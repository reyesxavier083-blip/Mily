@echo off
setlocal
set "ROOT_DIR=%~dp0"
set "PROPS=%ROOT_DIR%gradle\wrapper\gradle-wrapper.properties"
if not exist "%PROPS%" (
  echo ERROR: Missing %PROPS%
  exit /b 1
)
for /f "tokens=1,* delims==" %%A in ('findstr /b "distributionUrl=" "%PROPS%"') do set "DIST_URL=%%B"
set "DIST_URL=%DIST_URL:\:=:%"
for %%F in ("%DIST_URL%") do set "DIST_NAME=%%~nxF"
set "DIST_VERSION_DIR=%DIST_NAME:.zip=%"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\mily-bootstrap\%DIST_VERSION_DIR%"
set "DIST_ZIP=%CACHE_DIR%\%DIST_NAME%"
set "DIST_DIR=%CACHE_DIR%\%DIST_VERSION_DIR%"
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%DIST_ZIP%" (
    echo Mily: downloading Gradle distribution: %DIST_NAME%
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%DIST_URL%' -OutFile '%DIST_ZIP%'"
    if errorlevel 1 exit /b 1
  )
  echo Mily: extracting Gradle distribution...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST_ZIP%' '%CACHE_DIR%'"
  if errorlevel 1 exit /b 1
)
call "%DIST_DIR%\bin\gradle.bat" --project-dir "%ROOT_DIR%" %*
exit /b %ERRORLEVEL%
