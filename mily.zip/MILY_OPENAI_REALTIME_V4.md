# Mily OpenAI Realtime V4

This version adds the server-side WebRTC bridge for OpenAI Realtime.

## Flow

Android/WebRTC -> Mily backend -> `POST /v1/realtime/calls` -> OpenAI Realtime

The OpenAI API key remains on the backend. Android only talks to the Mily backend.

## Current scope

- Backend endpoint `/v1/mily/realtime/calls` proxies an SDP offer to OpenAI.
- Default realtime model: `gpt-realtime-2.1-mini`.
- Default voice: `marin`.
- Spanish instructions are applied by default.
- Android now contains the HTTP contract/configuration for this bridge.

## Not yet claimed as complete

The native Android WebRTC media layer (PeerConnection, microphone track, speaker sink, ICE lifecycle and UI state) still needs to be wired into the app and tested on a physical device.

OpenAI documents WebRTC as a supported Realtime transport and the `/v1/realtime/calls` endpoint as the server-side SDP bridge.


## V4.1 — Android WebRTC client

- Added `MilyRealtimeClient.kt` using native WebRTC (`org.webrtc:google-webrtc`).
- Captures microphone audio through WebRTC and negotiates a remote audio track with GPT-Live.
- Uses the `oai-events` data channel for session lifecycle and text events.
- Added runtime microphone permission handling in `MainActivity`.
- Added a dedicated GPT-Live headset button in `ChatScreen`; the existing microphone remains available for ordinary Android dictation.
- Backend now uses the current GPT-Live unified WebRTC flow: `POST /v1/live/sessions`.
- Default Live model: `gpt-live-1`; voice: `marin`.
- OpenAI credentials remain server-side.

OpenAI's current documentation describes WebRTC as the recommended transport for mobile/browser realtime voice and the unified Live session flow as the server-side initialization path. citeturn0search0turn0search11

### Validation
- Backend JavaScript syntax checked with `node --check`.
- Full Android compilation was not run in this environment because the archive does not include the Gradle wrapper executable/JAR and no system Gradle installation is available here.
