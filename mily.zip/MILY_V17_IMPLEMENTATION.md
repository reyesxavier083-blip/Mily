# Mily V17 — implementación consolidada

## Objetivo
Mily V17 consolida las etapas V8–V17 en una arquitectura única:

1. V8 — Knowledge Manager + OpenAI File Search
2. V9 — Memoria inteligente 2.0
3. V10 — Tool Gateway 2.0
4. V11 — GPT-Live avanzado
5. V12 — Memoria + voz
6. V13 — Context Engine
7. V14 — configuración/persona
8. V15 — permisos y seguridad
9. V16 — orquestación de rutas
10. V17 — consolidación y compatibilidad

## Arquitectura

Android → Backend Mily → OpenAI

- Android no contiene una API key de OpenAI.
- Responses API se usa para conversación, razonamiento y búsqueda documental.
- GPT-Live se usa para conversación de voz full-duplex.
- El backend mantiene el Vector Store y expone endpoints de conocimiento.
- Room continúa siendo la memoria local persistente de la app.
- El MemoryStore del backend es una caché de sesión para coordinación; para producción debe sustituirse por una base persistente del servidor.

## V8 — conocimiento

Endpoints:
- `GET /v1/mily/knowledge/vector-stores`
- `POST /v1/mily/knowledge/vector-stores`
- `POST /v1/mily/knowledge/files`
- `POST /v1/mily/knowledge/search`

El backend puede subir archivos a un Vector Store y realizar búsquedas semánticas.

## V9 — memoria

Endpoints:
- `POST /v1/mily/memory/list`
- `POST /v1/mily/memory/upsert`
- `POST /v1/mily/memory/remove`

La app sigue usando Room para conservar memoria aunque el backend no esté disponible.

## V10 — herramientas

`tool-gateway.mjs` aplica una lista permitida de herramientas. No se ejecutan nombres arbitrarios enviados por el modelo.

## V11/V12 — GPT-Live

La sesión Live usa `/v1/live/sessions` en OpenAI y el backend actúa como puente. El cliente Android conserva WebRTC y el canal de eventos.

## V13 — contexto

`context-engine.mjs` combina, con límites:
- conversación reciente;
- memoria;
- resultados documentales;
- contexto del dispositivo.

## V14 — configuración

La persona y preferencias existentes de Android siguen siendo la fuente de estilo local. El backend recibe instrucciones ya preparadas.

## V15 — seguridad

Se añadió `MilyPermissionGate` en Android y allowlist de herramientas en backend. Las operaciones sensibles deben continuar requiriendo confirmación de la aplicación.

## V16 — orquestación

`orchestrator.mjs` y `MilyOrchestrator` clasifican la solicitud como conversación, conocimiento o dispositivo. Es una primera capa determinista; el modelo sigue teniendo la última palabra sobre el contenido de la respuesta.

## V17 — consolidación

- Modelo OpenAI predeterminado del backend: `gpt-6-astra`.
- GPT-Live predeterminado: `gpt-live-1`.
- Gemini se conserva como compatibilidad para sesiones antiguas.
- Se mantiene Room v3 para evitar una migración destructiva innecesaria.
- Se añadieron servicios Android para conocimiento, contexto, orquestación y permisos.
- Se añadieron pruebas de sintaxis del backend.

## Configuración mínima

En `backend/mily-openai/.env`:

```text
OPENAI_API_KEY=...
MILY_DEFAULT_MODEL=gpt-6-astra
MILY_REALTIME_MODEL=gpt-live-1
MILY_VECTOR_STORE_ID=vs_...
MILY_PORT=8080
```

No pongas `OPENAI_API_KEY` dentro del APK.

## Estado de compilación

La validación de sintaxis JavaScript del backend pasó. El árbol entregado no contiene `gradlew`, por lo que no se declaró una compilación Android exitosa en este entorno.
