import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;

const app = express();
app.use(express.json({ limit: '10mb' }));

// Shared Gemini client with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface PersonaConfig {
  id: string;
  name: string;
  role: string;
  tone: string;
  focus: string;
  avatarSeed: string;
}

const PERSONA_PROMPTS: Record<string, string> = {
  essential: `Eres Mily (v18), una asistente de inteligencia artificial perspicaz, empática, eficiente y altamente resolutiva.
Tu tono es cálido, natural, elocuente y cercano en español. Ayudas en cualquier tarea con respuestas claras, estructuradas y profundas. Si el usuario te pide código, explícalo con elegancia. Si te comparte datos sobre él, intégralos con consideración.`,
  technical: `Eres Mily en modo Arquitecta Técnica & Especialista en Software.
Tu enfoque es el rigor de ingeniería, algoritmos eficientes, arquitectura limpia (SOLID, Clean Architecture), patrones modernos, código robusto, pruebas y depuración metódica. Sé directa, técnica y precisa. Usa bloques de código bien comentados y explica decisiones de diseño.`,
  creative: `Eres Mily en modo Creativa & Narradora.
Tu estilo es vibrante, imaginativo, poético cuando corresponde, persuasivo y rico en metáforas originales. Ayudas a redactar historias, guiones, ideas de negocio, campañas publicitarias, discursos o poesía con estilo literario cautivador.`,
  executive: `Eres Mily en modo Asesora Estratégica & Ejecutiva.
Tu enfoque es la productividad de alto impacto, síntesis ejecutiva, planes de acción en listas claras (bullet points), matrices de decisión, priorización 80/20 y enfoque a objetivos cuantificables. Sé concisa y pragmática.`,
  scientist: `Eres Mily en modo Investigadora Científica.
Tu enfoque es el método científico, explicaciones paso a paso de primeros principios, análisis causal, fuentes conceptuales, verificación de premisas y claridad pedagógica absoluta.`,
};

// API: System status and model info
app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    status: 'online',
    version: '18.4.2',
    name: 'Mily',
    model: 'gemini-3.8-flash',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    engines: {
      nexus: 'activo',
      semanticMemory: 'operativo',
      episodicMemory: 'operativo',
      voiceSynthesizer: 'disponible',
      autonomousLearning: 'habilitado',
    },
    uptime: process.uptime(),
  });
});

// API: Streaming Chat Endpoint (SSE)
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const {
      messages = [],
      persona = 'essential',
      memories = [],
      temperature = 0.7,
      autonomousExtraction = true,
    } = req.body;

    const basePersonaPrompt =
      PERSONA_PROMPTS[persona] || PERSONA_PROMPTS.essential;

    // Inject semantic/episodic memories if present
    let memoryBlock = '';
    if (Array.isArray(memories) && memories.length > 0) {
      memoryBlock = `\n\n[MEMORIA ACTIVA DE MILY SOBRE EL USUARIO Y CONTEXTO]:\n${memories
        .map((m: any) => `- [${m.type || 'recuerdo'}] ${m.content}`)
        .join('\n')}\nUtiliza estos datos de forma natural para personalizar tus respuestas sin mencionarlos mecánicamente a menos que sea relevante.`;
    }

    const systemInstruction = `${basePersonaPrompt}${memoryBlock}

Instrucciones de formato y comportamiento:
1. Responde siempre en español natural, salvo que el usuario hable en otro idioma.
2. Utiliza Markdown enriquecido: títulos limpios, listas ordenadas, negritas para conceptos clave y bloques de código con especificador de lenguaje.
3. Si el usuario te hace una corrección o te enseña un dato nuevo ("Mily, recuerda que...", "Prefiero que..."), acéptalo con amabilidad y confirma que lo has integrado a tu memoria.
4. Muestra curiosidad intelectual y ofrece sugerencias prácticas cuando sea constructivo.`;

    // Format conversation history for Gemini API
    // Gemini contents accepts array of { role: 'user' | 'model', parts: [{ text }] }
    const geminiContents: Array<{
      role: 'user' | 'model';
      parts: Array<{ text: string }>;
    }> = [];

    for (const msg of messages) {
      if (!msg.content || typeof msg.content !== 'string') continue;
      const role = msg.role === 'assistant' ? 'model' : 'user';
      geminiContents.push({
        role,
        parts: [{ text: msg.content }],
      });
    }

    // Ensure at least one message exists
    if (geminiContents.length === 0) {
      geminiContents.push({
        role: 'user',
        parts: [{ text: 'Hola Mily, ¿puedes presentarte?' }],
      });
    }

    // Set up SSE headers for smooth streaming
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    if (!process.env.GEMINI_API_KEY) {
      // Graceful demo response when API key is missing
      const demoReply = `Hola, soy **Mily v18**, tu asistente inteligente autónoma. 
      
Estoy lista para ayudarte con razonamiento, programación, redacción, organización y conversación. 

*Nota de inicialización:* Parece que la variable \`GEMINI_API_KEY\` aún no ha sido provista en el entorno. Para desbloquear mi capacidad total de generación mediante Gemini 3.8 Flash, puedes agregarla en la pestaña de Secretos. Sin embargo, mi interfaz, memorias y controles de voz están 100% operativos.`;
      
      const words = demoReply.split(' ');
      for (const word of words) {
        res.write(`data: ${JSON.stringify({ text: word + ' ' })}\n\n`);
        await new Promise((r) => setTimeout(r, 25));
      }
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
      return;
    }

    // Call Gemini with model fallback if a specific model encounters temporary high demand
    const candidateModels = ['gemini-3.8-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];
    let fullText = '';
    let streamSucceeded = false;

    for (const modelName of candidateModels) {
      try {
        const responseStream = await ai.models.generateContentStream({
          model: modelName,
          contents: geminiContents,
          config: {
            systemInstruction,
            temperature: Math.max(0.1, Math.min(1.2, Number(temperature) || 0.7)),
          },
        });

        for await (const chunk of responseStream) {
          const chunkText = chunk.text;
          if (chunkText) {
            fullText += chunkText;
            res.write(`data: ${JSON.stringify({ text: chunkText })}\n\n`);
          }
        }

        if (fullText.length > 0) {
          streamSucceeded = true;
          break;
        }
      } catch (err: any) {
        console.warn(`Model ${modelName} stream error: ${err.message}. Trying next candidate...`);
      }
    }

    if (!streamSucceeded) {
      // Graceful Mily fallback reply when all cloud models hit temporary 503 spikes
      const fallbackResponse = `¡Hola! Soy **Mily**. En este momento los servidores centrales están experimentando una alta demanda temporal, pero mis sistemas locales, orbe de voz y memoria cognitiva continúan 100% operativos.

Puedo ayudarte con cálculos, planificación de tareas, auditoría de código o conversación. Por favor intenta enviarme tu consulta nuevamente en un instante.`;

      const words = fallbackResponse.split(' ');
      for (const word of words) {
        res.write(`data: ${JSON.stringify({ text: word + ' ' })}\n\n`);
        await new Promise((r) => setTimeout(r, 20));
      }
    }

    res.write(`data: ${JSON.stringify({ done: true, fullLength: fullText.length })}\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    if (!res.headersSent) {
      res.status(500).json({
        error: error.message || 'Error procesando la respuesta con Mily.',
      });
    } else {
      res.write(
        `data: ${JSON.stringify({
          error: error.message || 'Error durante la transmisión.',
          done: true,
        })}\n\n`
      );
      res.end();
    }
  }
});

// API: Autonomous learning & memory extraction
app.post('/api/learn', async (req: Request, res: Response) => {
  try {
    const { userMessage, assistantReply } = req.body;
    if (!process.env.GEMINI_API_KEY || !userMessage) {
      res.json({ extractedFacts: [] });
      return;
    }

    const prompt = `Analiza la siguiente intervención del usuario e identifica si contiene algún dato personal relevante, preferencia, nombre, proyecto o regla permanente que Mily deba recordar a futuro.
Mensaje del usuario: "${userMessage}"
Respuesta de Mily: "${assistantReply || ''}"

Responde ÚNICAMENTE en formato JSON con la siguiente estructura:
{
  "facts": [
    { "type": "semantic" | "preference" | "goal" | "identity", "content": "descripción concisa del hecho a recordar en español" }
  ]
}
Si no hay hechos duraderos que recordar (solo una pregunta casual o saludo), devuelve { "facts": [] }.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    try {
      const parsed = JSON.parse(response.text?.trim() || '{"facts":[]}');
      res.json(parsed);
    } catch {
      res.json({ facts: [] });
    }
  } catch (err: any) {
    console.warn('Memory learning error:', err.message);
    res.json({ facts: [] });
  }
});

// API: Gemini Text-to-Speech (fallback to Web Speech API on client if needed)
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voice = 'Kore' } = req.body;
    if (!text || !process.env.GEMINI_API_KEY) {
      res.status(400).json({ error: 'Text and API key are required' });
      return;
    }

    // Clean text to avoid markdown artifacts in speech
    const cleanText = text
      .replace(/```[\s\S]*?```/g, 'bloque de código omitido')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[*_#~]/g, '')
      .slice(0, 800);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [{ text: cleanText }],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice || 'Kore' },
          },
        },
      },
    });

    const base64Audio =
      response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (base64Audio) {
      res.json({ audio: base64Audio, mimeType: 'audio/wav' });
    } else {
      res.status(500).json({ error: 'No audio generated by model' });
    }
  } catch (err: any) {
    console.warn('TTS error (falling back to client synthesis):', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Start Express server and mount Vite in development
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🤖 Mily v18 Server running at http://localhost:${PORT}`);
  });
}

startServer();
