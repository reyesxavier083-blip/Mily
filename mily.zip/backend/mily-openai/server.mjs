import express from "express";
import OpenAI from "openai";
import multer from "multer";
import { MemoryStore } from "./src/memory-store.mjs";
import { buildContext } from "./src/context-engine.mjs";
import { chooseRoute } from "./src/orchestrator.mjs";
import { createVectorStore, listVectorStores, addFileToVectorStore, searchKnowledge } from "./src/knowledge.mjs";
import { executeTool } from "./src/tool-gateway.mjs";

const app = express();
app.use(express.json({ limit: "512kb" }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
const port = Number(process.env.MILY_PORT || 8080);
const defaultModel = process.env.MILY_DEFAULT_MODEL || "gpt-6-astra";
const vectorStoreId = () => process.env.MILY_VECTOR_STORE_ID?.trim() || "";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const memoryStore = new MemoryStore();

app.get("/health", (_req,res) => res.json({ ok:true, service:"mily-openai-backend", version:"1.0.0", model:defaultModel, liveModel:process.env.MILY_REALTIME_MODEL || "gpt-live-1" }));

app.get('/v1/mily/knowledge/vector-stores', async (_req,res) => {
  try { res.json(await listVectorStores(client)); } catch(e) { res.status(502).json({error:'No fue posible listar Vector Stores.'}); }
});
app.post('/v1/mily/knowledge/vector-stores', async (req,res) => {
  try { res.status(201).json(await createVectorStore(client, req.body?.name || 'Mily Knowledge')); } catch(e) { res.status(502).json({error:'No fue posible crear el Vector Store.'}); }
});
app.post('/v1/mily/knowledge/files', upload.single('file'), async (req,res) => {
  try {
    const id = req.body?.vectorStoreId || vectorStoreId();
    if (!id || !req.file) return res.status(400).json({error:'vectorStoreId y file son requeridos.'});
    const result = await addFileToVectorStore(client, id, req.file.buffer, req.file.originalname);
    res.status(201).json({ vectorStoreId:id, fileName:req.file.originalname, file:result });
  } catch(e) { console.error(e?.message || e); res.status(502).json({error:'No fue posible agregar el archivo al conocimiento.'}); }
});
app.post('/v1/mily/knowledge/search', async (req,res) => {
  try { res.json({ results: await searchKnowledge(client, req.body?.vectorStoreId || vectorStoreId(), req.body?.query || '', req.body?.maxNumResults || 8) }); }
  catch(e) { res.status(502).json({error:'No fue posible buscar en el conocimiento.'}); }
});

app.post("/v1/mily/memory/list", (req,res) => res.json({ items:memoryStore.list(String(req.body?.userId||'default'),30) }));
app.post("/v1/mily/memory/recall", (req,res) => { const userId=String(req.body?.userId||'default'); const query=String(req.body?.query||''); res.json({ items:memoryStore.recall(userId,query,Number(req.body?.limit||12)) }); });
app.post("/v1/mily/memory/upsert", (req,res) => { const item=memoryStore.upsert(String(req.body?.userId||'default'),req.body||{}); res.status(item?201:400).json(item||{error:'text requerido.'}); });
app.post("/v1/mily/memory/remove", (req,res) => { memoryStore.remove(String(req.body?.userId||'default'),String(req.body?.id||'')); res.json({ok:true}); });

app.post("/v1/mily/tools/execute", async (req,res) => {
  try { res.json(await executeTool(req.body?.call, { memoryStore, knowledgeSearch:q=>searchKnowledge(client, vectorStoreId(), q, 8) })); }
  catch(e) { res.status(400).json({error:e?.message || 'Herramienta rechazada.'}); }
});

app.post("/v1/mily/responses", async (req,res) => {
  try {
    const { model, instructions, input, temperature, maxOutputTokens, memoryFacts, enableFileSearch=true, maxFileSearchResults=6, userId='default', deviceContext=null } = req.body ?? {};
    if (!Array.isArray(input) || !input.length) return res.status(400).json({error:'input debe contener al menos un mensaje.'});
    const safeMessages=input.slice(-20).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content??'').slice(0,12000)}));
    const memories=[...memoryStore.list(String(userId),30),...(Array.isArray(memoryFacts)?memoryFacts.filter(Boolean).slice(0,30).map(text=>({text,category:'local'})):[])];
    const route=chooseRoute({prompt:safeMessages.at(-1)?.content,wantsVoice:false,hasDocuments:Boolean(vectorStoreId())});
    let fileResults=[];
    if (enableFileSearch && vectorStoreId() && route.useFileSearch) fileResults=await searchKnowledge(client,vectorStoreId(),safeMessages.at(-1)?.content||'',maxFileSearchResults);
    const context=buildContext({messages:safeMessages,memories,fileResults,deviceContext});
    let enriched=String(instructions||'Eres Mily, una asistente útil, clara y segura.').slice(0,12000);
    if(context) enriched += `\n\nCONTEXTO DE APOYO:\n${context}`;
    const tools=[];
    if(enableFileSearch && vectorStoreId()) tools.push({type:'file_search',vector_store_ids:[vectorStoreId()],max_num_results:Math.max(1,Math.min(20,Number(maxFileSearchResults)||6))});
    const result=await client.responses.create({model:typeof model==='string'&&model.trim()?model:defaultModel,instructions:enriched,input:safeMessages,tools,include:tools.length?['file_search_call.results']:undefined,temperature:typeof temperature==='number'?Math.max(0,Math.min(2,temperature)):0.7,max_output_tokens:typeof maxOutputTokens==='number'?Math.max(1,Math.min(4096,maxOutputTokens)):2048});
    res.json({outputText:result.output_text||'',responseId:result.id,tokenCount:result.usage?.total_tokens??null,route,fileSearchUsed:fileResults.length>0,fileSearchResults:fileResults});
  } catch(e) { console.error('Responses error:',e?.message||e); res.status(502).json({error:'No fue posible completar la solicitud con OpenAI.'}); }
});

app.post('/v1/mily/live/sessions', async (req,res) => {
  try {
    const session=req.body?.session&&typeof req.body.session==='object'?req.body.session:{type:'live',model:process.env.MILY_REALTIME_MODEL||'gpt-live-1'};
    const sdp=typeof req.body?.transport?.sdp==='string'?req.body.transport.sdp:'';
    if(!sdp.trim()) return res.status(400).json({error:'transport.sdp es requerido.'});
    const upstream=await fetch('https://api.openai.com/v1/live/sessions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({session,transport:{type:'webrtc',sdp}})});
    const answer=await upstream.text(); if(!upstream.ok){console.error(answer.slice(0,1000));return res.status(502).json({error:'No fue posible crear la sesión GPT-Live.'});}
    res.status(201).type('application/json').send(answer);
  } catch(e){res.status(502).json({error:'Error al conectar Mily con GPT-Live.'});}
});
app.listen(port,'0.0.0.0',()=>console.log(`Mily backend v1.0 escuchando en ${port}`));
