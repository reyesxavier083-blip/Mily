# Mily — OpenAI Backend V1

Este servicio mantiene la clave de OpenAI fuera del APK de Mily y expone un endpoint pequeño para el proveedor `OpenAiBackendProvider`.

## Configuración

1. Copia `.env.example` a `.env`.
2. Define `OPENAI_API_KEY` en el entorno del servidor.
3. Instala dependencias con `npm install`.
4. Inicia con `npm start`.
5. Configura `MILY_BACKEND_URL` en Mily para apuntar al servidor, por ejemplo `http://10.0.2.2:8080/` cuando el backend corre en el host y Mily se ejecuta en el emulador Android.

La aplicación Android no debe contener la clave de OpenAI.

## Endpoint

`POST /v1/mily/responses`

El backend traduce la petición de Mily a Responses API y devuelve `outputText`, `tokenCount` y `responseId`.

## Siguiente etapa

- autenticación del cliente Mily;
- control de sesión/conversación;
- herramientas y function calling;
- File Search;
- capa Realtime/GPT-Live independiente del chat normal.
