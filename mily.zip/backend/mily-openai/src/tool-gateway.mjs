const SAFE_TOOLS = new Set(['server_time','device_context','memory_list','memory_upsert','memory_remove','knowledge_search']);
export function validateToolCall(call) {
  if (!call || typeof call.name !== 'string' || !SAFE_TOOLS.has(call.name)) throw new Error('Herramienta no permitida.');
  return { name: call.name, arguments: call.arguments && typeof call.arguments === 'object' ? call.arguments : {} };
}
export async function executeTool(call, deps) {
  const safe = validateToolCall(call);
  switch (safe.name) {
    case 'server_time': return { iso: new Date().toISOString() };
    case 'device_context': return { context: String(safe.arguments.context || '').slice(0, 3000) };
    case 'memory_list': return deps.memoryStore.list(String(safe.arguments.userId || 'default'), 30);
    case 'memory_upsert': return deps.memoryStore.upsert(String(safe.arguments.userId || 'default'), safe.arguments);
    case 'memory_remove': deps.memoryStore.remove(String(safe.arguments.userId || 'default'), String(safe.arguments.id || '')); return { ok:true };
    case 'knowledge_search': return await deps.knowledgeSearch(String(safe.arguments.query || '').slice(0, 2000));
  }
}
