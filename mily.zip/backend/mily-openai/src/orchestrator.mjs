export function chooseRoute({ prompt, wantsVoice=false, hasDocuments=false }) {
  const p = String(prompt || '').toLowerCase();
  const knowledge = hasDocuments && /(documento|archivo|pdf|según|segun|manual|proyecto|donde dice|qué dice|que dice)/.test(p);
  const device = /(batería|bateria|ram|almacenamiento|teléfono|telefono|celular|dispositivo|hardware)/.test(p);
  return { voice: wantsVoice, useFileSearch: knowledge, useDeviceContext: device, mode: knowledge ? 'knowledge' : device ? 'device' : 'conversation' };
}
