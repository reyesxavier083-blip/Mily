export class MemoryStore {
  constructor() { this.items = new Map(); }
  upsert(userId, item) {
    const key = `${userId}:${item.id || crypto.randomUUID()}`;
    const value = { id: item.id || key, userId, text: String(item.text || '').trim(), category: item.category || 'general', confidence: Number(item.confidence ?? 0.7), updatedAt: Date.now(), active: item.active !== false };
    if (!value.text) return null;
    this.items.set(key, value); return value;
  }
  list(userId, limit = 30) { return [...this.items.values()].filter(x => x.userId === userId && x.active).sort((a,b)=>b.updatedAt-a.updatedAt).slice(0, limit); }
  remove(userId, id) { for (const [k,v] of this.items) if (v.userId===userId && v.id===id) this.items.delete(k); }
  recall(userId, query, limit = 12) {
    const terms = String(query || '').toLowerCase().match(/[\p{L}\p{N}]{3,}/gu) || [];
    const unique = [...new Set(terms)];
    const now = Date.now();
    return this.list(userId, 200).map(item => {
      const words = new Set((item.text.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu) || []));
      const overlap = unique.length ? unique.filter(t => words.has(t)).length / unique.length : 0;
      const ageDays = Math.max(0, now - item.updatedAt) / 86400000;
      const recency = 1 / (1 + ageDays / 30);
      const score = overlap * (0.55 + 0.45 * Math.max(0, Math.min(1, item.confidence))) * (0.65 + 0.35 * recency);
      return { ...item, relevance: score };
    }).filter(x => x.relevance > 0).sort((a,b) => b.relevance - a.relevance).slice(0, Math.max(1, Math.min(50, limit)));
  }
}
