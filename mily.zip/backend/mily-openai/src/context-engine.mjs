export function buildContext({ messages=[], memories=[], fileResults=[], deviceContext=null, maxChars=18000 }) {
  const sections = [];
  const add = (title, lines) => { const s = lines.filter(Boolean).join('\n'); if (s) sections.push(`${title}:\n${s}`); };
  add('MEMORIA', memories.slice(0,30).map(m => `- [${m.category || 'general'}] ${m.text || m.content}`));
  add('DOCUMENTOS', fileResults.slice(0,10).map(r => `- ${r.filename || r.fileId || 'archivo'}: ${String(r.text || '').slice(0,1200)}`));
  add('DISPOSITIVO', deviceContext ? [String(deviceContext).slice(0,3000)] : []);
  add('CONVERSACIÓN RECIENTE', messages.slice(-12).map(m => `${m.role}: ${String(m.content || '').slice(0,1200)}`));
  return sections.join('\n\n').slice(0, maxChars);
}
