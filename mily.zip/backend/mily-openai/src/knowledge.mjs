export async function createVectorStore(client, name) { return client.vectorStores.create({ name: String(name || 'Mily Knowledge').slice(0,120) }); }
export async function listVectorStores(client) { return client.vectorStores.list({ limit: 100 }); }
import { toFile } from 'openai';

export async function addFileToVectorStore(client, vectorStoreId, file, filename='document') {
  const uploadable = await toFile(file, filename);
  const uploaded = await client.files.create({ file: uploadable, purpose: 'assistants' });
  return client.vectorStores.files.create(vectorStoreId, { file_id: uploaded.id });
}
export async function searchKnowledge(client, vectorStoreId, query, maxNumResults=8) {
  if (!vectorStoreId) return [];
  const result = await client.vectorStores.search(vectorStoreId, { query: String(query).slice(0,2000), max_num_results: Math.max(1, Math.min(20, maxNumResults)) });
  return Array.isArray(result.data) ? result.data.map(x => ({ fileId:x.file_id, filename:x.filename, score:x.score, text:(x.content || []).map(c=>c.text || '').join('\n') })) : [];
}
