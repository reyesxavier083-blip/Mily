package com.example.util

import android.app.Application
import android.content.Context
import kotlin.system.exitProcess

class CrashHandler(private val application: Application) : Thread.UncaughtExceptionHandler {
    private val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(thread: Thread, exception: Throwable) {
        val stackTrace = exception.stackTraceToString()
        
        // Save to SharedPreferences so we can read it on next launch
        val prefs = application.getSharedPreferences("nexus_crash_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("last_crash_trace", stackTrace).commit() // Synchronous commit to ensure it saves
        
        // Let the default handler do its job (or just kill process if none exists)
        if (defaultHandler != null) {
            defaultHandler.uncaughtException(thread, exception)
        } else {
            exitProcess(2)
        }
    }

    companion object {
        fun init(application: Application) {
            val currentHandler = Thread.getDefaultUncaughtExceptionHandler()
            if (currentHandler !is CrashHandler) {
                Thread.setDefaultUncaughtExceptionHandler(CrashHandler(application))
            }
        }
        
        fun getLastCrash(context: Context): String? {
            val prefs = context.getSharedPreferences("nexus_crash_prefs", Context.MODE_PRIVATE)
            val crash = prefs.getString("last_crash_trace", null)
            if (crash != null) {
                // Clear it after reading so we don't report it again
                prefs.edit().remove("last_crash_trace").apply()
            }
            return crash
        }
    }
}
