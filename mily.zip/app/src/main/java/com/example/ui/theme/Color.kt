package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val CyanPrimaryLight = Color(0xFF0284C7)
val CyanOnPrimaryLight = Color(0xFFFFFFFF)
val CyanPrimaryContainerLight = Color(0xFFE0F2FE)
val CyanOnPrimaryContainerLight = Color(0xFF0369A1)
val VioletSecondaryLight = Color(0xFF4F46E5)
val VioletOnSecondaryLight = Color(0xFFFFFFFF)
val VioletSecondaryContainerLight = Color(0xFFEEF2FF)
val VioletOnSecondaryContainerLight = Color(0xFF3730A3)
val AmberTertiaryLight = Color(0xFFD97706)
val AmberOnTertiaryLight = Color(0xFFFFFFFF)
val AmberTertiaryContainerLight = Color(0xFFFEF3C7)
val AmberOnTertiaryContainerLight = Color(0xFF92400E)

val BackgroundLight = Color(0xFFE2E8F0) // Slightly darker silver background
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFF1F5F9) // Metallic silver surface
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFCBD5E1)
val OnSurfaceVariantLight = Color(0xFF334155)
val OutlineLight = Color(0xFF94A3B8)

// Dark Palette (Metallic & Futuristic)
val CyanPrimaryDark = Color(0xFF00F0FF) // Neon Cyan
val CyanOnPrimaryDark = Color(0xFF002233)
val CyanPrimaryContainerDark = Color(0xFF004466)
val CyanOnPrimaryContainerDark = Color(0xFF80FAFF)

val VioletSecondaryDark = Color(0xFFA855F7) // Neon Violet
val VioletOnSecondaryDark = Color(0xFF1E1B4B)
val VioletSecondaryContainerDark = Color(0xFF3730A3)
val VioletOnSecondaryContainerDark = Color(0xFFEEF2FF)

val AmberTertiaryDark = Color(0xFFFFB300) // Gold / Bronze
val AmberOnTertiaryDark = Color(0xFF451A03)
val AmberTertiaryContainerDark = Color(0xFF78350F)
val AmberOnTertiaryContainerDark = Color(0xFFFEF3C7)

// Gunmetal & Titanium Dark Theme
val BackgroundDark = Color(0xFF06090F) // Very deep void background
val OnBackgroundDark = Color(0xFFE2E8F0)
val SurfaceDark = Color(0xFF0B121C) // Dark steel surface
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF151E2E) // Lighter steel variant
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF2E3E53) // Metallic stroke

// Custom UI Accents
val CodeBackgroundDark = Color(0xFF05080C)
val CodeBorderDark = Color(0xFF1E2D3D)
val UserBubbleLight = Color(0xFF0F172A) // Sleek dark bubble for light mode
val UserBubbleDark = Color(0xFF131D2E) // Dark steel blue for user bubble
val AssistantCardDark = Color(0xFF0B131E)
val AssistantCardLight = Color(0xFFE2E8F0)
val GlowingCyan = Color(0xFF00F0FF)
val GlowingViolet = Color(0xFFA855F7)

// Metallic Gradients Colors (For use in Brushes)
val SilverLight = Color(0xFFE2E8F0)
val SilverDark = Color(0xFF94A3B8)
val TitaniumLight = Color(0xFF334155)
val TitaniumDark = Color(0xFF0F172A)
