package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private sealed class MarkdownSegment {
    data class Regular(val text: String) : MarkdownSegment()
    data class CodeBlock(val language: String, val code: String) : MarkdownSegment()
    data class Header(val level: Int, val text: String) : MarkdownSegment()
    data class BulletItem(val prefix: String, val text: String) : MarkdownSegment()
}

@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val segments = parseMarkdown(markdown)

    Column(modifier = modifier.fillMaxWidth()) {
        segments.forEach { segment ->
            when (segment) {
                is MarkdownSegment.CodeBlock -> {
                    CodeBlockView(language = segment.language, code = segment.code)
                }
                is MarkdownSegment.Header -> {
                    val fontSize = when (segment.level) {
                        1 -> 20.sp
                        2 -> 17.sp
                        else -> 15.sp
                    }
                    Text(
                        text = buildAnnotatedInline(segment.text, textColor),
                        fontSize = fontSize,
                        fontWeight = FontWeight.Bold,
                        color = textColor,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                is MarkdownSegment.BulletItem -> {
                    Row(modifier = Modifier.padding(vertical = 2.dp, horizontal = 4.dp)) {
                        Text(
                            text = segment.prefix,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Text(
                            text = buildAnnotatedInline(segment.text, textColor),
                            fontSize = 14.5.sp,
                            lineHeight = 21.sp,
                            color = textColor
                        )
                    }
                }
                is MarkdownSegment.Regular -> {
                    if (segment.text.isNotBlank()) {
                        Text(
                            text = buildAnnotatedInline(segment.text, textColor),
                            fontSize = 14.5.sp,
                            lineHeight = 21.sp,
                            color = textColor,
                            modifier = Modifier.padding(vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun parseMarkdown(raw: String): List<MarkdownSegment> {
    val segments = mutableListOf<MarkdownSegment>()
    val lines = raw.split("\n")
    var inCodeBlock = false
    var codeLang = ""
    val codeBuilder = StringBuilder()
    val textBuilder = StringBuilder()

    for (line in lines) {
        val trimmed = line.trim()

        if (trimmed.startsWith("```")) {
            if (inCodeBlock) {
                // End of code block
                segments.add(MarkdownSegment.CodeBlock(codeLang, codeBuilder.toString().trimEnd()))
                codeBuilder.clear()
                codeLang = ""
                inCodeBlock = false
            } else {
                // Start of code block
                if (textBuilder.isNotEmpty()) {
                    segments.add(MarkdownSegment.Regular(textBuilder.toString().trim()))
                    textBuilder.clear()
                }
                codeLang = trimmed.removePrefix("```").trim()
                inCodeBlock = true
            }
            continue
        }

        if (inCodeBlock) {
            codeBuilder.append(line).append("\n")
            continue
        }

        // Check for headers
        if (line.startsWith("# ") || line.startsWith("## ") || line.startsWith("### ")) {
            if (textBuilder.isNotEmpty()) {
                segments.add(MarkdownSegment.Regular(textBuilder.toString().trim()))
                textBuilder.clear()
            }
            val level = line.takeWhile { it == '#' }.length
            val headerText = line.drop(level).trim()
            segments.add(MarkdownSegment.Header(level, headerText))
            continue
        }

        // Check for list items
        if (line.trimStart().startsWith("- ") || line.trimStart().startsWith("* ") || line.trimStart().startsWith("• ")) {
            if (textBuilder.isNotEmpty()) {
                segments.add(MarkdownSegment.Regular(textBuilder.toString().trim()))
                textBuilder.clear()
            }
            val content = line.trimStart().drop(2).trim()
            segments.add(MarkdownSegment.BulletItem("•", content))
            continue
        }

        val numberedMatch = Regex("^\\s*(\\d+\\.)\\s+(.*)").find(line)
        if (numberedMatch != null) {
            if (textBuilder.isNotEmpty()) {
                segments.add(MarkdownSegment.Regular(textBuilder.toString().trim()))
                textBuilder.clear()
            }
            val numPrefix = numberedMatch.groupValues[1]
            val content = numberedMatch.groupValues[2]
            segments.add(MarkdownSegment.BulletItem(numPrefix, content))
            continue
        }

        textBuilder.append(line).append("\n")
    }

    if (inCodeBlock && codeBuilder.isNotEmpty()) {
        segments.add(MarkdownSegment.CodeBlock(codeLang, codeBuilder.toString().trimEnd()))
    } else if (textBuilder.isNotEmpty()) {
        segments.add(MarkdownSegment.Regular(textBuilder.toString().trim()))
    }

    return segments
}

private fun buildAnnotatedInline(raw: String, baseColor: Color): AnnotatedString {
    return buildAnnotatedString {
        var i = 0
        while (i < raw.length) {
            // Check for bold **...**
            if (i + 1 < raw.length && raw[i] == '*' && raw[i + 1] == '*') {
                val end = raw.indexOf("**", i + 2)
                if (end != -1) {
                    pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                    append(raw.substring(i + 2, end))
                    pop()
                    i = end + 2
                    continue
                }
            }

            // Check for inline code `...`
            if (raw[i] == '`') {
                val end = raw.indexOf('`', i + 1)
                if (end != -1) {
                    pushStyle(
                        SpanStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            background = Color(0x22888888),
                            color = Color(0xFF0284C7)
                        )
                    )
                    append(raw.substring(i + 1, end))
                    pop()
                    i = end + 1
                    continue
                }
            }

            // Check for italic *...*
            if (raw[i] == '*') {
                val end = raw.indexOf('*', i + 1)
                if (end != -1) {
                    pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                    append(raw.substring(i + 1, end))
                    pop()
                    i = end + 1
                    continue
                }
            }

            append(raw[i])
            i++
        }
    }
}
