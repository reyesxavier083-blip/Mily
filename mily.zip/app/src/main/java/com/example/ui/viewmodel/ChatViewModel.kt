package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SpeechManager
import com.example.data.local.AppDatabase
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatSessionEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.NexusEngineTemplate
import com.example.data.model.NexusEngineType
import com.example.data.model.Persona
import com.example.data.remote.ApiConnectionStatus
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val currentSession: ChatSessionEntity? = null,
    val messages: List<ChatMessageEntity> = emptyList(),
    val sessions: List<ChatSessionEntity> = emptyList(),
    val filteredSessions: List<ChatSessionEntity> = emptyList(),
    val memories: List<MemoryEntity> = emptyList(),
    val activeMemoriesCount: Int = 0,
    val isAutonomousLearningEnabled: Boolean = true,
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val selectedPersona: Persona = Persona.DEFAULT_PERSONAS.first(),
    val currentModel: String = "gpt-6-astra",
    val customApiKey: String = "",
    val temperature: Float = 0.7f,
    val isSpeaking: Boolean = false,
    val speakingMessageId: String? = null,
    val apiConnectionStatus: ApiConnectionStatus = ApiConnectionStatus.Idle,
    val errorMessage: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val repository = ChatRepository(
        database.chatDao(),
        database.memoryDao(),
        database.episodicMemoryDao(),
        database.semanticMemoryDao()
    )
    val speechManager = SpeechManager(application)
    val deviceManager = com.example.device.DeviceSystemManager(application)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var messagesJob: Job? = null

    init {
        // Observe sessions from Room
        viewModelScope.launch {
            repository.allSessions.collect { sessionsList ->
                val current = _uiState.value.currentSession
                val selectedSession = if (current != null && sessionsList.any { it.id == current.id }) {
                    sessionsList.first { it.id == current.id }
                } else if (sessionsList.isNotEmpty()) {
                    sessionsList.first()
                } else {
                    null
                }

                _uiState.value = _uiState.value.copy(
                    sessions = sessionsList,
                    filteredSessions = filterSessions(sessionsList, _uiState.value.searchQuery),
                    currentSession = selectedSession
                )

                if (selectedSession == null && sessionsList.isEmpty()) {
                    createNewSession()
                } else if (selectedSession != null) {
                    observeMessagesForSession(selectedSession.id)
                    val persona = Persona.getById(selectedSession.personaId)
                    _uiState.value = _uiState.value.copy(
                        selectedPersona = persona,
                        currentModel = selectedSession.modelName
                    )
                }
            }
        }

        // Observe memories from Room
        viewModelScope.launch {
            repository.allMemories.collect { memList ->
                _uiState.value = _uiState.value.copy(
                    memories = memList,
                    activeMemoriesCount = memList.count { it.isActive }
                )
            }
        }

        // Observe TTS state
        viewModelScope.launch {
            speechManager.isSpeaking.collect { speaking ->
                _uiState.value = _uiState.value.copy(isSpeaking = speaking)
            }
        }

        viewModelScope.launch {
            speechManager.currentMessageId.collect { id ->
                _uiState.value = _uiState.value.copy(speakingMessageId = id)
            }
        }
    }

    private fun observeMessagesForSession(sessionId: String) {
        messagesJob?.cancel()
        messagesJob = viewModelScope.launch {
            repository.getMessages(sessionId).collect { messageList ->
                _uiState.value = _uiState.value.copy(messages = messageList)
            }
        }
    }

    fun createNewSession(personaId: String? = null, initialPrompt: String? = null) {
        viewModelScope.launch {
            speechManager.stop()
            val chosenPersonaId = personaId ?: _uiState.value.selectedPersona.id
            val newSession = repository.createNewSession(
                personaId = chosenPersonaId,
                modelName = _uiState.value.currentModel
            )
            _uiState.value = _uiState.value.copy(
                currentSession = newSession,
                selectedPersona = Persona.getById(chosenPersonaId),
                currentModel = newSession.modelName
            )
            observeMessagesForSession(newSession.id)

            if (!initialPrompt.isNullOrBlank()) {
                sendMessage(initialPrompt)
            }
        }
    }

    fun selectSession(sessionId: String) {
        viewModelScope.launch {
            speechManager.stop()
            val session = repository.getSession(sessionId) ?: return@launch
            val persona = Persona.getById(session.personaId)
            _uiState.value = _uiState.value.copy(
                currentSession = session,
                selectedPersona = persona,
                currentModel = session.modelName
            )
            observeMessagesForSession(sessionId)
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            speechManager.stop()
            repository.deleteSession(sessionId)
        }
    }

    fun togglePinSession(sessionId: String) {
        viewModelScope.launch {
            repository.togglePin(sessionId)
        }
    }

    fun clearCurrentChat() {
        val currentSessionId = _uiState.value.currentSession?.id ?: return
        viewModelScope.launch {
            speechManager.stop()
            repository.clearSessionMessages(currentSessionId)
        }
    }

    fun selectPersona(persona: Persona) {
        _uiState.value = _uiState.value.copy(
            selectedPersona = persona,
            temperature = persona.defaultTemperature
        )
        val currentSession = _uiState.value.currentSession
        if (currentSession != null) {
            viewModelScope.launch {
                repository.updateSession(currentSession.copy(personaId = persona.id))
            }
        }
    }

    fun triggerAutoRepair(stackTrace: String) {
        val template = NexusEngineTemplate.ALL_TEMPLATES.find { it.engineType == NexusEngineType.AUTO_REPAIR }
        val prompt = template?.promptTemplate?.invoke(stackTrace) ?: "Analiza este crash: $stackTrace"
        
        // Use a short delay so the UI can settle if it's right at startup
        viewModelScope.launch {
            kotlinx.coroutines.delay(1000)
            if (_uiState.value.currentSession == null) {
                createNewSession()
                kotlinx.coroutines.delay(500)
            }
            sendMessage(prompt)
        }
    }

    fun sendMessage(prompt: String) {
        val trimmed = prompt.trim()
        if (trimmed.isBlank() || _uiState.value.isLoading) return

        val session = _uiState.value.currentSession ?: return

        val lower = trimmed.lowercase(java.util.Locale.getDefault())
        val isDeviceQuery = lower.contains("dispositivo") || lower.contains("device") ||
                lower.contains("batería") || lower.contains("bateria") ||
                lower.contains("memoria ram") || lower.contains("ram") ||
                lower.contains("almacenamiento") || lower.contains("hardware") ||
                lower.contains("teléfono") || lower.contains("telefono") ||
                lower.contains("celular") || lower.contains("telemetría") ||
                lower.contains("telemetria")

        val deviceContext = if (isDeviceQuery) deviceManager.getFormattedDeviceContextForAi() else null

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            val result = repository.sendMessage(
                sessionId = session.id,
                userPrompt = trimmed,
                persona = _uiState.value.selectedPersona,
                modelName = _uiState.value.currentModel,
                customApiKey = _uiState.value.customApiKey,
                temperature = _uiState.value.temperature,
                isAutonomousLearningEnabled = _uiState.value.isAutonomousLearningEnabled,
                deviceContext = deviceContext
            )

            result.onFailure { error ->
                _uiState.value = _uiState.value.copy(errorMessage = error.localizedMessage)
            }

            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    fun saveRealtimeMessage(role: String, content: String) {
        val session = _uiState.value.currentSession ?: return
        val normalizedRole = if (role == "user") "user" else "model"
        viewModelScope.launch {
            repository.saveRealtimeMessage(
                sessionId = session.id,
                role = normalizedRole,
                content = content
            )
        }
    }

    fun regenerateLastResponse() {
        val messages = _uiState.value.messages
        if (messages.isEmpty() || _uiState.value.isLoading) return

        val lastUserMessage = messages.lastOrNull { it.role == "user" } ?: return
        val lastAssistantMessage = messages.lastOrNull { it.role == "model" }

        viewModelScope.launch {
            if (lastAssistantMessage != null) {
                database.chatDao().deleteMessageById(lastAssistantMessage.id)
            }
            sendMessage(lastUserMessage.content)
        }
    }

    fun speakMessage(message: ChatMessageEntity) {
        speechManager.speak(message.content, message.id)
    }

    fun stopSpeaking() {
        speechManager.stop()
    }

    fun updateModel(model: String) {
        _uiState.value = _uiState.value.copy(currentModel = model)
        val currentSession = _uiState.value.currentSession
        if (currentSession != null) {
            viewModelScope.launch {
                repository.updateSession(currentSession.copy(modelName = model))
            }
        }
    }

    fun updateApiKey(key: String) {
        _uiState.value = _uiState.value.copy(customApiKey = key)
    }

    fun updateTemperature(temp: Float) {
        _uiState.value = _uiState.value.copy(temperature = temp)
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(
            searchQuery = query,
            filteredSessions = filterSessions(_uiState.value.sessions, query)
        )
    }

    fun toggleAutonomousLearning(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isAutonomousLearningEnabled = enabled)
    }

    fun toggleMemoryActive(memoryId: String) {
        viewModelScope.launch {
            repository.toggleMemoryActive(memoryId)
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            repository.deleteMemory(memoryId)
        }
    }

    fun addManualMemory(content: String, category: com.example.data.model.MemoryCategory) {
        viewModelScope.launch {
            repository.addManualMemory(content, category)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            repository.clearAllMemories()
        }
    }

    fun recordMessageFeedback(
        messageId: String,
        feedback: Int,
        note: String? = null,
        originalPrompt: String? = null
    ) {
        viewModelScope.launch {
            repository.recordFeedback(messageId, feedback, note, originalPrompt)
        }
    }

    fun executeTool(prompt: String) {
        sendMessage(prompt)
    }

    fun testApiConnection() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(apiConnectionStatus = ApiConnectionStatus.Testing)
            val status = repository.testApiConnection(
                customApiKey = _uiState.value.customApiKey,
                modelName = _uiState.value.currentModel
            )
            _uiState.value = _uiState.value.copy(apiConnectionStatus = status)
        }
    }

    fun resetApiConnectionStatus() {
        _uiState.value = _uiState.value.copy(apiConnectionStatus = ApiConnectionStatus.Idle)
    }

    fun clearAllChats() {
        viewModelScope.launch {
            speechManager.stop()
            database.chatDao().deleteAllSessions()
            createNewSession()
        }
    }

    private fun filterSessions(sessions: List<ChatSessionEntity>, query: String): List<ChatSessionEntity> {
        if (query.isBlank()) return sessions
        return sessions.filter { it.title.contains(query, ignoreCase = true) }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.destroy()
    }
}

