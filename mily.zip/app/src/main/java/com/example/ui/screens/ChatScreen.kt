package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.MilyRealtimeClient
import com.example.data.model.ChatMessageEntity
import com.example.data.model.Persona
import com.example.ui.components.AudioWaveIndicator
import com.example.ui.components.CorrectionFeedbackDialog
import com.example.ui.components.DeviceSystemSheet
import com.example.ui.components.MarkdownText
import com.example.ui.components.MemoryHubSheet
import com.example.ui.components.NexusEnginesHubSheet
import com.example.ui.components.PersonaSelectorSheet
import com.example.ui.components.QuickPromptChips
import com.example.ui.components.SettingsSheet
import com.example.ui.components.ThinkingIndicator
import com.example.ui.components.ToolsHubSheet
import com.example.ui.components.VoiceSettingsSheet
import com.example.ui.components.getPersonaIcon
import com.example.ui.theme.AssistantCardDark
import com.example.ui.theme.AssistantCardLight
import com.example.ui.theme.GlowingCyan
import com.example.ui.theme.GlowingViolet
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    realtimeState: MilyRealtimeClient.State = MilyRealtimeClient.State.IDLE,
    realtimeTranscript: String = "",
    onToggleRealtime: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    var inputText by remember { mutableStateOf("") }
    var showPersonaSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showToolsSheet by remember { mutableStateOf(false) }
    var showMemorySheet by remember { mutableStateOf(false) }
    var showNexusEnginesSheet by remember { mutableStateOf(false) }
    var showVoiceSettingsSheet by remember { mutableStateOf(false) }
    var showDeviceSheet by remember { mutableStateOf(false) }
    var feedbackMessageToCorrect by remember { mutableStateOf<ChatMessageEntity?>(null) }
    var showMenu by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    // Voice recognition launcher
    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                inputText = spokenText
            }
        }
    }

    // Auto-scroll on new message
    LaunchedEffect(uiState.messages.size, uiState.isLoading) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ChatDrawerContent(
                sessions = uiState.filteredSessions,
                currentSessionId = uiState.currentSession?.id,
                searchQuery = uiState.searchQuery,
                activeMemoriesCount = uiState.activeMemoriesCount,
                onSearchChange = { viewModel.updateSearchQuery(it) },
                onSessionSelected = { sessionId ->
                    viewModel.selectSession(sessionId)
                    coroutineScope.launch { drawerState.close() }
                },
                onNewChatClick = {
                    viewModel.createNewSession()
                    coroutineScope.launch { drawerState.close() }
                },
                onTogglePin = { viewModel.togglePinSession(it) },
                onDeleteSession = { viewModel.deleteSession(it) },
                onOpenMemory = {
                    showMemorySheet = true
                    coroutineScope.launch { drawerState.close() }
                },
                onOpenTools = {
                    showToolsSheet = true
                    coroutineScope.launch { drawerState.close() }
                },
                onOpenNexusEngines = {
                    showNexusEnginesSheet = true
                    coroutineScope.launch { drawerState.close() }
                },
                onOpenSettings = {
                    showSettingsSheet = true
                    coroutineScope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
        ) {
            if (realtimeState != MilyRealtimeClient.State.IDLE) {
                Card(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp, start = 16.dp, end = 16.dp)
                        .fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.HeadsetMic, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            when (realtimeState) {
                                MilyRealtimeClient.State.CONNECTING -> "Conectando GPT-Live…"
                                MilyRealtimeClient.State.CONNECTED -> "GPT-Live activo"
                                MilyRealtimeClient.State.ERROR -> "Error en GPT-Live"
                                else -> ""
                            },
                            fontWeight = FontWeight.SemiBold
                        )
                        if (realtimeTranscript.isNotBlank()) {
                            Spacer(Modifier.width(10.dp))
                            Text(
                                realtimeTranscript,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { showPersonaSheet = true }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("persona_header_trigger")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = getPersonaIcon(uiState.selectedPersona.iconName),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = uiState.selectedPersona.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Cambiar rol",
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = uiState.currentModel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("drawer_button")
                        ) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Historial")
                        }
                    },
                    actions = {
                        // NEXUS Engines Button
                        IconButton(
                            onClick = { showNexusEnginesSheet = true },
                            modifier = Modifier.testTag("action_nexus_engines")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = "NEXUS Motores",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Voice Engine Settings
                        IconButton(
                            onClick = { showVoiceSettingsSheet = true },
                            modifier = Modifier.testTag("action_voice_settings")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.RecordVoiceOver,
                                contentDescription = "Voice Settings",
                                tint = if (uiState.isSpeaking) GlowingCyan else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Autonomous Learning Memory Button
                        IconButton(
                            onClick = { showMemorySheet = true },
                            modifier = Modifier.testTag("action_memory_hub")
                        ) {
                            Box(contentAlignment = Alignment.TopEnd) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = "Memoria y Aprendizaje",
                                    tint = if (uiState.isAutonomousLearningEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (uiState.activeMemoriesCount > 0) {
                                    Surface(
                                        shape = CircleShape,
                                        color = GlowingCyan,
                                        modifier = Modifier.size(8.dp)
                                    ) {}
                                }
                            }
                        }

                        // AI Tools Hub Button
                        IconButton(
                            onClick = { showToolsSheet = true },
                            modifier = Modifier.testTag("action_tools_hub")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoFixHigh,
                                contentDescription = "Herramientas de IA",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (uiState.isSpeaking) {
                            IconButton(
                                onClick = { viewModel.stopSpeaking() },
                                modifier = Modifier.testTag("stop_speaking_top_button")
                            ) {
                                AudioWaveIndicator(isSpeaking = true, activeColor = MaterialTheme.colorScheme.primary)
                            }
                        }

                        IconButton(
                            onClick = { viewModel.createNewSession() },
                            modifier = Modifier.testTag("action_new_chat")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Nuevo chat")
                        }

                        IconButton(
                            onClick = { showMenu = !showMenu },
                            modifier = Modifier.testTag("more_options_button")
                        ) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Opciones")
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Motores Autónomos NEXUS") },
                                onClick = {
                                    showNexusEnginesSheet = true
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Hub, contentDescription = null)
                                },
                                modifier = Modifier.testTag("menu_nexus_engines")
                            )
                            DropdownMenuItem(
                                text = { Text("Aprendizaje Autónomo") },
                                onClick = {
                                    showMemorySheet = true
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Psychology, contentDescription = null)
                                },
                                modifier = Modifier.testTag("menu_memory")
                            )
                            DropdownMenuItem(
                                text = { Text("Herramientas de IA") },
                                onClick = {
                                    showToolsSheet = true
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.AutoFixHigh, contentDescription = null)
                                },
                                modifier = Modifier.testTag("menu_tools")
                            )
                            DropdownMenuItem(
                                text = { Text("Limpiar conversación") },
                                onClick = {
                                    viewModel.clearCurrentChat()
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.CleaningServices, contentDescription = null)
                                },
                                modifier = Modifier.testTag("menu_clear_chat")
                            )
                            DropdownMenuItem(
                                text = { Text("Roles del Asistente") },
                                onClick = {
                                    showPersonaSheet = true
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                                },
                                modifier = Modifier.testTag("menu_personas")
                            )
                            DropdownMenuItem(
                                text = { Text("Ajustes") },
                                onClick = {
                                    showSettingsSheet = true
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Settings, contentDescription = null)
                                },
                                modifier = Modifier.testTag("menu_settings")
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                ) {
                    // Quick Prompt Suggestion Chips
                    QuickPromptChips(
                        onPromptSelected = { selectedPrompt ->
                            if (selectedPrompt == "🛠️ Herramientas de IA") {
                                showToolsSheet = true
                            } else if (selectedPrompt == "🧠 Ver Memoria") {
                                showMemorySheet = true
                            } else {
                                inputText = selectedPrompt
                            }
                        }
                    )

                    // Input Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        // Shortcut to Open Tools Suite
                        IconButton(
                            onClick = { showToolsSheet = true },
                            modifier = Modifier
                                .padding(bottom = 4.dp)
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .testTag("open_tools_bottom_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoFixHigh,
                                contentDescription = "Herramientas",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 52.dp, max = 140.dp)
                                .testTag("message_input_field"),
                            placeholder = {
                                Text(
                                    text = "Pregúntale a ${uiState.selectedPersona.name}…",
                                    fontSize = 14.sp
                                )
                            },
                            trailingIcon = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora...")
                                            }
                                            try {
                                                voiceLauncher.launch(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Entrada por voz no disponible en este dispositivo", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.testTag("voice_input_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Mic,
                                            contentDescription = "Dictado",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(
                                        onClick = onToggleRealtime,
                                        modifier = Modifier.testTag("gpt_live_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.HeadsetMic,
                                            contentDescription = if (realtimeState == MilyRealtimeClient.State.CONNECTED) "Desconectar GPT-Live" else "Conectar GPT-Live",
                                            tint = if (realtimeState == MilyRealtimeClient.State.CONNECTED) GlowingCyan else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                focusedBorderColor = GlowingCyan,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            ),
                            maxLines = 5
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        FloatingActionButton(
                            onClick = {
                                if (inputText.isNotBlank() && !uiState.isLoading) {
                                    val textToSend = inputText
                                    inputText = ""
                                    viewModel.sendMessage(textToSend)
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("send_message_button"),
                            shape = CircleShape,
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            elevation = FloatingActionButtonDefaults.elevation(2.dp)
                        ) {
                            if (uiState.isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Enviar",
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (uiState.messages.isEmpty() && !uiState.isLoading) {
                    // Welcoming Hero Screen
                    WelcomeScreen(
                        persona = uiState.selectedPersona,
                        onSamplePromptClick = { prompt ->
                            viewModel.sendMessage(prompt)
                        },
                        onOpenTools = { showToolsSheet = true },
                        onOpenMemory = { showMemorySheet = true },
                        onOpenNexusEngines = { showNexusEnginesSheet = true }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(vertical = 16.dp)
                    ) {
                        items(uiState.messages, key = { it.id }) { message ->
                            MessageItem(
                                message = message,
                                persona = uiState.selectedPersona,
                                isSpeaking = uiState.isSpeaking && uiState.speakingMessageId == message.id,
                                onSpeak = { viewModel.speakMessage(message) },
                                onStopSpeaking = { viewModel.stopSpeaking() },
                                onRegenerate = { viewModel.regenerateLastResponse() },
                                onPositiveFeedback = {
                                    viewModel.recordMessageFeedback(message.id, 1)
                                    Toast.makeText(context, "¡Gracias! El asistente ha registrado tu aprobación.", Toast.LENGTH_SHORT).show()
                                },
                                onNegativeFeedback = {
                                    feedbackMessageToCorrect = message
                                }
                            )
                        }

                        if (uiState.isLoading) {
                            item {
                                ThinkingCard(persona = uiState.selectedPersona)
                            }
                        }
                    }
                }
            }
        }
        }
    }

    // Persona Selector Sheet
    if (showPersonaSheet) {
        PersonaSelectorSheet(
            selectedPersonaId = uiState.selectedPersona.id,
            onPersonaSelected = { viewModel.selectPersona(it) },
            onDismiss = { showPersonaSheet = false }
        )
    }

    // Tools Hub Sheet
    if (showToolsSheet) {
        ToolsHubSheet(
            onToolExecute = { toolPrompt ->
                viewModel.executeTool(toolPrompt)
            },
            onDismiss = { showToolsSheet = false }
        )
    }

    // Memory & Learning Hub Sheet
    if (showMemorySheet) {
        MemoryHubSheet(
            memories = uiState.memories,
            isAutonomousLearningEnabled = uiState.isAutonomousLearningEnabled,
            onToggleAutonomousLearning = { viewModel.toggleAutonomousLearning(it) },
            onToggleMemoryActive = { viewModel.toggleMemoryActive(it) },
            onDeleteMemory = { viewModel.deleteMemory(it) },
            onAddManualMemory = { content, category ->
                viewModel.addManualMemory(content, category)
            },
            onClearAllMemories = { viewModel.clearAllMemories() },
            onDismiss = { showMemorySheet = false }
        )
    }

    // Voice Settings Sheet
    if (showVoiceSettingsSheet) {
        VoiceSettingsSheet(
            speechManager = viewModel.speechManager,
            onDismiss = { showVoiceSettingsSheet = false }
        )
    }

    // Correction Feedback Dialog
    if (feedbackMessageToCorrect != null) {
        val msg = feedbackMessageToCorrect!!
        CorrectionFeedbackDialog(
            originalPrompt = msg.content,
            onConfirmFeedback = { feedback, note ->
                viewModel.recordMessageFeedback(
                    messageId = msg.id,
                    feedback = feedback,
                    note = note,
                    originalPrompt = msg.content
                )
                Toast.makeText(context, "Aprendizaje registrado. Las futuras respuestas se adaptarán.", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { feedbackMessageToCorrect = null }
        )
    }

    // Nexus Engines Hub Sheet
    if (showNexusEnginesSheet) {
        NexusEnginesHubSheet(
            onDismiss = { showNexusEnginesSheet = false },
            onExecutePrompt = { prompt ->
                viewModel.sendMessage(prompt)
            },
            activeMemoriesCount = uiState.activeMemoriesCount,
            totalSessionsCount = uiState.sessions.size,
            currentModel = uiState.currentModel
        )
    }

    // Settings Sheet
    if (showSettingsSheet) {
        SettingsSheet(
            currentModel = uiState.currentModel,
            onModelChange = { viewModel.updateModel(it) },
            apiKey = uiState.customApiKey,
            onApiKeyChange = { viewModel.updateApiKey(it) },
            temperature = uiState.temperature,
            onTemperatureChange = { viewModel.updateTemperature(it) },
            onClearAllChats = { viewModel.clearAllChats() },
            apiConnectionStatus = uiState.apiConnectionStatus,
            onTestApiConnection = { viewModel.testApiConnection() },
            onDismiss = {
                showSettingsSheet = false
                viewModel.resetApiConnectionStatus()
            }
        )
    }
}

@Composable
fun WelcomeScreen(
    persona: Persona,
    onSamplePromptClick: (String) -> Unit,
    onOpenTools: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenNexusEngines: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Glowing Hero Icon
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(GlowingCyan, GlowingViolet)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = getPersonaIcon(persona.iconName),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "¡Hola! Soy tu ${persona.name}",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "${persona.description} Con aprendizaje autónomo y motores NEXUS.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Feature Badges
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                modifier = Modifier.clickable { onOpenNexusEngines() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Hub,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Motores M81-83",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                modifier = Modifier.clickable { onOpenMemory() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Auto-Memoria",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                modifier = Modifier.clickable { onOpenTools() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "7 Herramientas",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Sugerencias para comenzar",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(10.dp))

        persona.samplePrompts.forEachIndexed { index, prompt ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onSamplePromptClick(prompt) }
                    .testTag("welcome_prompt_sample_$index"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MessageItem(
    message: ChatMessageEntity,
    persona: Persona,
    isSpeaking: Boolean,
    onSpeak: () -> Unit,
    onStopSpeaking: () -> Unit,
    onRegenerate: () -> Unit,
    onPositiveFeedback: () -> Unit,
    onNegativeFeedback: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val context = LocalContext.current
    val timeFormatted = remember(message.timestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
    }

    if (isUser) {
        // User Message Bubble (Right aligned)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .testTag("user_message_${message.id}"),
            horizontalArrangement = Arrangement.End
        ) {
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.fillMaxWidth(0.85f)
            ) {
                Surface(
                    shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f)
                                )
                            ),
                            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp)
                        )
                        .shadow(
                            elevation = 8.dp,
                            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp),
                            spotColor = MaterialTheme.colorScheme.primary,
                            ambientColor = MaterialTheme.colorScheme.primaryContainer
                        )
                ) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 15.sp,
                            lineHeight = 21.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }

                Text(
                    text = timeFormatted,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, end = 4.dp),
                    fontSize = 11.sp
                )
            }
        }
    } else {
        // Assistant Message Card (Left aligned)
        Row(
            modifier = modifier
                .fillMaxWidth()
                .testTag("assistant_message_${message.id}"),
            horizontalArrangement = Arrangement.Start
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header with Persona Icon & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getPersonaIcon(persona.iconName),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = persona.name,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = timeFormatted,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )

                    if (message.tokenCount > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${message.tokenCount} tokens",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            fontSize = 10.sp
                        )
                    }
                }

                // Assistant Card Content
                Card(
                    shape = RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (message.isError)
                            MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        else
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (message.isError) Brush.linearGradient(listOf(MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.errorContainer))
                        else Brush.linearGradient(listOf(GlowingCyan.copy(alpha = 0.5f), GlowingViolet.copy(alpha = 0.3f), MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)))
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(
                            elevation = if (message.isError) 12.dp else 16.dp,
                            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp),
                            spotColor = if (message.isError) MaterialTheme.colorScheme.error else GlowingCyan,
                            ambientColor = GlowingViolet
                        )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        MarkdownText(
                            markdown = message.content,
                            textColor = MaterialTheme.colorScheme.onSurface
                        )

                        // Action Bar (Speech, Copy, Share, Feedback, Regenerate)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Learning Feedback Buttons (Thumbs up / Thumbs down)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = onPositiveFeedback,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("thumbs_up_button_${message.id}")
                                ) {
                                    Icon(
                                        imageVector = if (message.feedback == 1) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                                        contentDescription = "Me gusta",
                                        tint = if (message.feedback == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.size(15.dp)
                                    )
                                }

                                IconButton(
                                    onClick = onNegativeFeedback,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("thumbs_down_button_${message.id}")
                                ) {
                                    Icon(
                                        imageVector = if (message.feedback == -1) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                                        contentDescription = "Corregir respuesta",
                                        tint = if (message.feedback == -1) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }

                            // Utilities (Speech, Copy, Share, Regenerate)
                            Row(
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Text to Speech
                                IconButton(
                                    onClick = {
                                        if (isSpeaking) onStopSpeaking() else onSpeak()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("speak_button_${message.id}")
                                ) {
                                    if (isSpeaking) {
                                        AudioWaveIndicator(isSpeaking = true)
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.VolumeUp,
                                            contentDescription = "Escuchar",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }

                                // Copy message
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("IA Asistente", message.content)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "Respuesta copiada", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("copy_button_${message.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copiar",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }

                                // Share message
                                IconButton(
                                    onClick = {
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, message.content)
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, "Compartir respuesta"))
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("share_button_${message.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Compartir",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }

                                // Regenerate
                                IconButton(
                                    onClick = onRegenerate,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("regenerate_button_${message.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Regenerar",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ThinkingCard(
    persona: Persona,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = getPersonaIcon(persona.iconName),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(15.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${persona.name} está pensando",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(6.dp))
                ThinkingIndicator()
            }
        }
    }
}
