package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.audio.SpeechManager
import com.example.audio.VoiceOption
import com.example.ui.theme.GlowingCyan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSettingsSheet(
    speechManager: SpeechManager,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val availableVoices by speechManager.availableVoices.collectAsState()
    val currentVoice by speechManager.currentVoice.collectAsState()
    val isSpeaking by speechManager.isSpeaking.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "NEXUS Voice Engine",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            
            Text(
                text = "Síntesis neuronal de voz y fluidez",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Animated Voice Orb
            AIVoiceOrb(
                isSpeaking = isSpeaking,
                modifier = Modifier
                    .padding(vertical = 16.dp)
                    .size(150.dp)
            )
            
            if (!isSpeaking) {
                Text(
                    text = "Selecciona un perfil de voz para escucharlo.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            } else {
                Text(
                    text = "Reproduciendo muestra de audio...",
                    style = MaterialTheme.typography.bodySmall,
                    color = GlowingCyan,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Voice Options List
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(availableVoices) { voiceOption ->
                    VoiceOptionCard(
                        voiceOption = voiceOption,
                        isSelected = currentVoice?.id == voiceOption.id,
                        onClick = {
                            speechManager.setVoice(voiceOption)
                            speechManager.speak(
                                text = "Hola, soy ${voiceOption.id}. Este es mi perfil de voz fluido.",
                                messageId = "sample_${voiceOption.id}"
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun VoiceOptionCard(
    voiceOption: VoiceOption,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isSelected) GlowingCyan.copy(alpha = 0.1f) 
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Outlined.RecordVoiceOver,
            contentDescription = null,
            tint = if (isSelected) GlowingCyan else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(24.dp)
        )
        
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = voiceOption.id,
                style = MaterialTheme.typography.titleMedium,
                color = if (isSelected) GlowingCyan else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = voiceOption.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        if (isSelected) {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = "Selected",
                tint = GlowingCyan,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
