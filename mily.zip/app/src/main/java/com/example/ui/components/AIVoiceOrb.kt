package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlowingCyan
import com.example.ui.theme.GlowingViolet

@Composable
fun AIVoiceOrb(
    isSpeaking: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    
    // Core pulsing scale
    val scale by infiniteTransition.animateFloat(
        initialValue = if (isSpeaking) 0.8f else 0.95f,
        targetValue = if (isSpeaking) 1.2f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking) 400 else 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    
    // Outer aura scale
    val auraScale by infiniteTransition.animateFloat(
        initialValue = if (isSpeaking) 1.0f else 1.0f,
        targetValue = if (isSpeaking) 1.6f else 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking) 600 else 3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraScale"
    )
    
    // Rotation for fluid gradient
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking) 2000 else 8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val primary = GlowingCyan
    val secondary = GlowingViolet
    val surface = MaterialTheme.colorScheme.surface

    Box(modifier = modifier.size(120.dp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val baseRadius = size.width / 3
            
            // Outer Aura
            if (isSpeaking) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(primary.copy(alpha = 0.3f), Color.Transparent),
                        center = center,
                        radius = baseRadius * auraScale
                    ),
                    radius = baseRadius * auraScale,
                    center = center,
                    blendMode = BlendMode.Screen
                )
            }
            
            // Core Orb
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(primary, secondary, primary),
                    center = center
                ),
                radius = baseRadius * scale,
                center = center,
                alpha = if (isSpeaking) 0.9f else 0.4f
            )
            
            // Inner Surface Cutout
            drawCircle(
                color = surface,
                radius = (baseRadius * scale) * 0.7f,
                center = center
            )
            
            // Core Light
            drawCircle(
                color = if (isSpeaking) primary else secondary.copy(alpha = 0.5f),
                radius = (baseRadius * scale) * 0.4f,
                center = center
            )
        }
    }
}
