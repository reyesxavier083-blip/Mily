package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp

data class QuickPrompt(
    val title: String,
    val prompt: String,
    val icon: ImageVector
)

val DEFAULT_QUICK_PROMPTS = listOf(
    QuickPrompt("📱 Diagnóstico celular", "Por favor revisa y analiza la telemetría de mi dispositivo, batería, RAM y almacenamiento:", Icons.Default.PhoneAndroid),
    QuickPrompt("💡 Explicar concepto", "Explícame este concepto de forma clara, con un ejemplo cotidiano y puntos clave: ", Icons.Default.Lightbulb),
    QuickPrompt("💻 Escribir código", "Escribe una implementación en Kotlin limpia, robusta y con comentarios para: ", Icons.Default.Code),
    QuickPrompt("📑 Resumir texto", "Resume el siguiente texto en 3 puntos clave y una conclusión breve:\n\n", Icons.Default.Summarize),
    QuickPrompt("✉️ Redactar correo", "Redacta un correo formal, profesional y directo para: ", Icons.Default.Create),
    QuickPrompt("🎓 Plan de estudio", "Crea un temario y plan de estudio de 5 días para aprender: ", Icons.Default.School),
    QuickPrompt("✨ Mejorar redacción", "Reescribe y optimiza el siguiente texto mejorando su vocabulario y coherencia:\n\n", Icons.Default.AutoAwesome)
)

@Composable
fun QuickPromptChips(
    onPromptSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        DEFAULT_QUICK_PROMPTS.forEachIndexed { index, item ->
            AssistChip(
                onClick = { onPromptSelected(item.prompt) },
                label = { Text(item.title, style = MaterialTheme.typography.labelMedium) },
                leadingIcon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag("quick_prompt_chip_$index")
            )
        }
    }
}
