package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlowingCyan
import com.example.ui.theme.GlowingViolet

@Composable
fun SimulationNodeGraph(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "NodeGraphAnimation")
    
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "phase"
    )

    val pulse by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    val primaryColor = GlowingCyan
    val secondaryColor = GlowingViolet
    val tertiaryColor = Color(0xFF00E5FF)
    val surfaceColor = MaterialTheme.colorScheme.surface
    
    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            
            // Define node layers
            val startNode = Offset(width * 0.1f, height * 0.5f)
            
            val hiddenNodes1 = listOf(
                Offset(width * 0.4f, height * 0.2f),
                Offset(width * 0.4f, height * 0.5f),
                Offset(width * 0.4f, height * 0.8f)
            )
            
            val hiddenNodes2 = listOf(
                Offset(width * 0.7f, height * 0.35f),
                Offset(width * 0.7f, height * 0.65f)
            )
            
            val endNode = Offset(width * 0.9f, height * 0.5f)
            
            // Draw Edges
            val allEdges = mutableListOf<Pair<Offset, Offset>>()
            hiddenNodes1.forEach { node -> allEdges.add(startNode to node) }
            hiddenNodes1.forEach { node1 -> 
                hiddenNodes2.forEach { node2 -> allEdges.add(node1 to node2) }
            }
            hiddenNodes2.forEach { node -> allEdges.add(node to endNode) }
            
            val strokeWidth = 2.dp.toPx()
            
            allEdges.forEachIndexed { index, (start, end) ->
                // Draw base edge
                val path = Path().apply {
                    moveTo(start.x, start.y)
                    cubicTo(
                        start.x + (end.x - start.x) / 2, start.y,
                        start.x + (end.x - start.x) / 2, end.y,
                        end.x, end.y
                    )
                }
                drawPath(
                    path = path,
                    color = primaryColor.copy(alpha = 0.15f),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
                
                // Draw animated pulse along edge
                val delayOffset = (index % 3) * 0.3f
                var localPulse = pulse - delayOffset
                if (localPulse < 0) localPulse += 1f
                
                val pulseX = start.x + (end.x - start.x) * localPulse
                
                val t = localPulse
                val invT = 1f - t
                val p0y = start.y
                val p1y = start.y
                val p2y = end.y
                val p3y = end.y
                val pulseY = (invT * invT * invT * p0y) + 
                             (3f * invT * invT * t * p1y) + 
                             (3f * invT * t * t * p2y) + 
                             (t * t * t * p3y)
                             
                drawCircle(
                    color = tertiaryColor.copy(alpha = (1f - localPulse) * 0.8f),
                    radius = 3.dp.toPx() + (localPulse * 2.dp.toPx()),
                    center = Offset(pulseX, pulseY)
                )
            }
            
            // Draw Nodes
            val baseNodeRadius = 6.dp.toPx()
            val activeNodeRadius = baseNodeRadius * (1f + phase * 0.4f)
            
            // Start Node
            drawCircle(color = primaryColor, radius = activeNodeRadius, center = startNode)
            drawCircle(color = surfaceColor, radius = baseNodeRadius * 0.5f, center = startNode)
            
            // Hidden Nodes
            hiddenNodes1.forEachIndexed { index, node ->
                val radius = if (index == 1) activeNodeRadius else baseNodeRadius
                val color = if (index == 1) secondaryColor else primaryColor.copy(alpha = 0.5f)
                drawCircle(color = color, radius = radius, center = node)
            }
            
            hiddenNodes2.forEachIndexed { index, node ->
                 drawCircle(color = tertiaryColor.copy(alpha = 0.7f), radius = baseNodeRadius, center = node)
            }
            
            // End Node
            drawCircle(color = secondaryColor, radius = activeNodeRadius, center = endNode)
            drawCircle(color = surfaceColor, radius = baseNodeRadius * 0.5f, center = endNode)
        }
    }
}
