package com.example.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class SpeechManager(context: Context) {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentMessageId = MutableStateFlow<String?>(null)
    val currentMessageId: StateFlow<String?> = _currentMessageId.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<VoiceOption>> = _availableVoices.asStateFlow()
    
    private val _currentVoice = MutableStateFlow<VoiceOption?>(null)
    val currentVoice: StateFlow<VoiceOption?> = _currentVoice.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                val spanishLocale = Locale("es", "ES")
                val result = tts?.setLanguage(spanishLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
                tts?.setSpeechRate(1.05f) // Slightly faster for fluidity
                tts?.setPitch(1.0f)
                
                loadBetterVoices()
            } else {
                Log.e("SpeechManager", "TTS initialization failed with status $status")
            }
        }

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
                _currentMessageId.value = utteranceId
            }

            override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
                _currentMessageId.value = null
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
                _currentMessageId.value = null
            }
        })
    }
    
    private fun loadBetterVoices() {
        try {
            val voices = tts?.voices ?: return
            
            // Filter Spanish voices
            val esVoices = voices.filter { it.locale.language == "es" }
            
            val options = mutableListOf<VoiceOption>()
            
            // Find network voices if available (they sound much better)
            val premiumFemale = esVoices.find { it.name.contains("es-es-x-sfd-network", ignoreCase = true) || it.name.contains("es-ES-language", ignoreCase = true) && it.name.contains("network") }
            val premiumMale = esVoices.find { it.name.contains("es-es-x-sfc-network", ignoreCase = true) || it.name.contains("es-US") && it.name.contains("network") }
            
            // Add custom options mapping to Android voices
            options.add(VoiceOption("NEXUS Nova", "Voz fluida femenina (Premium)", premiumFemale ?: esVoices.firstOrNull { !it.name.contains("male", ignoreCase = true) }, 1.05f, 1.05f))
            options.add(VoiceOption("NEXUS Orion", "Voz fluida masculina (Premium)", premiumMale ?: esVoices.firstOrNull { it.name.contains("male", ignoreCase = true) }, 1.05f, 0.95f))
            options.add(VoiceOption("NEXUS Echo", "Voz robótica IA", esVoices.firstOrNull(), 1.0f, 0.7f))
            
            val validOptions = options.filter { it.voice != null }
            if (validOptions.isNotEmpty()) {
                _availableVoices.value = validOptions
                setVoice(validOptions.first())
            }
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error loading voices: \${e.message}")
        }
    }
    
    fun setVoice(option: VoiceOption) {
        if (!isInitialized) return
        option.voice?.let { 
            tts?.voice = it
            tts?.setSpeechRate(option.rate)
            tts?.setPitch(option.pitch)
            _currentVoice.value = option
        }
    }

    fun speak(text: String, messageId: String) {
        if (!isInitialized || tts == null) return

        if (_isSpeaking.value && _currentMessageId.value == messageId) {
            stop()
            return
        }

        stop()
        val cleanText = sanitizeTextForSpeech(text)
        _currentMessageId.value = messageId
        tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, messageId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _currentMessageId.value = null
    }

    fun destroy() {
        stop()
        tts?.shutdown()
        tts = null
    }

    private fun sanitizeTextForSpeech(text: String): String {
        return text
            // Remove code blocks
            .replace(Regex("```[\\s\\S]*?```"), " Bloque de código omitido. ")
            // Remove inline code
            .replace(Regex("`([^`]+)`"), "$1")
            // Remove markdown bold/italics
            .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
            .replace(Regex("\\*([^*]+)\\*"), "$1")
            .replace(Regex("#+\\s*"), "")
            // Remove bullet points
            .replace(Regex("^[-*•]\\s+", RegexOption.MULTILINE), "")
            // Remove link urls
            .replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1")
            .trim()
    }
}

data class VoiceOption(
    val id: String,
    val description: String,
    val voice: Voice?,
    val rate: Float = 1.0f,
    val pitch: Float = 1.0f
)
