package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.data.ai.MilyRealtimeClient
import com.example.ui.screens.ChatScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.CrashHandler

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()
    private lateinit var realtimeClient: MilyRealtimeClient
    private val realtimeState = mutableStateOf(MilyRealtimeClient.State.IDLE)
    private val realtimeTranscript = mutableStateOf("")

    private val microphonePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRealtime()
        else realtimeState.value = MilyRealtimeClient.State.ERROR
    }

    private fun toggleRealtime() {
        if (realtimeState.value == MilyRealtimeClient.State.CONNECTED ||
            realtimeState.value == MilyRealtimeClient.State.CONNECTING) {
            realtimeClient.disconnect()
            realtimeState.value = MilyRealtimeClient.State.IDLE
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            startRealtime()
        }
    }

    private fun startRealtime() {
        realtimeClient.connect { state -> runOnUiThread { realtimeState.value = state } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        realtimeClient = MilyRealtimeClient(this, BuildConfig.MILY_BACKEND_URL)
        realtimeClient.setEventListener { event ->
            runOnUiThread {
                if (!event.text.isNullOrBlank()) realtimeTranscript.value = event.text
                if (event.isFinal && !event.text.isNullOrBlank() && event.role != null) {
                    viewModel.saveRealtimeMessage(event.role, event.text)
                }
            }
        }

        // Inicializar el manejador de fallas
        CrashHandler.init(application)
        
        // Verificar si hubo una falla en la sesión anterior
        val lastCrash = CrashHandler.getLastCrash(this)
        if (lastCrash != null) {
            viewModel.triggerAutoRepair(lastCrash)
        }
        
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ChatScreen(
                        viewModel = viewModel,
                        realtimeState = realtimeState.value,
                        realtimeTranscript = realtimeTranscript.value,
                        onToggleRealtime = ::toggleRealtime
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        if (::realtimeClient.isInitialized) realtimeClient.disconnect()
        super.onDestroy()
    }
}

