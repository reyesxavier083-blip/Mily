package com.example.data.mily.knowledge

import retrofit2.http.Body
import retrofit2.http.POST

interface MilyKnowledgeService {
    @POST("v1/mily/knowledge/vector-stores")
    suspend fun createVectorStore(@Body request: VectorStoreRequest): Map<String, Any?>

    @POST("v1/mily/knowledge/search")
    suspend fun search(@Body request: KnowledgeSearchRequest): KnowledgeSearchResponse
}
