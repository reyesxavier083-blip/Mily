package com.example.data.mily.openai

/** Central capability registry for Mily's OpenAI integration.
 *  It deliberately describes capabilities rather than hard-coding model names.
 */
object OpenAiFeatureRegistry {
    val supported = setOf(
        OpenAiCapability.RESPONSES,
        OpenAiCapability.CONVERSATIONS,
        OpenAiCapability.PROMPTS,
        OpenAiCapability.STREAMING,
        OpenAiCapability.REALTIME,
        OpenAiCapability.FILE_SEARCH,
        OpenAiCapability.WEB_SEARCH,
        OpenAiCapability.CODE_INTERPRETER,
        OpenAiCapability.FUNCTION_CALLING,
        OpenAiCapability.TOOL_SEARCH,
        OpenAiCapability.REMOTE_MCP,
        OpenAiCapability.STRUCTURED_OUTPUTS,
        OpenAiCapability.IMAGE_INPUT,
        OpenAiCapability.AUDIO_INPUT,
        OpenAiCapability.IMAGE_GENERATION,
        OpenAiCapability.SPEECH,
        OpenAiCapability.TRANSCRIPTION,
        OpenAiCapability.TRANSLATION,
        OpenAiCapability.MODERATION,
        OpenAiCapability.EMBEDDINGS,
        OpenAiCapability.BACKGROUND_RESPONSES,
        OpenAiCapability.CONTEXT_MANAGEMENT,
        OpenAiCapability.EVALS,
        OpenAiCapability.VECTOR_STORES,
        OpenAiCapability.FILES,
        OpenAiCapability.ADMIN_AUDIT
    )

    fun isSupported(capability: OpenAiCapability): Boolean = capability in supported
}
