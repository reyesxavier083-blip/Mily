package com.example.data.ai

/** Provider-neutral contract used by Mily's conversation layer. */
interface AiProvider {
    suspend fun generate(request: AiRequest): Result<AiResponse>
}

data class AiRequest(
    val model: String,
    val systemPrompt: String,
    val history: List<AiMessage>,
    val temperature: Float = 0.7f,
    val maxOutputTokens: Int = 2048,
    val memoryFacts: List<String> = emptyList(),
    val enableFileSearch: Boolean = true,
    val maxFileSearchResults: Int = 6
)

data class AiMessage(
    val role: String,
    val content: String
)

data class AiResponse(
    val text: String,
    val tokenCount: Int = 0
)
