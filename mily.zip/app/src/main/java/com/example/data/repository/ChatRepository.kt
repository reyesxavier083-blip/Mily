package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.ai.AiMessage
import com.example.data.ai.AiRequest
import com.example.data.ai.OpenAiBackendProvider
import com.example.data.learning.AutonomousLearningEngine
import com.example.data.local.ChatDao
import com.example.data.local.EpisodicMemoryDao
import com.example.data.local.MemoryDao
import com.example.data.local.SemanticMemoryDao
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatSessionEntity
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryEntity
import com.example.data.model.Persona
import com.example.data.remote.ApiConnectionStatus
import com.example.data.remote.GeminiApiClient
import com.example.data.remote.GeminiContent
import com.example.data.remote.GeminiGenerationConfig
import com.example.data.remote.GeminiPart
import com.example.data.remote.GeminiRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatRepository(
    private val chatDao: ChatDao,
    val memoryDao: MemoryDao,
    val episodicDao: EpisodicMemoryDao? = null,
    val semanticDao: SemanticMemoryDao? = null
) {
    val allSessions: Flow<List<ChatSessionEntity>> = chatDao.getAllSessions()
    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()
    val activeMemoriesCount: Flow<Int> = memoryDao.getActiveMemoriesCount()

    val learningEngine = AutonomousLearningEngine(memoryDao, episodicDao, semanticDao)
    private val repositoryScope = CoroutineScope(Dispatchers.IO)
    private val openAiProvider = OpenAiBackendProvider()

    fun getMessages(sessionId: String): Flow<List<ChatMessageEntity>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createNewSession(
        personaId: String = Persona.ID_GENERAL,
        modelName: String = "gpt-6-astra",
        customTitle: String? = null
    ): ChatSessionEntity = withContext(Dispatchers.IO) {
        val persona = Persona.getById(personaId)
        val title = customTitle ?: "Chat con ${persona.name}"
        val session = ChatSessionEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            personaId = personaId,
            modelName = modelName,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        chatDao.insertSession(session)
        session
    }

    suspend fun getSession(sessionId: String): ChatSessionEntity? = withContext(Dispatchers.IO) {
        chatDao.getSessionById(sessionId)
    }

    suspend fun updateSession(session: ChatSessionEntity) = withContext(Dispatchers.IO) {
        chatDao.updateSession(session)
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun togglePin(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.togglePinSession(sessionId)
    }

    suspend fun clearSessionMessages(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForSession(sessionId)
    }

    suspend fun saveMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        chatDao.insertMessage(message)
        val session = chatDao.getSessionById(message.sessionId)
        if (session != null) {
            chatDao.updateSession(session.copy(updatedAt = System.currentTimeMillis()))
        }
    }


    suspend fun saveRealtimeMessage(
        sessionId: String,
        role: String,
        content: String,
        timestamp: Long = System.currentTimeMillis()
    ): ChatMessageEntity? = withContext(Dispatchers.IO) {
        val normalized = content.trim()
        if (normalized.isBlank()) return@withContext null

        // Avoid inserting an identical final transcript twice when the Live client
        // emits both an audio-transcript and text completion event.
        val recent = chatDao.getMessagesForSessionList(sessionId).takeLast(4)
        val duplicate = recent.any {
            it.role == role && it.content.trim() == normalized
        }
        if (duplicate) return@withContext null

        val message = ChatMessageEntity(
            sessionId = sessionId,
            role = role,
            content = normalized,
            timestamp = timestamp
        )
        saveMessage(message)
        message
    }

    suspend fun recordFeedback(
        messageId: String,
        feedback: Int,
        note: String? = null,
        originalPrompt: String? = null
    ) = withContext(Dispatchers.IO) {
        chatDao.updateMessageFeedback(messageId, feedback, note)
        if (!note.isNullOrBlank() && !originalPrompt.isNullOrBlank()) {
            learningEngine.recordCorrection(originalPrompt, note)
        }
    }

    suspend fun addManualMemory(
        content: String,
        category: MemoryCategory
    ) = withContext(Dispatchers.IO) {
        val memory = MemoryEntity(
            category = category.name,
            content = content.trim(),
            confidence = 1.0f
        )
        memoryDao.insertMemory(memory)
    }

    suspend fun deleteMemory(memoryId: String) = withContext(Dispatchers.IO) {
        memoryDao.deleteMemory(memoryId)
    }

    suspend fun toggleMemoryActive(memoryId: String) = withContext(Dispatchers.IO) {
        memoryDao.toggleMemoryActive(memoryId)
    }

    suspend fun clearAllMemories() = withContext(Dispatchers.IO) {
        memoryDao.deleteAllMemories()
    }

    suspend fun sendMessage(
        sessionId: String,
        userPrompt: String,
        persona: Persona,
        modelName: String = "gpt-6-astra",
        customApiKey: String? = null,
        temperature: Float = 0.7f,
        isAutonomousLearningEnabled: Boolean = true,
        deviceContext: String? = null
    ): Result<ChatMessageEntity> = withContext(Dispatchers.IO) {
        // 1. Save user message to database
        val userMessage = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            sessionId = sessionId,
            role = "user",
            content = userPrompt.trim(),
            timestamp = System.currentTimeMillis()
        )
        chatDao.insertMessage(userMessage)

        // 2. Auto-generate title if this is the first interaction in the session
        val currentHistory = chatDao.getMessagesForSessionList(sessionId)
        val session = chatDao.getSessionById(sessionId)
        if (session != null && (session.title.startsWith("Nueva ") || session.title.startsWith("Chat con "))) {
            val generatedTitle = makeBriefTitle(userPrompt)
            chatDao.updateSession(session.copy(title = generatedTitle, updatedAt = System.currentTimeMillis()))
        }

        // 3. Resolve API Key
        val apiKey = when {
            !customApiKey.isNullOrBlank() -> customApiKey.trim()
            BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY" -> BuildConfig.GEMINI_API_KEY
            else -> ""
        }

        // 4. Autonomous Learning & System Prompt Enrichment
        val enrichedSystemPrompt = learningEngine.enrichSystemPrompt(
            basePrompt = persona.systemPrompt,
            isAutonomousLearningEnabled = isAutonomousLearningEnabled,
            deviceContext = deviceContext
        )

        // Asynchronous background learning from user prompt
        if (isAutonomousLearningEnabled) {
            repositoryScope.launch {
                try {
                    learningEngine.analyzeAndLearn(userPrompt, null, apiKey)
                } catch (e: Exception) {
                    Log.d("ChatRepository", "Background learning completed with fallback: ${e.message}")
                }
            }
        }

        // Mily provider routing: GPT models go through the secure app backend.
        // The APK never receives an OpenAI API key. Gemini remains available for backward compatibility.
        if (modelName.startsWith("gpt-", ignoreCase = true)) {
            val history = currentHistory.takeLast(12).map {
                AiMessage(
                    role = if (it.role == "model") "assistant" else it.role,
                    content = it.content
                )
            }
            val localMemoryFacts = buildList {
                memoryDao.getActiveMemoriesForPrompt().forEach {
                    add("[${it.category}] ${it.content}")
                }
                semanticDao?.getActiveFactsForInjection(limit = 20)?.forEach {
                    add("[SEMANTIC:${it.category}] ${it.formattedFact}")
                }
            }.distinct().take(30)

            val aiResult = openAiProvider.generate(
                AiRequest(
                    model = modelName,
                    systemPrompt = enrichedSystemPrompt,
                    history = history,
                    temperature = temperature,
                    maxOutputTokens = 2048,
                    memoryFacts = localMemoryFacts,
                    enableFileSearch = true,
                    maxFileSearchResults = 6
                )
            )
            return@withContext aiResult.fold(
                onSuccess = { aiResponse ->
                    val assistantMessage = ChatMessageEntity(
                        id = UUID.randomUUID().toString(),
                        sessionId = sessionId,
                        role = "model",
                        content = aiResponse.text,
                        timestamp = System.currentTimeMillis(),
                        tokenCount = aiResponse.tokenCount
                    )
                    chatDao.insertMessage(assistantMessage)
                    if (isAutonomousLearningEnabled) {
                        repositoryScope.launch {
                            try { learningEngine.analyzeAndLearn(userPrompt, aiResponse.text, "", sessionId) }
                            catch (e: Exception) { Log.d("ChatRepository", "Background learning error: ${e.message}") }
                        }
                    }
                    Result.success(assistantMessage)
                },
                onFailure = { error ->
                    Log.e("ChatRepository", "Error calling Mily OpenAI backend: ${error.message}", error)
                    val errorEntity = ChatMessageEntity(
                        id = UUID.randomUUID().toString(), sessionId = sessionId, role = "model",
                        content = "⚠️ Mily no pudo contactar su backend de OpenAI: ${error.localizedMessage ?: "conexión no disponible"}. Configura MILY_BACKEND_URL.",
                        timestamp = System.currentTimeMillis(), isError = true
                    )
                    chatDao.insertMessage(errorEntity)
                    Result.failure(error)
                }
            )
        }

        // 5. Build Multi-turn History (last 12 messages to stay within token & fast latency budgets)
        val historyLimit = currentHistory.takeLast(12)
        val contentsList = mutableListOf<GeminiContent>()

        for (msg in historyLimit) {
            val role = if (msg.role == "user") "user" else "model"
            contentsList.add(
                GeminiContent(
                    role = role,
                    parts = listOf(GeminiPart(text = msg.content))
                )
            )
        }

        val request = GeminiRequest(
            contents = contentsList,
            generationConfig = GeminiGenerationConfig(
                temperature = temperature,
                topP = 0.95f,
                topK = 40,
                maxOutputTokens = 2048
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = enrichedSystemPrompt))
            )
        )

        try {
            if (apiKey.isEmpty()) {
                // If no real API key is configured yet, provide a high quality local response with instructions
                val localResponseText = generateFallbackResponse(userPrompt, persona)
                val assistantMessage = ChatMessageEntity(
                    id = UUID.randomUUID().toString(),
                    sessionId = sessionId,
                    role = "model",
                    content = localResponseText,
                    timestamp = System.currentTimeMillis(),
                    tokenCount = localResponseText.split(" ").size
                )
                chatDao.insertMessage(assistantMessage)
                return@withContext Result.success(assistantMessage)
            }

            val response = GeminiApiClient.service.generateContent(
                model = modelName,
                apiKey = apiKey,
                request = request
            )

            val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: response.error?.message
                ?: "No se obtuvo una respuesta del modelo."

            val tokens = response.usageMetadata?.totalTokenCount ?: (textResponse.split(" ").size)

            val assistantMessage = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = "model",
                content = textResponse,
                timestamp = System.currentTimeMillis(),
                tokenCount = tokens
            )
            chatDao.insertMessage(assistantMessage)

            // Trigger background learning with assistant response context
            if (isAutonomousLearningEnabled) {
                repositoryScope.launch {
                    try {
                        learningEngine.analyzeAndLearn(userPrompt, textResponse, apiKey, sessionId)
                    } catch (e: Exception) {
                        Log.d("ChatRepository", "Background learning error: ${e.message}")
                    }
                }
            }

            Result.success(assistantMessage)
        } catch (e: Exception) {
            Log.e("ChatRepository", "Error calling Gemini API: ${e.message}", e)
            val errorMessage = "⚠️ Ocurrió un error al contactar al asistente (${e.localizedMessage ?: "Conexión interrumpida"}). Puedes reintentar o verificar tu clave de API en Ajustes."
            val errorEntity = ChatMessageEntity(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = "model",
                content = errorMessage,
                timestamp = System.currentTimeMillis(),
                isError = true
            )
            chatDao.insertMessage(errorEntity)
            Result.failure(e)
        }
    }

    /**
     * Prueba la conexión en vivo con la API de Gemini
     */
    suspend fun testApiConnection(
        customApiKey: String? = null,
        modelName: String = "gpt-6-astra"
    ): ApiConnectionStatus = withContext(Dispatchers.IO) {
        val apiKey = when {
            !customApiKey.isNullOrBlank() -> customApiKey.trim()
            BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY" -> BuildConfig.GEMINI_API_KEY
            else -> ""
        }
        if (apiKey.isBlank()) {
            return@withContext ApiConnectionStatus.Error("No hay clave de API configurada en AI Studio ni personalizada.")
        }
        GeminiApiClient.testConnection(apiKey, modelName)
    }

    private fun makeBriefTitle(prompt: String): String {
        val clean = prompt.replace("\n", " ").trim()
        val words = clean.split(" ").filter { it.isNotBlank() }
        return if (words.size <= 5) {
            clean.take(30)
        } else {
            words.take(4).joinToString(" ").take(30) + "…"
        }
    }

    private fun generateFallbackResponse(prompt: String, persona: Persona): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("hola") || lower.contains("saludo") || lower.contains("buenos") -> {
                "¡Hola! Soy tu **${persona.name}** con IA.\n\n" +
                "Estoy listo para ayudarte con:\n" +
                "- 📝 Redacción, corrección y generación de ideas\n" +
                "- 💻 Programación, resolución de errores y arquitectura\n" +
                "- 📚 Explicaciones paso a paso y estudio\n" +
                "- ⚡ Productividad y organización de proyectos\n\n" +
                "¿Qué deseas que exploremos hoy?"
            }
            lower.contains("codigo") || lower.contains("código") || lower.contains("kotlin") || lower.contains("programar") -> {
                "Aquí tienes un ejemplo de código estructurado siguiendo buenas prácticas:\n\n" +
                "```kotlin\n" +
                "// Función para procesar datos de forma asíncrona\n" +
                "suspend fun processTask(query: String): Result<String> = withContext(Dispatchers.IO) {\n" +
                "    try {\n" +
                "        val result = executeComputation(query)\n" +
                "        Result.success(result)\n" +
                "    } catch (e: Exception) {\n" +
                "        Result.failure(e)\n" +
                "    }\n" +
                "}\n" +
                "```\n\n" +
                "**Puntos clave:**\n" +
                "1. Utiliza `Dispatchers.IO` para evitar bloquear el hilo principal.\n" +
                "2. Envuelve en `Result<T>` para un manejo robusto de excepciones."
            }
            else -> {
                "He recibido tu consulta: **\"$prompt\"**.\n\n" +
                "Como **${persona.name}**, aquí tienes un análisis inicial estructurado:\n\n" +
                "1. **Objetivo Principal:** Identificar las variables clave y estructurar la mejor solución.\n" +
                "2. **Recomendación:** Aplicar un enfoque modular, asegurando claridad y consistencia.\n" +
                "3. **Siguiente Paso:** Puedes pedirme que profundice en un punto específico, genere código o redacte un documento completo.\n\n" +
                "*(Nota: Puedes configurar tu clave de Gemini API en la sección de Ajustes ⚙️ para acceder a las respuestas en tiempo real del modelo gemini-3.5-flash).* "
            }
        }
    }
}

