package com.example.data.mily.orchestration

enum class MilyRoute { CONVERSATION, KNOWLEDGE, DEVICE }

data class MilyRouteDecision(val route: MilyRoute, val useFileSearch: Boolean, val useDeviceContext: Boolean)

object MilyOrchestrator {
    fun decide(prompt: String, hasKnowledge: Boolean): MilyRouteDecision {
        val p = prompt.lowercase()
        val knowledge = hasKnowledge && listOf("documento", "archivo", "pdf", "manual", "según", "segun", "qué dice", "que dice").any(p::contains)
        val device = listOf("batería", "bateria", "ram", "almacenamiento", "teléfono", "telefono", "celular", "hardware", "dispositivo").any(p::contains)
        return when {
            knowledge -> MilyRouteDecision(MilyRoute.KNOWLEDGE, true, false)
            device -> MilyRouteDecision(MilyRoute.DEVICE, false, true)
            else -> MilyRouteDecision(MilyRoute.CONVERSATION, false, false)
        }
    }
}
