package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SemanticMemoryEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object para la Memoria Semántica.
 */
@Dao
interface SemanticMemoryDao {

    @Query("SELECT * FROM semantic_memories ORDER BY confidenceScore DESC, updatedAt DESC")
    fun getAllSemanticMemories(): Flow<List<SemanticMemoryEntity>>

    @Query("SELECT * FROM semantic_memories WHERE isActive = 1 ORDER BY confidenceScore DESC, accessCount DESC LIMIT :limit")
    suspend fun getActiveFactsForInjection(limit: Int = 30): List<SemanticMemoryEntity>

    @Query("SELECT * FROM semantic_memories WHERE category = :category ORDER BY updatedAt DESC")
    fun getSemanticMemoriesByCategory(category: String): Flow<List<SemanticMemoryEntity>>

    @Query("SELECT * FROM semantic_memories WHERE subject LIKE '%' || :query || '%' OR predicate LIKE '%' || :query || '%' OR objectValue LIKE '%' || :query || '%' OR formattedFact LIKE '%' || :query || '%'")
    fun searchSemanticFacts(query: String): Flow<List<SemanticMemoryEntity>>

    @Query("SELECT * FROM semantic_memories WHERE subject = :subject ORDER BY confidenceScore DESC")
    fun getFactsBySubject(subject: String): Flow<List<SemanticMemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSemanticMemory(memory: SemanticMemoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSemanticMemories(memories: List<SemanticMemoryEntity>)

    @Update
    suspend fun updateSemanticMemory(memory: SemanticMemoryEntity)

    @Query("UPDATE semantic_memories SET isActive = NOT isActive WHERE id = :id")
    suspend fun toggleSemanticMemoryActive(id: String)

    @Query("UPDATE semantic_memories SET accessCount = accessCount + 1, updatedAt = :time WHERE id = :id")
    suspend fun recordSemanticRecall(id: String, time: Long = System.currentTimeMillis())

    @Query("DELETE FROM semantic_memories WHERE id = :id")
    suspend fun deleteSemanticMemoryById(id: String)

    @Query("DELETE FROM semantic_memories")
    suspend fun clearAllSemanticMemories()

    @Query("SELECT COUNT(*) FROM semantic_memories WHERE isActive = 1")
    fun getActiveSemanticCount(): Flow<Int>
}
