package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Tabla para Memoria Episódica (Episodic Memory).
 * Almacena eventos situacionales, interacciones temporales, contexto de sesiones y secuencias cronológicas.
 */
@Entity(
    tableName = "episodic_memories",
    indices = [
        Index(value = ["sessionId"]),
        Index(value = ["timestamp"]),
        Index(value = ["importanceScore"])
    ]
)
data class EpisodicMemoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val sessionId: String? = null,
    val summary: String,
    val detailedContext: String,
    val timestamp: Long = System.currentTimeMillis(),
    val importanceScore: Float = 0.5f,
    val emotionalValence: String? = "neutral",
    val tags: String = "",
    val decayFactor: Float = 1.0f,
    val accessCount: Int = 0,
    val lastRecalledAt: Long = System.currentTimeMillis()
)
