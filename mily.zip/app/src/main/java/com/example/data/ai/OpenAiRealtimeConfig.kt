package com.example.data.ai

/** Configuration shared by the Android Realtime layer. Actual WebRTC media handling is separate. */
data class OpenAiRealtimeConfig(
    val model: String = "gpt-live-1",
    val voice: String = "marin",
    val language: String = "es"
)
