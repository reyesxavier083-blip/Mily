package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.MemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM autonomous_memories ORDER BY createdAt DESC")
    fun getAllMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM autonomous_memories WHERE isActive = 1 ORDER BY confidence DESC, lastAccessedAt DESC LIMIT 25")
    suspend fun getActiveMemoriesForPrompt(): List<MemoryEntity>

    @Query("SELECT * FROM autonomous_memories WHERE category = :category ORDER BY createdAt DESC")
    fun getMemoriesByCategory(category: String): Flow<List<MemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemories(memories: List<MemoryEntity>)

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("DELETE FROM autonomous_memories WHERE id = :memoryId")
    suspend fun deleteMemory(memoryId: String)

    @Query("DELETE FROM autonomous_memories")
    suspend fun deleteAllMemories()

    @Query("UPDATE autonomous_memories SET isActive = NOT isActive WHERE id = :memoryId")
    suspend fun toggleMemoryActive(memoryId: String)

    @Query("UPDATE autonomous_memories SET lastAccessedAt = :time WHERE id IN (:memoryIds)")
    suspend fun updateLastAccessed(memoryIds: List<String>, time: Long = System.currentTimeMillis())

    @Query("SELECT COUNT(*) FROM autonomous_memories WHERE isActive = 1")
    fun getActiveMemoriesCount(): Flow<Int>
}
