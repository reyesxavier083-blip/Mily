package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EpisodicMemoryEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object para la Memoria Episódica.
 */
@Dao
interface EpisodicMemoryDao {

    @Query("SELECT * FROM episodic_memories ORDER BY timestamp DESC")
    fun getAllEpisodes(): Flow<List<EpisodicMemoryEntity>>

    @Query("SELECT * FROM episodic_memories WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getEpisodesBySession(sessionId: String): Flow<List<EpisodicMemoryEntity>>

    @Query("SELECT * FROM episodic_memories ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentEpisodes(limit: Int = 20): List<EpisodicMemoryEntity>

    @Query("SELECT * FROM episodic_memories WHERE importanceScore >= :minScore ORDER BY importanceScore DESC, timestamp DESC LIMIT :limit")
    suspend fun getSignificantEpisodes(minScore: Float = 0.7f, limit: Int = 15): List<EpisodicMemoryEntity>

    @Query("SELECT * FROM episodic_memories WHERE summary LIKE '%' || :query || '%' OR detailedContext LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchEpisodes(query: String): Flow<List<EpisodicMemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisode(episode: EpisodicMemoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisodes(episodes: List<EpisodicMemoryEntity>)

    @Update
    suspend fun updateEpisode(episode: EpisodicMemoryEntity)

    @Query("UPDATE episodic_memories SET accessCount = accessCount + 1, lastRecalledAt = :time WHERE id = :id")
    suspend fun recordEpisodeRecall(id: String, time: Long = System.currentTimeMillis())

    @Query("DELETE FROM episodic_memories WHERE id = :id")
    suspend fun deleteEpisodeById(id: String)

    @Query("DELETE FROM episodic_memories WHERE sessionId = :sessionId")
    suspend fun deleteEpisodesBySession(sessionId: String)

    @Query("DELETE FROM episodic_memories")
    suspend fun clearAllEpisodes()

    @Query("SELECT COUNT(*) FROM episodic_memories")
    fun getEpisodesCount(): Flow<Int>
}
