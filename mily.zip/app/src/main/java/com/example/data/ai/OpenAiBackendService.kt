package com.example.data.ai

import com.squareup.moshi.JsonClass
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Mily talks to a small application backend instead of shipping an OpenAI API key in the APK.
 * The backend owns the OpenAI credential and calls the Responses API.
 */
interface OpenAiBackendService {
    @POST("v1/mily/responses")
    suspend fun generate(@Body request: OpenAiBackendRequest): OpenAiBackendResponse
}

@JsonClass(generateAdapter = true)
data class OpenAiBackendRequest(
    val model: String,
    val instructions: String,
    val input: List<OpenAiInputMessage>,
    val temperature: Float = 0.7f,
    val maxOutputTokens: Int = 2048,
    val memoryFacts: List<String> = emptyList(),
    val enableFileSearch: Boolean = true,
    val maxFileSearchResults: Int = 6
)

@JsonClass(generateAdapter = true)
data class OpenAiInputMessage(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class OpenAiBackendResponse(
    val text: String? = null,
    val outputText: String? = null,
    val tokenCount: Int? = null,
    val error: String? = null
)
