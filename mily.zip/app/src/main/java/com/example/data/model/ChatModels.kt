package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String = "Nueva conversación",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val personaId: String = Persona.ID_GENERAL,
    val modelName: String = "gpt-6-astra",
    val isPinned: Boolean = false
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val role: String, // "user" | "model" | "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false,
    val tokenCount: Int = 0,
    val feedback: Int = 0, // 0 = none, 1 = positive, -1 = negative
    val feedbackNote: String? = null
)

@Entity(tableName = "autonomous_memories")
data class MemoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val category: String = MemoryCategory.PREFERENCE.name,
    val content: String,
    val confidence: Float = 0.9f,
    val createdAt: Long = System.currentTimeMillis(),
    val lastAccessedAt: Long = System.currentTimeMillis(),
    val isActive: Boolean = true,
    val sourceContext: String? = null
)

enum class MemoryCategory(val displayName: String, val iconName: String) {
    WORKING("Memoria de Trabajo", "psychology"),
    EPISODIC("Memoria Episódica", "history"),
    SEMANTIC("Memoria Semántica", "menu_book"),
    PROCEDURAL("Memoria Procedimental", "account_tree"),
    USER_CONTEXT("Contexto de Usuario", "person"),
    LONG_TERM("Largo Plazo Consolidada", "all_inclusive"),
    PREFERENCE("Preferencias", "tune"),
    PROJECT("Proyectos y Código", "code"),
    FACT("Hechos y Datos", "info"),
    GOAL("Metas y Hábitos", "flag"),
    CORRECTION("Feedback y Ajustes", "auto_fix_high")
}

enum class NexusEngineType(
    val title: String,
    val subtitle: String,
    val milestone: String,
    val iconName: String,
    val description: String
) {
    RESEARCH(
        title = "Research Engine",
        subtitle = "Investigación Autónoma Profunda",
        milestone = "M81",
        iconName = "travel_explore",
        description = "Explora hipótesis, sintetiza fuentes técnicas, descompone temas de investigación y genera marcos teóricos."
    ),
    SIMULATION(
        title = "Simulation Engine",
        subtitle = "Simulador de Escenarios y Monte Carlo",
        milestone = "M82",
        iconName = "model_training",
        description = "Simula escenarios futuros, dinámicas de debate multi-agente, árboles de decisión y evaluación de riesgos."
    ),
    PREDICTION(
        title = "Prediction Engine",
        subtitle = "Inteligencia Predictiva y Tendencias",
        milestone = "M83 / M500",
        iconName = "query_stats",
        description = "Extrapola tendencias de desarrollo, proyecta cronogramas y anticipa cuellos de botella con scoring de probabilidad."
    ),
    AGENT_MESH(
        title = "Agent Runtime & Mesh",
        subtitle = "Malla de Agentes y Orquestación",
        milestone = "M1000",
        iconName = "hub",
        description = "Ciclo cognitivo continuo (Plan -> Act -> Observe -> Consolidate) con despacho de herramientas."
    ),
    SECURITY_GOVERNANCE(
        title = "Security & Governance",
        subtitle = "Gobernanza, Privacidad y Filtros",
        milestone = "Core",
        iconName = "security",
        description = "Monitoreo de tokens, guardrails de alineación, validación de salidas y auditoría de contexto local."
    ),
    AUTO_REPAIR(
        title = "Auto-Repair System",
        subtitle = "Sistema Autónomo de Reparación de Fallas",
        milestone = "M900",
        iconName = "build_circle",
        description = "Intercepta crashes y excepciones globales, realiza diagnóstico del stack trace, y auto-corrige bugs en el código."
    )
}

data class NexusEngineTemplate(
    val id: String,
    val engineType: NexusEngineType,
    val title: String,
    val promptTemplate: (String) -> String,
    val placeholder: String
) {
    companion object {
        val ALL_TEMPLATES = listOf(
            NexusEngineTemplate(
                id = "eng_research_deep",
                engineType = NexusEngineType.RESEARCH,
                title = "Análisis Exhaustivo & Estado del Arte",
                placeholder = "Ej: Estado actual de la computación neuromórfica o arquitecturas LLM on-device...",
                promptTemplate = { input ->
                    "### [NEXUS RESEARCH ENGINE — M81]\n" +
                    "Ejecuta una investigación analítica profunda y estructurada sobre:\n\"$input\"\n\n" +
                    "Estructura el reporte en:\n" +
                    "1. **Hipótesis y Tesis Central**\n" +
                    "2. **Estado del Arte y Antecedentes Técnicos**\n" +
                    "3. **Metodología y Análisis Comparativo**\n" +
                    "4. **Hallazgos Clave y Conclusiones Fundamentadas**\n" +
                    "5. **Referencias conceptuales y preguntas abiertas**"
                }
            ),
            NexusEngineTemplate(
                id = "eng_sim_sandbox",
                engineType = NexusEngineType.SIMULATION,
                title = "Simulación de Escenarios y Ramificaciones",
                placeholder = "Ej: Lanzar la app como modelo Freemium vs Suscripción en LATAM...",
                promptTemplate = { input ->
                    "### [NEXUS SIMULATION ENGINE — M82]\n" +
                    "Simula una matriz de escenarios y resultados para la siguiente premisa:\n\"$input\"\n\n" +
                    "Genera 3 escenarios detallados:\n" +
                    "- **Escenario A (Optimista / Mejor Caso)**: Factores desencadenantes, métricas y probabilidad estimada.\n" +
                    "- **Escenario B (Pesimista / Análisis de Riesgos)**: Modos de falla y mitigaciones críticas.\n" +
                    "- **Escenario C (Base / Más Probable)**: Ruta esperada paso a paso y puntos de inflexión."
                }
            ),
            NexusEngineTemplate(
                id = "eng_pred_roadmap",
                engineType = NexusEngineType.PREDICTION,
                title = "Proyección de Tendencias & Estimación Temporal",
                placeholder = "Ej: Evolución de desarrollo de mi sistema NEXUS y adopción de agentes...",
                promptTemplate = { input ->
                    "### [NEXUS PREDICTION ENGINE — M83 / M500]\n" +
                    "Genera una proyección predictiva y extrapolación técnica para:\n\"$input\"\n\n" +
                    "Incluye:\n" +
                    "1. **Horizonte Temporal (Corto, Mediano y Largo Plazo)**\n" +
                    "2. **Variables Determinantes y Nivel de Confianza (%)**\n" +
                    "3. **Cuellos de Botella Anticipados y Señales de Alerta Temprana**\n" +
                    "4. **Recomendaciones Estratégicas para Maximizar Éxito**"
                }
            ),
            NexusEngineTemplate(
                id = "eng_agent_mesh_task",
                engineType = NexusEngineType.AGENT_MESH,
                title = "Orquestación Multi-Paso de Agente",
                placeholder = "Ej: Diseñar la arquitectura modular completa para persistencia y sincronización...",
                promptTemplate = { input ->
                    "### [NEXUS AGENT RUNTIME — MESH EXECUTION]\n" +
                    "Ejecuta como Agente Orquestador Autónomo la siguiente tarea:\n\"$input\"\n\n" +
                    "Aplica el ciclo cognitivo NEXUS:\n" +
                    "1. **PLAN (Planificación)**: Descomposición atómica de pasos.\n" +
                    "2. **ACT (Ejecución)**: Desarrollo exhaustivo y soluciones concretas.\n" +
                    "3. **OBSERVE (Validación)**: Comprobación de integridad, edge cases y rendimiento.\n" +
                    "4. **CONSOLIDATE (Consolidación)**: Extracción de reglas y aprendizajes persistentes."
                }
            ),
            NexusEngineTemplate(
                id = "eng_auto_repair",
                engineType = NexusEngineType.AUTO_REPAIR,
                title = "Sistema Autónomo de Reparación de Fallas",
                placeholder = "Pega el StackTrace o describe el crash/bug de la aplicación...",
                promptTemplate = { input ->
                    "⚠️ **[SISTEMA DE AUTO-REPARACIÓN INICIADO]** ⚠️\n" +
                    "Se ha detectado una falla (Crash) en la aplicación o se requiere intervención técnica. Por favor analiza el siguiente reporte de error / StackTrace:\n\n" +
                    "```\n$input\n```\n\n" +
                    "Como el Motor de Auto-Reparación, debes:\n" +
                    "1. **Identificar la Causa Raíz**: Explica de forma concisa qué está fallando y por qué.\n" +
                    "2. **Proponer el Arreglo Automático**: Genera el bloque de código exacto necesario para solucionar el bug.\n" +
                    "3. **Medidas Preventivas**: Qué cambios estructurales evitarían que esto se repita."
                }
            ),
            NexusEngineTemplate(
                id = "eng_sec_vuln_api",
                engineType = NexusEngineType.SECURITY_GOVERNANCE,
                title = "Auditoría de Ciberseguridad & Vulnerabilidades (API)",
                placeholder = "Ej: Analiza este snippet de autenticación o busca vulnerabilidades CVE-2021-44228...",
                promptTemplate = { input ->
                    "🛡️ **[NEXUS SECURITY & VULNERABILITY ENGINE]** 🛡️\n" +
                    "Actúa como un Analista Experto en Ciberseguridad y Pentester. Analiza la siguiente consulta, arquitectura o código en busca de vulnerabilidades:\n\n" +
                    "\"$input\"\n\n" +
                    "Ejecuta el siguiente protocolo de seguridad:\n" +
                    "1. **Identificación de Vulnerabilidades (CVE / OWASP)**: Detecta inyecciones SQL, XSS, CSRF, desbordamientos de buffer, o configuraciones inseguras.\n" +
                    "2. **Vector de Ataque y Gravedad**: Explica cómo se explotaría y asigna un nivel de criticidad (Bajo, Medio, Alto, Crítico).\n" +
                    "3. **Protocolo de Mitigación**: Proporciona el código corregido o la arquitectura segura (Zero Trust) necesaria para neutralizar la amenaza."
                }
            )
        )
    }
}

data class AITool(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val iconName: String,
    val placeholder: String,
    val promptTemplate: (String) -> String
) {
    companion object {
        val ALL_TOOLS = listOf(
            AITool(
                id = "tool_cyber_sec_scanner",
                title = "Vulnerability Scanner API",
                description = "Simula una API de escaneo de vulnerabilidades, analizando dependencias y código contra bases de datos CVE.",
                category = "Ciberseguridad",
                iconName = "security",
                placeholder = "Pega código fuente, dependencias o logs de red para analizar...",
                promptTemplate = { input ->
                    "Iniciando escaneo de vulnerabilidades (Simulación API CVE). Analiza el siguiente objetivo de evaluación:\n\n" +
                    "```\n$input\n```\n\n" +
                    "Proporciona un reporte en formato JSON o estructurado con:\n" +
                    "- Vulnerabilidades detectadas (CVE ID si aplica)\n" +
                    "- Severidad (CVSS Score estimado)\n" +
                    "- Dependencias afectadas\n" +
                    "- Solución y parche recomendado."
                }
            ),
            AITool(
                id = "tool_code_auditor",
                title = "Auditor y Refactor de Código",
                description = "Analiza complejidad O(N), detecta bugs, optimiza y genera tests unitarios.",
                category = "Programación",
                iconName = "code",
                placeholder = "Pega aquí tu código en Kotlin, Python, JS, Java...",
                promptTemplate = { input ->
                    "Por favor audita y optimiza el siguiente código. Incluye:\n" +
                    "1. Análisis de complejidad temporal y espacial O(N)\n" +
                    "2. Detección de posibles bugs o memory leaks\n" +
                    "3. Versión refactorizada y limpia con mejores prácticas\n" +
                    "4. Ejemplo de test unitario recomendado\n\n```\n$input\n```"
                }
            ),
            AITool(
                id = "tool_action_plan",
                title = "Plan de Acción y Cronograma",
                description = "Convierte cualquier objetivo en un roadmap estructurado paso a paso.",
                category = "Productividad",
                iconName = "task_alt",
                placeholder = "Ej: Lanzar mi aplicación Android en 30 días...",
                promptTemplate = { input ->
                    "Diseña un plan de acción integral y cronograma para el siguiente objetivo:\n\"$input\"\n\n" +
                    "Divide el plan en:\n" +
                    "- Fases clave con estimación de tiempos\n" +
                    "- Checklist de tareas accionables de alta prioridad\n" +
                    "- Métricas de éxito y posibles riesgos a prevenir"
                }
            ),
            AITool(
                id = "tool_mindmap",
                title = "Esquema y Mapa Conceptual",
                description = "Genera un árbol jerárquico visual y estructurado para aprender cualquier tema.",
                category = "Estudio",
                iconName = "schema",
                placeholder = "Ej: Arquitectura Limpia en Android (Clean Architecture)...",
                promptTemplate = { input ->
                    "Genera un esquema conceptual y mapa jerárquico detallado para el tema:\n\"$input\"\n\n" +
                    "Utiliza formato de árbol estructurado (ASCII/Markdown con ├─, └─), definiciones concisas de cada nodo y relaciones clave."
                }
            ),
            AITool(
                id = "tool_deep_summarizer",
                title = "Extractor & Resumen Ejecutivo",
                description = "Extrae conclusiones, puntos críticos y tareas accionables de textos largos.",
                category = "Análisis",
                iconName = "summarize",
                placeholder = "Pega aquí el artículo, reunión, reporte o texto largo...",
                promptTemplate = { input ->
                    "Realiza una extracción analítica profunda del siguiente texto:\n\n\"\"\"\n$input\n\"\"\"\n\n" +
                    "Estructura el resultado en:\n" +
                    "1. **Resumen Ejecutivo** (máximo 3 párrafos de alto impacto)\n" +
                    "2. **Puntos Clave y Hallazgos Principales** (lista con viñetas)\n" +
                    "3. **Decisiones o Tareas Accionables (Action Items)**"
                }
            ),
            AITool(
                id = "tool_roleplay_interview",
                title = "Simulador de Entrevistas & Debate",
                description = "Simula una entrevista técnica/laboral o un debate socrático con retroalimentación.",
                category = "Entrenamiento",
                iconName = "psychology",
                placeholder = "Ej: Entrevista técnica para Desarrollador Android Senior...",
                promptTemplate = { input ->
                    "Quiero simular una sesión de entrenamiento interactivo para:\n\"$input\"\n\n" +
                    "Inicia como el evaluador/entrevistador profesional formulándome la primera pregunta desafiante, y después de mi respuesta, evalúa y da retroalimentación antes de la siguiente pregunta."
                }
            ),
            AITool(
                id = "tool_cultural_translator",
                title = "Traductor & Adaptador Cultural",
                description = "Traduce preservando el tono idiomático y explicando matices culturales.",
                category = "Idiomas",
                iconName = "translate",
                placeholder = "Escribe el texto y el idioma destino...",
                promptTemplate = { input ->
                    "Traduce y adapta contextualmente el siguiente contenido:\n\"$input\"\n\n" +
                    "Proporciona:\n" +
                    "1. Traducción natural y profesional adaptada al contexto\n" +
                    "2. Explicación de expresiones idiomáticas o modismos equivalentes\n" +
                    "3. Alternativas de tono (Formal vs Coloquial)"
                }
            ),
            AITool(
                id = "tool_math_reasoning",
                title = "Resolutor Lógico & Matemático",
                description = "Resuelve problemas cuantitativos, lógicos o científicos con demostración paso a paso.",
                category = "Ciencia",
                iconName = "calculate",
                placeholder = "Escribe tu problema matemático, físico o ecuación...",
                promptTemplate = { input ->
                    "Resuelve el siguiente problema con rigor analítico y demostración detallada paso a paso:\n\"$input\"\n\n" +
                    "Muestra las fórmulas aplicadas, el desarrollo paso a paso y la interpretación del resultado final."
                }
            ),
            AITool(
                id = "tool_device_diagnostics",
                title = "Diagnóstico & Telemetría de Dispositivo",
                description = "Analiza el estado del sistema, hardware, memoria RAM, batería y salud del dispositivo.",
                category = "Sistema",
                iconName = "phone_android",
                placeholder = "Ej: Analiza el consumo de batería y memoria RAM o describe el estado general...",
                promptTemplate = { input ->
                    "### [NEXUS DEVICE SYSTEM ENGINE — TELEMETRÍA]\n" +
                    "Realiza un análisis integral sobre el estado del dispositivo y hardware para:\n\"$input\"\n\n" +
                    "Incluye:\n" +
                    "1. **Evaluación de Recursos** (RAM, Batería, Almacenamiento y Conectividad)\n" +
                    "2. **Diagnóstico de Salud y Cuellos de Botella Térmicos/Memoria**\n" +
                    "3. **Recomendaciones Accionables de Optimización On-Device**"
                }
            )
        )

        fun getById(id: String): AITool? = ALL_TOOLS.find { it.id == id }
    }
}


data class Persona(
    val id: String,
    val name: String,
    val description: String,
    val iconName: String,
    val systemPrompt: String,
    val defaultTemperature: Float = 0.7f,
    val samplePrompts: List<String> = emptyList()
) {
    companion object {
        const val ID_GENERAL = "persona_general"
        const val ID_CODER = "persona_coder"
        const val ID_TUTOR = "persona_tutor"
        const val ID_WRITER = "persona_writer"
        const val ID_PRODUCTIVITY = "persona_productivity"
        const val ID_CREATIVE = "persona_creative"

        val DEFAULT_PERSONAS = listOf(
            Persona(
                id = ID_GENERAL,
                name = "Asistente General",
                description = "Respuestas claras, versátiles y precisas para cualquier tarea cotidiana.",
                iconName = "smart_toy",
                systemPrompt = "Eres un asistente de inteligencia artificial avanzado, cordial, elocuente y muy eficiente. Responde siempre de forma estructurada, útil y con formato claro.",
                defaultTemperature = 0.7f,
                samplePrompts = listOf(
                    "¿Cuáles son los hábitos más efectivos para aprender algo nuevo?",
                    "Explícame cómo funciona la computación cuántica de forma sencilla.",
                    "Dame 5 ideas creativas para organizar mi semana laboral."
                )
            ),
            Persona(
                id = ID_CODER,
                name = "Experto en Programación",
                description = "Especialista en Kotlin, Python, JS, arquitectura y depuración de código.",
                iconName = "code",
                systemPrompt = "Eres un Ingeniero de Software Principal y arquitecto de sistemas experto. Proporciona código limpio, moderno, con mejores prácticas, explicaciones claras de complejidad y comentarios bien estructurados.",
                defaultTemperature = 0.2f,
                samplePrompts = listOf(
                    "Escribe una función en Kotlin para calcular Fibonacci con memoización.",
                    "¿Cómo implementar paginación eficiente con Jetpack Compose y Room?",
                    "Explica las diferencias entre coroutines y threads con ejemplos."
                )
            ),
            Persona(
                id = ID_TUTOR,
                name = "Tutor Académico",
                description = "Enseña paso a paso con explicaciones pedagógicas y preguntas guía.",
                iconName = "school",
                systemPrompt = "Eres un profesor y tutor socrático excepcional. Explica temas complejos con analogías cotidianas, divide las respuestas en pasos lógicos y añade preguntas de autoevaluación al final.",
                defaultTemperature = 0.6f,
                samplePrompts = listOf(
                    "Explícame el cálculo diferencial y la regla de la cadena con un ejemplo.",
                    "Hazme un resumen y un cuestionario de 3 preguntas sobre la fotosíntesis.",
                    "¿Cómo estructurar un ensayo argumentativo convincente?"
                )
            ),
            Persona(
                id = ID_WRITER,
                name = "Redactor & Corrector",
                description = "Redacción persuasiva, corrección de estilo, correos formales y ensayos.",
                iconName = "edit_note",
                systemPrompt = "Eres un redactor profesional, editor de estilo y estratega de contenido. Ayuda a pulir textos, mejorar la fluidez, adaptar el tono (formal, persuasivo o narrativo) y corregir la gramática.",
                defaultTemperature = 0.8f,
                samplePrompts = listOf(
                    "Redacta un correo formal solicitando una reunión de seguimiento de proyecto.",
                    "Mejora este párrafo para que suene más profesional y conciso.",
                    "Crea una propuesta de valor atractiva para una aplicación móvil."
                )
            ),
            Persona(
                id = ID_PRODUCTIVITY,
                name = "Productividad & Planes",
                description = "Planes de acción, resúmenes ejecutivos, listas de tareas y hábitos.",
                iconName = "task_alt",
                systemPrompt = "Eres un coach de productividad y organización de alto rendimiento. Estructura respuestas con tablas, listas de verificación, metodologías probadas (Pomodoro, Eisenhower, Time-blocking) y plazos claros.",
                defaultTemperature = 0.5f,
                samplePrompts = listOf(
                    "Crea un plan de 7 días para preparar una presentación de impacto.",
                    "Diseña una rutina matutina enfocada en concentración profunda.",
                    "Transforma estas notas desordenadas en un plan de acción con prioridades."
                )
            ),
            Persona(
                id = ID_CREATIVE,
                name = "Creativo & Storytelling",
                description = "Brainstorming, relatos, guiones, metáforas y creatividad sin límites.",
                iconName = "auto_awesome",
                systemPrompt = "Eres un consultor creativo, novelista y generador de ideas fuera de lo común. Utiliza metáforas inspiradoras, narrativas envolventes y pensamiento lateral para generar propuestas originales.",
                defaultTemperature = 0.9f,
                samplePrompts = listOf(
                    "Escribe el inicio de una historia de ciencia ficción cyberpunk.",
                    "Genera 5 nombres creativos y eslóganes para una startup de café.",
                    "Diseña una dinámica interactiva para romper el hielo en un equipo."
                )
            )
        )

        fun getById(id: String): Persona {
            return DEFAULT_PERSONAS.find { it.id == id } ?: DEFAULT_PERSONAS.first()
        }
    }
}
