package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Tabla para Memoria Semántica (Semantic Memory).
 * Almacena conocimiento factual, conceptos generalizados, preferencias estables, reglas y modelos conceptuales
 * independientes del momento específico del evento.
 */
@Entity(
    tableName = "semantic_memories",
    indices = [
        Index(value = ["category"]),
        Index(value = ["subject"]),
        Index(value = ["isActive"]),
        Index(value = ["confidenceScore"])
    ]
)
data class SemanticMemoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val subject: String,
    val predicate: String,
    val objectValue: String,
    val formattedFact: String,
    val category: String = "PREFERENCE", // PREFERENCE, KNOWLEDGE, SYSTEM_RULE, SKILL, IDENTITY, FACT
    val confidenceScore: Float = 0.9f,
    val sourceEpisodeId: String? = null,
    val isVerified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val accessCount: Int = 0,
    val isActive: Boolean = true
)
