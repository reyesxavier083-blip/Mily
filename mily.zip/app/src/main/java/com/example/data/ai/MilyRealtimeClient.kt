package com.example.data.ai

import android.content.Context
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SessionDescription
import org.webrtc.audio.AudioDeviceModule
import org.webrtc.audio.JavaAudioDeviceModule
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Native Android WebRTC client for Mily GPT-Live.
 * The OpenAI credential never enters the APK; Android only talks to MILY_BACKEND_URL.
 */
class MilyRealtimeClient(
    private val context: Context,
    private val backendUrl: String,
    private val config: OpenAiRealtimeConfig = OpenAiRealtimeConfig()
) {
    enum class State { IDLE, CONNECTING, CONNECTED, ERROR }

    data class Event(
        val type: String,
        val text: String? = null,
        val role: String? = null,
        val isFinal: Boolean = false
    )

    var state: State = State.IDLE
        private set

    var lastError: String? = null
        private set

    private var eventListener: ((Event) -> Unit)? = null

    fun setEventListener(listener: ((Event) -> Unit)?) {
        eventListener = listener
    }

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private var factory: PeerConnectionFactory? = null
    private var audioModule: AudioDeviceModule? = null
    private var peerConnection: PeerConnection? = null
    private var localAudioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null
    private var events: DataChannel? = null

    fun connect(onState: (State) -> Unit = {}) {
        if (state == State.CONNECTING || state == State.CONNECTED) return
        state = State.CONNECTING
        lastError = null
        onState(state)

        try {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )

            audioModule = JavaAudioDeviceModule.builder(context.applicationContext)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .createAudioDeviceModule()

            factory = PeerConnectionFactory.builder()
                .setAudioDeviceModule(audioModule)
                .createPeerConnectionFactory()

            val rtcConfig = PeerConnection.RTCConfiguration(
                listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer())
            )
            rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

            val observer = object : PeerConnection.Observer {
                override fun onIceCandidate(candidate: IceCandidate) = Unit
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) = Unit
                override fun onSignalingChange(newState: PeerConnection.SignalingState) = Unit
                override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                    if (newState == PeerConnection.IceConnectionState.FAILED ||
                        newState == PeerConnection.IceConnectionState.DISCONNECTED) {
                        fail("Conexión WebRTC perdida: $newState", onState)
                    }
                }
                override fun onIceConnectionReceivingChange(receiving: Boolean) = Unit
                override fun onIceGatheringChange(newState: PeerConnection.IceGatheringState) = Unit
                override fun onAddStream(stream: MediaStream) = Unit
                override fun onRemoveStream(stream: MediaStream) = Unit
                override fun onDataChannel(dataChannel: DataChannel) = Unit
                override fun onRenegotiationNeeded() = Unit
                override fun onAddTrack(receiver: org.webrtc.RtpReceiver, mediaStreams: Array<out MediaStream>) = Unit
            }

            peerConnection = factory?.createPeerConnection(rtcConfig, observer)
                ?: error("No se pudo crear PeerConnection")

            val constraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            }
            localAudioSource = factory?.createAudioSource(MediaConstraints())
            localAudioTrack = factory?.createAudioTrack("mily-mic", localAudioSource)
            localAudioTrack?.setEnabled(true)
            peerConnection?.addTrack(localAudioTrack, listOf("mily-audio"))

            events = peerConnection?.createDataChannel("oai-events", DataChannel.Init())
            events?.registerObserver(object : DataChannel.Observer {
                override fun onBufferedAmountChange(previousAmount: Long) = Unit
                override fun onStateChange() = Unit
                override fun onMessage(buffer: DataChannel.Buffer) {
                    val bytes = ByteArray(buffer.data.remaining())
                    buffer.data.get(bytes)
                    val event = String(bytes, Charsets.UTF_8)
                    try {
                        val json = JSONObject(event)
                        val type = json.optString("type")
                        when (type) {
                            "session.started", "session.created" -> {
                                state = State.CONNECTED
                                onState(state)
                            }
                            "session.closed" -> {
                                state = State.IDLE
                                onState(state)
                            }
                            "input_audio_buffer.speech_started" ->
                                eventListener?.invoke(Event(type))
                            "input_audio_buffer.speech_stopped" ->
                                eventListener?.invoke(Event(type))
                            "conversation.item.input_audio_transcription.delta" -> {
                                eventListener?.invoke(Event(type, json.optString("delta"), role = "user"))
                            }
                            "conversation.item.input_audio_transcription.completed" -> {
                                eventListener?.invoke(
                                    Event(
                                        type,
                                        json.optString("transcript"),
                                        role = "user",
                                        isFinal = true
                                    )
                                )
                            }
                            "response.output_audio_transcript.delta", "response.output_text.delta" -> {
                                eventListener?.invoke(Event(type, json.optString("delta"), role = "model"))
                            }
                            "response.output_audio_transcript.done", "response.output_text.done" -> {
                                eventListener?.invoke(
                                    Event(
                                        type,
                                        json.optString("transcript", json.optString("text")),
                                        role = "model",
                                        isFinal = true
                                    )
                                )
                            }
                            "error" -> {
                                eventListener?.invoke(Event(type, json.optString("message")))
                            }
                            else -> eventListener?.invoke(Event(type))
                        }
                    } catch (_: Throwable) {
                        eventListener?.invoke(Event("unknown", event))
                    }
                }
            })

            peerConnection?.createOffer(object : SdpObserverAdapter() {
                override fun onCreateSuccess(description: SessionDescription) {
                    peerConnection?.setLocalDescription(object : SdpObserverAdapter() {
                        override fun onSetSuccess() {
                            sendOfferWhenGathered(description, onState)
                        }
                        override fun onSetFailure(error: String) = fail(error, onState)
                    }, description)
                }
                override fun onCreateFailure(error: String) = fail(error, onState)
            }, constraints)
        } catch (t: Throwable) {
            fail(t.message ?: "Error inicializando WebRTC", onState)
        }
    }

    private fun sendOfferWhenGathered(description: SessionDescription, onState: (State) -> Unit) {
        Thread {
            try {
                // OpenAI expects the complete non-trickle SDP offer. Wait for ICE gathering.
                val deadline = System.currentTimeMillis() + 5_000
                while (peerConnection?.iceGatheringState != PeerConnection.IceGatheringState.COMPLETE &&
                    System.currentTimeMillis() < deadline) {
                    Thread.sleep(50)
                }
                val sdp = peerConnection?.localDescription?.description ?: description.description
                val session = JSONObject().apply {
                    put("type", "live")
                    put("model", config.model)
                    put("instructions", "Eres Mily, una asistente útil, clara y segura. Responde en español de México.")
                    put("audio", JSONObject().apply {
                        put("output", JSONObject().put("voice", config.voice))
                        put("input", JSONObject().apply {
                            put("transcription", JSONObject().put("model", "gpt-live-transcribe").put("languages", org.json.JSONArray().put("es")))
                            put("turn_detection", JSONObject().put("type", "semantic_vad"))
                        })
                    })
                }
                val body = JSONObject().apply {
                    put("session", session)
                    put("transport", JSONObject().apply {
                        put("type", "webrtc")
                        put("sdp", sdp)
                    })
                }.toString()

                val base = backendUrl.trimEnd('/')
                val request = Request.Builder()
                    .url("$base/v1/mily/live/sessions")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                http.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) error("Servidor Mily: HTTP ${response.code}")
                    val json = JSONObject(text)
                    val answer = json.getJSONObject("transport").getString("sdp")
                    peerConnection?.setRemoteDescription(object : SdpObserverAdapter() {
                        override fun onSetSuccess() {
                            state = State.CONNECTED
                            onState(state)
                        }
                        override fun onSetFailure(error: String) = fail(error, onState)
                    }, SessionDescription(SessionDescription.Type.ANSWER, answer))
                }
            } catch (t: Throwable) {
                fail(t.message ?: "No se pudo iniciar GPT-Live", onState)
            }
        }.start()
    }

    fun disconnect() {
        try {
            if (events?.state() == DataChannel.State.OPEN) {
                events?.send(DataChannel.Buffer(
                    java.nio.ByteBuffer.wrap(JSONObject().put("type", "session.close").toString().toByteArray()),
                    false
                ))
            }
        } catch (_: Throwable) {}
        try { events?.dispose() } catch (_: Throwable) {}
        try { peerConnection?.close() } catch (_: Throwable) {}
        try { localAudioTrack?.dispose() } catch (_: Throwable) {}
        try { localAudioSource?.dispose() } catch (_: Throwable) {}
        try { factory?.dispose() } catch (_: Throwable) {}
        try { audioModule?.release() } catch (_: Throwable) {}
        events = null
        peerConnection = null
        localAudioTrack = null
        localAudioSource = null
        factory = null
        audioModule = null
        state = State.IDLE
    }

    fun sendText(text: String) {
        val channel = events ?: return
        if (channel.state() != DataChannel.State.OPEN) return
        val event = JSONObject().apply {
            put("type", "conversation.item.create")
            put("item", JSONObject().apply {
                put("type", "message")
                put("role", "user")
                put("content", org.json.JSONArray().put(JSONObject().apply {
                    put("type", "input_text")
                    put("text", text)
                }))
            })
        }
        channel.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(event.toString().toByteArray()), false))
        val response = JSONObject().put("type", "response.create")
        channel.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(response.toString().toByteArray()), false))
    }

    private fun fail(message: String, onState: (State) -> Unit) {
        lastError = message
        state = State.ERROR
        onState(state)
    }

    private open class SdpObserverAdapter : org.webrtc.SdpObserver {
        override fun onCreateSuccess(description: SessionDescription) = Unit
        override fun onSetSuccess() = Unit
        override fun onCreateFailure(error: String) = Unit
        override fun onSetFailure(error: String) = Unit
    }
}
