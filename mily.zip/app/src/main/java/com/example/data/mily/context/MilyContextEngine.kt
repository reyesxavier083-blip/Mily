package com.example.data.mily.context

import com.example.data.model.ChatMessageEntity
import com.example.data.model.MemoryEntity

class MilyContextEngine {
    fun build(messages: List<ChatMessageEntity>, memories: List<MemoryEntity>, maxChars: Int = 16000): String {
        val out = StringBuilder()
        if (memories.isNotEmpty()) {
            out.append("MEMORIA DE APOYO:\n")
            memories.filter { it.isActive }.take(30).forEach { out.append("- [${it.category}] ${it.content}\n") }
        }
        if (messages.isNotEmpty()) {
            out.append("\nCONVERSACIÓN RECIENTE:\n")
            messages.takeLast(12).forEach { out.append("${it.role}: ${it.content.take(1200)}\n") }
        }
        return out.toString().take(maxChars)
    }
}
