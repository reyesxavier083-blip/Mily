package com.example.data.mily.security

enum class MilyPermission { READ_KNOWLEDGE, WRITE_KNOWLEDGE, READ_MEMORY, WRITE_MEMORY, DEVICE_CONTEXT, EXECUTE_TOOL }

class MilyPermissionGate(private val granted: Set<MilyPermission> = emptySet()) {
    fun allows(permission: MilyPermission): Boolean = permission in granted
}
