package com.example.data.ai
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.example.BuildConfig
import java.net.URI
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Per-device backend configuration; the client token is encrypted with Android Keystore. */
class MilyBackendSettings(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("mily_connection_settings", Context.MODE_PRIVATE)
    fun baseUrl(): String = prefs.getString("backend_base_url", null) ?: (normalizeBaseUrl(BuildConfig.MILY_BACKEND_URL.trim()) ?: "")
    fun saveBaseUrl(value: String) { prefs.edit().putString("backend_base_url", value.trim()).apply() }
    fun apiToken(): String {
        val value = prefs.getString("backend_token", null) ?: return ""
        return runCatching { decrypt(value) }.getOrElse { prefs.edit().remove("backend_token").apply(); "" }
    }
    fun saveApiToken(value: String) {
        if (value.isBlank()) prefs.edit().remove("backend_token").apply()
        else prefs.edit().putString("backend_token", encrypt(value.trim())).apply()
    }
    private fun encrypt(value: String): String {
        val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key())
        val body=c.doFinal(value.toByteArray(Charsets.UTF_8)); val iv=c.iv
        val packed=ByteArray(1+iv.size+body.size); packed[0]=iv.size.toByte()
        System.arraycopy(iv,0,packed,1,iv.size); System.arraycopy(body,0,packed,1+iv.size,body.size)
        return Base64.encodeToString(packed,Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String {
        val p=Base64.decode(value,Base64.NO_WRAP); require(p.isNotEmpty())
        val n=p[0].toInt() and 255; require(n in 12..16 && p.size>1+n)
        val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,p.copyOfRange(1,1+n)))
        return String(c.doFinal(p.copyOfRange(1+n,p.size)),Charsets.UTF_8)
    }
    private fun key(): SecretKey {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("mily.client.token.v1",null) as? SecretKey)?.let { return it }
        val gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder("mily.client.token.v1",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return gen.generateKey()
    }
    companion object {
        fun normalizeBaseUrl(raw: String): String? {
            val v=raw.trim(); if (v.isBlank() || v.any { it.isWhitespace() }) return null
            val u=runCatching { URI(v) }.getOrNull() ?: return null
            if (!u.scheme.equals("https",true) || u.host.isNullOrBlank() || u.rawUserInfo!=null || u.rawQuery!=null || u.rawFragment!=null) return null
            return v.trimEnd('/')+"/"
        }
    }
}
