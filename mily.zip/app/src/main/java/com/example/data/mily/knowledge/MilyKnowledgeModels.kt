package com.example.data.mily.knowledge

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class VectorStoreRequest(val name: String)

@JsonClass(generateAdapter = true)
data class KnowledgeSearchRequest(val vectorStoreId: String? = null, val query: String, val maxNumResults: Int = 8)

@JsonClass(generateAdapter = true)
data class KnowledgeSearchResponse(val results: List<KnowledgeResult> = emptyList())

@JsonClass(generateAdapter = true)
data class KnowledgeResult(val fileId: String? = null, val filename: String? = null, val score: Double? = null, val text: String? = null)
