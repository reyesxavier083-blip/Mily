package com.example.data.learning

import com.example.data.local.EpisodicMemoryDao
import com.example.data.local.MemoryDao
import com.example.data.local.SemanticMemoryDao
import com.example.data.model.EpisodicMemoryEntity
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryEntity
import com.example.data.model.SemanticMemoryEntity
import com.example.data.remote.GeminiApiClient
import com.example.data.remote.GeminiContent
import com.example.data.remote.GeminiGenerationConfig
import com.example.data.remote.GeminiPart
import com.example.data.remote.GeminiRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

class AutonomousLearningEngine(
    private val memoryDao: MemoryDao,
    private val episodicDao: EpisodicMemoryDao? = null,
    private val semanticDao: SemanticMemoryDao? = null
) {
    /**
     * Builds the augmented system prompt injecting active autonomous memories,
     * semantic facts and significant episodic context.
     */
    suspend fun enrichSystemPrompt(
        basePrompt: String,
        isAutonomousLearningEnabled: Boolean = true,
        deviceContext: String? = null
    ): String = withContext(Dispatchers.IO) {
        val activeMemories = if (isAutonomousLearningEnabled) memoryDao.getActiveMemoriesForPrompt() else emptyList()
        val semanticFacts = if (isAutonomousLearningEnabled) (semanticDao?.getActiveFactsForInjection(15) ?: emptyList()) else emptyList()
        val episodicEpisodes = if (isAutonomousLearningEnabled) (episodicDao?.getSignificantEpisodes(0.7f, 5) ?: emptyList()) else emptyList()

        if (activeMemories.isEmpty() && semanticFacts.isEmpty() && episodicEpisodes.isEmpty() && deviceContext.isNullOrBlank()) {
            return@withContext basePrompt
        }

        // Mark memories as accessed
        val memoryIds = activeMemories.map { it.id }
        if (memoryIds.isNotEmpty()) {
            memoryDao.updateLastAccessed(memoryIds)
        }

        val memoryBlock = buildString {
            if (activeMemories.isNotEmpty() || semanticFacts.isNotEmpty() || episodicEpisodes.isNotEmpty()) {
                append("\n\n[SISTEMA DE MEMORIA PERSISTENTE Y APRENDIZAJE AUTÓNOMO]")
                append("\nTienes memoria continua persistente aprendida de interacciones pasadas con el usuario:")

                if (semanticFacts.isNotEmpty()) {
                    append("\n\n• Conocimiento Semántico y Preferencias Consolidadas:\n")
                    semanticFacts.forEach { fact ->
                        append("   - [${fact.category}] ${fact.formattedFact}\n")
                        semanticDao?.recordSemanticRecall(fact.id)
                    }
                }

                if (activeMemories.isNotEmpty()) {
                    append("\n• Reglas y Ajustes de Usuario:\n")
                    val grouped = activeMemories.groupBy { it.category }
                    grouped.forEach { (catName, items) ->
                        val categoryEnum = try {
                            MemoryCategory.valueOf(catName)
                        } catch (e: Exception) {
                            MemoryCategory.PREFERENCE
                        }
                        append("   * ${categoryEnum.displayName}:\n")
                        items.forEach { memory ->
                            append("      - ${memory.content}\n")
                        }
                    }
                }

                if (episodicEpisodes.isNotEmpty()) {
                    append("\n• Contexto Episódico Relevante (Sesiones Anteriores):\n")
                    episodicEpisodes.forEach { ep ->
                        append("   - ${ep.summary} (${ep.detailedContext.take(100)})\n")
                        episodicDao?.recordEpisodeRecall(ep.id)
                    }
                }

                append("\n[FIN DE MEMORIA]")
            }

            if (!deviceContext.isNullOrBlank()) {
                append("\n\n")
                append(deviceContext)
            }
        }

        basePrompt + memoryBlock
    }

    /**
     * Autonomous analysis of user input to learn new preferences, facts, goals, or coding conventions.
     */
    suspend fun analyzeAndLearn(
        userPrompt: String,
        assistantResponse: String?,
        apiKey: String,
        sessionId: String? = null
    ) = withContext(Dispatchers.IO) {
        val extractedInsights = extractHeuristicInsights(userPrompt)

        if (extractedInsights.isNotEmpty()) {
            memoryDao.insertMemories(extractedInsights)
            // Also store as semantic memories
            extractedInsights.forEach { mem ->
                semanticDao?.insertSemanticMemory(
                    SemanticMemoryEntity(
                        subject = "Usuario",
                        predicate = if (mem.category == MemoryCategory.PREFERENCE.name) "prefiere" else "contexto",
                        objectValue = mem.content,
                        formattedFact = mem.content,
                        category = mem.category,
                        confidenceScore = mem.confidence
                    )
                )
            }
        }

        // Store episodic memory of this interaction
        if (assistantResponse != null && assistantResponse.isNotBlank()) {
            episodicDao?.insertEpisode(
                EpisodicMemoryEntity(
                    sessionId = sessionId,
                    summary = "Interacción: ${userPrompt.take(60)}...",
                    detailedContext = "Usuario: ${userPrompt.take(150)}\nAsistente: ${assistantResponse.take(200)}",
                    importanceScore = if (userPrompt.length > 50) 0.8f else 0.5f,
                    tags = extractTags(userPrompt)
                )
            )
        }

        // Deep AI-assisted semantic extraction if prompt is substantive
        if (userPrompt.length > 30 && apiKey.isNotBlank()) {
            try {
                val aiExtracted = extractAiInsights(userPrompt, apiKey)
                if (aiExtracted.isNotEmpty()) {
                    memoryDao.insertMemories(aiExtracted)
                    aiExtracted.forEach { mem ->
                        semanticDao?.insertSemanticMemory(
                            SemanticMemoryEntity(
                                subject = "Usuario",
                                predicate = "informó",
                                objectValue = mem.content,
                                formattedFact = mem.content,
                                category = mem.category,
                                confidenceScore = mem.confidence
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // Heuristic extraction was already saved; graceful fallback
            }
        }
    }

    private fun extractTags(text: String): String {
        val keywords = listOf("kotlin", "compose", "api", "gemini", "room", "arquitectura", "nexus", "database", "ui")
        val lower = text.lowercase(Locale.getDefault())
        return keywords.filter { lower.contains(it) }.joinToString(",")
    }

    /**
     * Fast local rule-based heuristic extraction for instant zero-latency learning
     */
    private fun extractHeuristicInsights(text: String): List<MemoryEntity> {
        val insights = mutableListOf<MemoryEntity>()
        val lower = text.lowercase(Locale.getDefault())

        // Preference detection
        val prefPatterns = listOf(
            Regex("(?:yo\\s+)?prefiero\\s+([^.,;\\n]+)", RegexOption.IGNORE_CASE),
            Regex("(?:siempre\\s+)?(?:responde|hazlo|escribe|explica)\\s+(?:en|con|de forma)\\s+([^.,;\\n]+)", RegexOption.IGNORE_CASE),
            Regex("(?:me\\s+gusta\\s+que\\s+([^.,;\\n]+))", RegexOption.IGNORE_CASE),
            Regex("(?:no\\s+me\\s+gusta\\s+([^.,;\\n]+))", RegexOption.IGNORE_CASE)
        )

        for (pattern in prefPatterns) {
            val match = pattern.find(text)
            if (match != null) {
                val detail = match.value.trim()
                if (detail.length in 8..140) {
                    insights.add(
                        MemoryEntity(
                            category = MemoryCategory.PREFERENCE.name,
                            content = "Preferencia: " + detail.replaceFirstChar { it.uppercase() },
                            confidence = 0.85f,
                            sourceContext = text.take(60)
                        )
                    )
                }
            }
        }

        // Project / Tech detection
        val projectPatterns = listOf(
            Regex("(?:estoy\\s+(?:programando|desarrollando|creando|haciendo)\\s+(?:un|una|el|la)\\s+[^.,;\\n]+)", RegexOption.IGNORE_CASE),
            Regex("(?:mi\\s+(?:proyecto|app|sistema|código|stack)\\s+(?:es|usa|está\\s+en)\\s+[^.,;\\n]+)", RegexOption.IGNORE_CASE),
            Regex("(?:trabajo\\s+con\\s+(?:kotlin|compose|python|javascript|typescript|flutter|react|java|swift|rust|go|c\\+\\+)[^.,;\\n]*)", RegexOption.IGNORE_CASE)
        )

        for (pattern in projectPatterns) {
            val match = pattern.find(text)
            if (match != null) {
                val detail = match.value.trim()
                if (detail.length in 10..150) {
                    insights.add(
                        MemoryEntity(
                            category = MemoryCategory.PROJECT.name,
                            content = "Contexto de Proyecto: " + detail.replaceFirstChar { it.uppercase() },
                            confidence = 0.9f,
                            sourceContext = text.take(60)
                        )
                    )
                }
            }
        }

        // Goal detection
        val goalPatterns = listOf(
            Regex("(?:mi\\s+meta|mi\\s+objetivo|quiero\\s+aprender|tengo\\s+que\\s+terminar|estoy\\s+estudiando)\\s+([^.,;\\n]+)", RegexOption.IGNORE_CASE)
        )

        for (pattern in goalPatterns) {
            val match = pattern.find(text)
            if (match != null) {
                val detail = match.value.trim()
                if (detail.length in 10..150) {
                    insights.add(
                        MemoryEntity(
                            category = MemoryCategory.GOAL.name,
                            content = "Meta/Interés: " + detail.replaceFirstChar { it.uppercase() },
                            confidence = 0.88f,
                            sourceContext = text.take(60)
                        )
                    )
                }
            }
        }

        return insights
    }

    /**
     * Deep semantic extraction using Gemini Flash Lite
     */
    private suspend fun extractAiInsights(
        text: String,
        apiKey: String
    ): List<MemoryEntity> {
        val prompt = "Analiza este mensaje del usuario y extrae CERO, UNO o DOS hechos clave permanentes sobre sus preferencias de formato, lenguajes que usa, nombre, profesión o metas que valga la pena recordar para personalizar futuras respuestas.\n" +
                "Si no hay datos memorables, responde ÚNICAMENTE con 'NINGUNO'.\n" +
                "Si hay datos, responde en líneas separadas con formato:\n" +
                "CATEGORIA|Detalle conciso\n" +
                "Donde CATEGORIA es una de: PREFERENCE, PROJECT, FACT, GOAL.\n\n" +
                "Mensaje del usuario:\n\"$text\""

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = prompt))
                )
            ),
            generationConfig = GeminiGenerationConfig(
                temperature = 0.1f,
                maxOutputTokens = 120
            )
        )

        val response = GeminiApiClient.service.generateContent(
            model = "gemini-3.1-flash-lite-preview",
            apiKey = apiKey,
            request = request
        )

        val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim() ?: ""
        if (responseText.contains("NINGUNO", ignoreCase = true) || responseText.isBlank()) {
            return emptyList()
        }

        val results = mutableListOf<MemoryEntity>()
        responseText.lines().forEach { line ->
            val parts = line.split("|")
            if (parts.size == 2) {
                val catStr = parts[0].trim().uppercase()
                val fact = parts[1].trim()
                val category = try {
                    MemoryCategory.valueOf(catStr).name
                } catch (e: Exception) {
                    MemoryCategory.PREFERENCE.name
                }
                if (fact.isNotBlank() && fact.length > 5) {
                    results.add(
                        MemoryEntity(
                            category = category,
                            content = fact,
                            confidence = 0.92f,
                            sourceContext = text.take(50)
                        )
                    )
                }
            }
        }

        return results
    }

    /**
     * Record explicit feedback from the user to improve future responses
     */
    suspend fun recordCorrection(
        originalPrompt: String,
        correctionNote: String
    ) = withContext(Dispatchers.IO) {
        val memory = MemoryEntity(
            category = MemoryCategory.CORRECTION.name,
            content = "Ajuste de respuesta: $correctionNote",
            confidence = 1.0f,
            sourceContext = originalPrompt.take(60)
        )
        memoryDao.insertMemory(memory)
    }

    companion object {
        fun extractMemoriesHeuristically(text: String): List<SemanticMemoryEntity> {
            val lower = text.lowercase(Locale.getDefault())
            val list = mutableListOf<SemanticMemoryEntity>()
            if (lower.contains("prefiero") || lower.contains("me gusta") || lower.contains("responde")) {
                list.add(
                    SemanticMemoryEntity(
                        subject = "Usuario",
                        predicate = "prefiere",
                        objectValue = text.take(60),
                        formattedFact = text,
                        category = "preference",
                        confidenceScore = 0.90f
                    )
                )
            }
            return list
        }
    }
}
