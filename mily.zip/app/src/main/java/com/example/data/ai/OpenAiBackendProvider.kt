package com.example.data.ai

import com.example.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class OpenAiBackendProvider : AiProvider {
    private val service: OpenAiBackendService? by lazy {
        val configuredUrl = BuildConfig.MILY_BACKEND_URL.trim()
        if (configuredUrl.isBlank() || configuredUrl == "http://10.0.2.2:8080/") {
            null
        } else {
            val baseUrl = if (configuredUrl.endsWith('/')) configuredUrl else "$configuredUrl/"
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(90, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()
            Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(OpenAiBackendService::class.java)
        }
    }

    override suspend fun generate(request: AiRequest): Result<AiResponse> {
        val api = service
            ?: return Result.failure(IllegalStateException("MILY_BACKEND_URL no está configurado."))

        return runCatching {
            val response = api.generate(
                OpenAiBackendRequest(
                    model = request.model,
                    instructions = request.systemPrompt,
                    input = request.history.map { OpenAiInputMessage(it.role, it.content) },
                    temperature = request.temperature,
                    maxOutputTokens = request.maxOutputTokens,
                    memoryFacts = request.memoryFacts,
                    enableFileSearch = request.enableFileSearch,
                    maxFileSearchResults = request.maxFileSearchResults
                )
            )
            val text = response.text ?: response.outputText
                ?: response.error
                ?: "El backend de Mily no devolvió texto."
            if (!response.error.isNullOrBlank()) {
                throw IllegalStateException(response.error)
            }
            AiResponse(text = text, tokenCount = response.tokenCount ?: text.split(" ").size)
        }
    }
}
