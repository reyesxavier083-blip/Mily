package com.example.data.ai
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

/** OpenAI API credentials stay on the backend; Android sends only the configured client token. */
class OpenAiBackendProvider(private val backendSettings: MilyBackendSettings) : AiProvider {
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(20,TimeUnit.SECONDS).readTimeout(90,TimeUnit.SECONDS).writeTimeout(30,TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val token=backendSettings.apiToken(); val req=chain.request().newBuilder()
                if (token.isNotBlank()) req.header("Authorization","Bearer $token")
                chain.proceed(req.build())
            }.build()
    }
    private fun service(): OpenAiBackendService? {
        val url=MilyBackendSettings.normalizeBaseUrl(backendSettings.baseUrl()) ?: return null
        return Retrofit.Builder().baseUrl(url).client(client).addConverterFactory(MoshiConverterFactory.create())
            .build().create(OpenAiBackendService::class.java)
    }
    override suspend fun generate(request: AiRequest): Result<AiResponse> {
        val api=service() ?: return Result.failure(IllegalStateException("Configura una URL HTTPS válida del backend de MILY en Ajustes."))
        return runCatching {
            val r=api.generate(OpenAiBackendRequest(
                model=request.model, instructions=request.systemPrompt,
                input=request.history.map { OpenAiInputMessage(it.role,it.content) },
                temperature=request.temperature, maxOutputTokens=request.maxOutputTokens,
                memoryFacts=request.memoryFacts, enableFileSearch=request.enableFileSearch,
                maxFileSearchResults=request.maxFileSearchResults))
            val text=r.text ?: r.outputText ?: r.error ?: "El backend de Mily no devolvió texto."
            if (!r.error.isNullOrBlank()) error(r.error)
            AiResponse(text=text, tokenCount=r.tokenCount ?: text.split(" ").size)
        }
    }
}
