package com.example.data.mily.memory

import com.example.data.local.EpisodicMemoryDao
import com.example.data.local.MemoryDao
import com.example.data.local.SemanticMemoryDao
import com.example.data.model.EpisodicMemoryEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.SemanticMemoryEntity
import kotlin.math.max

class CognitiveMemoryEngine(
    private val memoryDao: MemoryDao,
    private val episodicDao: EpisodicMemoryDao,
    private val semanticDao: SemanticMemoryDao
) {
    suspend fun recall(query: String, limit: Int = 12): CognitiveRecall {
        val terms = tokenize(query)
        val stable = memoryDao.getActiveMemoriesForPrompt()
        val semantic = semanticDao.getActiveFactsForInjection(60)
        val episodes = episodicDao.getRecentEpisodes(60)
        val stableHits = stable.map { it to score(terms, it.content, it.confidence.toDouble(), it.lastAccessedAt) }.filter { it.second > 0 }
        val semanticHits = semantic.map { it to score(terms, it.formattedFact, it.confidenceScore.toDouble(), it.updatedAt) }.filter { it.second > 0 }
        val episodeHits = episodes.map { it to score(terms, "${it.summary} ${it.detailedContext} ${it.tags}", it.importanceScore.toDouble(), it.timestamp) }.filter { it.second > 0 }
        val recalledStable = stableHits.sortedByDescending { it.second }.take(limit / 3 + 1).map { it.first }
        val recalledSemantic = semanticHits.sortedByDescending { it.second }.take(limit / 3 + 1).map { it.first }
        val recalledEpisodes = episodeHits.sortedByDescending { it.second }.take(limit / 3 + 1).map { it.first }
        if (recalledStable.isNotEmpty()) memoryDao.updateLastAccessed(recalledStable.map { it.id })
        recalledSemantic.forEach { semanticDao.recordSemanticRecall(it.id) }
        recalledEpisodes.forEach { episodicDao.recordEpisodeRecall(it.id) }
        return CognitiveRecall(recalledStable, recalledSemantic, recalledEpisodes)
    }

    suspend fun rememberEpisode(sessionId: String?, summary: String, context: String, importance: Float = 0.6f, tags: String = ""): EpisodicMemoryEntity {
        val item = EpisodicMemoryEntity(sessionId = sessionId, summary = summary.trim(), detailedContext = context.trim(), importanceScore = importance.coerceIn(0f, 1f), tags = tags)
        episodicDao.insertEpisode(item)
        return item
    }

    suspend fun rememberFact(subject: String, predicate: String, value: String, category: String = "FACT", confidence: Float = 0.8f): SemanticMemoryEntity {
        val s = subject.trim(); val p = predicate.trim(); val v = value.trim()
        val item = SemanticMemoryEntity(subject = s, predicate = p, objectValue = v, formattedFact = "$s $p $v", category = category, confidenceScore = confidence.coerceIn(0f, 1f))
        semanticDao.insertSemanticMemory(item)
        return item
    }

    fun render(recall: CognitiveRecall, maxChars: Int = 9000): String = buildString {
        append("MEMORIA COGNITIVA RELEVANTE:\n")
        recall.semantic.forEach { append("- [semántica:${it.category}] ${it.formattedFact}\n") }
        recall.stable.forEach { append("- [estable:${it.category}] ${it.content}\n") }
        recall.episodes.forEach { append("- [episodio] ${it.summary}\n") }
    }.take(maxChars)

    private fun tokenize(text: String): Set<String> = Regex("[\\p{L}\\p{N}]{3,}").findAll(text.lowercase()).map { it.value }.toSet()
    private fun score(terms: Set<String>, text: String, confidence: Double, timestamp: Long): Double {
        if (terms.isEmpty()) return 0.0
        val overlap = terms.count { it in tokenize(text) }.toDouble() / max(1, terms.size)
        val ageDays = ((System.currentTimeMillis() - timestamp).coerceAtLeast(0L) / 86_400_000.0)
        val recency = 1.0 / (1.0 + ageDays / 30.0)
        return overlap * (0.55 + 0.45 * confidence.coerceIn(0.0, 1.0)) * (0.65 + 0.35 * recency)
    }
}

data class CognitiveRecall(val stable: List<MemoryEntity>, val semantic: List<SemanticMemoryEntity>, val episodes: List<EpisodicMemoryEntity>)
