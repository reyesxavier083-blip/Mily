package com.example.data.ai

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

/** Contract for Mily's server-side WebRTC bridge. The OpenAI key never reaches Android. */
interface OpenAiRealtimeService {
    @Headers("Content-Type: application/sdp")
    @POST("v1/mily/realtime/calls")
    suspend fun createCall(@Body sdpOffer: RequestBody): ResponseBody
}
