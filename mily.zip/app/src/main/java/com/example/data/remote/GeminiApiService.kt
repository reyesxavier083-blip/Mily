package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.IOException
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>,
    @Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val role: String? = null, // "user" | "model"
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    val temperature: Float? = 0.7f,
    val topP: Float? = 0.95f,
    val topK: Int? = 40,
    val maxOutputTokens: Int? = 2048
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null,
    val usageMetadata: GeminiUsageMetadata? = null,
    val error: GeminiError? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null,
    val finishReason: String? = null,
    val index: Int? = null
)

@JsonClass(generateAdapter = true)
data class GeminiUsageMetadata(
    val promptTokenCount: Int? = null,
    val candidatesTokenCount: Int? = null,
    val totalTokenCount: Int? = null
)

@JsonClass(generateAdapter = true)
data class GeminiError(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)

sealed class ApiConnectionStatus {
    object Idle : ApiConnectionStatus()
    object Testing : ApiConnectionStatus()
    data class Success(val modelName: String, val latencyMs: Long) : ApiConnectionStatus()
    data class Error(val message: String, val httpCode: Int? = null) : ApiConnectionStatus()
}

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .build()

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(GeminiApiService::class.java)
    }

    /**
     * Valida la clave de API y la disponibilidad del modelo seleccionado en tiempo real.
     */
    suspend fun testConnection(apiKey: String, model: String = "gemini-3.5-flash"): ApiConnectionStatus {
        if (apiKey.isBlank()) {
            return ApiConnectionStatus.Error("No se proporcionó una clave de API.")
        }
        val startTime = System.currentTimeMillis()
        return try {
            val testRequest = GeminiRequest(
                contents = listOf(
                    GeminiContent(
                        role = "user",
                        parts = listOf(GeminiPart(text = "ping"))
                    )
                ),
                generationConfig = GeminiGenerationConfig(maxOutputTokens = 5)
            )
            val response = service.generateContent(
                model = model,
                apiKey = apiKey,
                request = testRequest
            )
            val latency = System.currentTimeMillis() - startTime
            if (response.candidates?.isNotEmpty() == true) {
                ApiConnectionStatus.Success(modelName = model, latencyMs = latency)
            } else if (response.error != null) {
                ApiConnectionStatus.Error(response.error.message ?: "Error desconocido retornado por Gemini.")
            } else {
                ApiConnectionStatus.Success(modelName = model, latencyMs = latency)
            }
        } catch (e: HttpException) {
            val code = e.code()
            val msg = when (code) {
                400 -> "Parámetros inválidos o modelo no disponible ($code)."
                403 -> "Clave de API no autorizada o expirada (403 Forbidden)."
                404 -> "Modelo no encontrado o ruta no válida (404 Not Found)."
                429 -> "Límite de cuota de API excedido (429 Rate Limit)."
                500, 503 -> "Servidor de Google Gemini temporalmente no disponible ($code)."
                else -> "Error HTTP $code: ${e.message()}"
            }
            ApiConnectionStatus.Error(msg, httpCode = code)
        } catch (e: IOException) {
            ApiConnectionStatus.Error("Error de conexión de red: ${e.localizedMessage ?: "Verifica tu conexión a internet"}")
        } catch (e: Exception) {
            ApiConnectionStatus.Error("Error inesperado: ${e.localizedMessage ?: e.javaClass.simpleName}")
        }
    }
}

