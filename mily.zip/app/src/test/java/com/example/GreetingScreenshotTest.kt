package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.onNodeWithText
import com.example.data.model.Persona
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GreetingScreenshotTest {
  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screen_renders() {
    composeTestRule.setContent {
      MyApplicationTheme {
        WelcomeScreen(
          persona = Persona.DEFAULT_PERSONAS.first(),
          onSamplePromptClick = {},
          onOpenTools = {},
          onOpenMemory = {},
          onOpenMilyEngines = {}
        )
      }
    }
    composeTestRule.onRoot().fetchSemanticsNode()
    composeTestRule.onNodeWithText("MILY", substring = true).fetchSemanticsNode()
  }
}
