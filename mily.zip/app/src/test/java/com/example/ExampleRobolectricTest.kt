package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.learning.AutonomousLearningEngine
import com.example.data.local.AppDatabase
import com.example.data.model.EpisodicMemoryEntity
import com.example.data.model.NexusEngineType
import com.example.data.model.SemanticMemoryEntity
import com.example.data.model.defaultNexusEngineTemplates
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var db: AppDatabase

  @Before
  fun createDb() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
      .allowMainThreadQueries()
      .build()
  }

  @After
  fun closeDb() {
    db.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NEXUS", appName)
  }

  @Test
  fun `episodic memory dao inserts and retrieves episodic interaction`() = runBlocking {
    val episode = EpisodicMemoryEntity(
      sessionId = "session-101",
      summary = "Discusión sobre arquitectura de memoria",
      detailedContext = "El usuario solicitó diseñar memoria episódica y semántica.",
      importanceScore = 0.95f,
      tags = "memoria,room,episodica"
    )
    db.episodicMemoryDao().insertEpisode(episode)

    val recent = db.episodicMemoryDao().getRecentEpisodes(10)
    assertEquals(1, recent.size)
    assertEquals("Discusión sobre arquitectura de memoria", recent.first().summary)
    assertEquals(0.95f, recent.first().importanceScore, 0.001f)
  }

  @Test
  fun `semantic memory dao stores facts and retrieves active facts`() = runBlocking {
    val semanticFact = SemanticMemoryEntity(
      subject = "Usuario",
      predicate = "prefiere",
      objectValue = "Kotlin y Jetpack Compose",
      formattedFact = "El usuario prefiere trabajar en Kotlin y Compose.",
      category = "PREFERENCE",
      confidenceScore = 0.98f
    )
    db.semanticMemoryDao().insertSemanticMemory(semanticFact)

    val active = db.semanticMemoryDao().getActiveFactsForInjection(10)
    assertEquals(1, active.size)
    assertEquals("Usuario", active.first().subject)
    assertEquals("prefiere", active.first().predicate)
    assertTrue(active.first().isActive)
  }

  @Test
  fun `autonomous learning heuristic extraction recognizes user preference`() {
    val input = "Prefiero que siempre respondas en Kotlin y de forma concisa."
    val extracted = AutonomousLearningEngine.extractMemoriesHeuristically(input)
    assertTrue("Should extract at least 1 memory", extracted.isNotEmpty())
    val memory = extracted.first()
    assertEquals("preference", memory.category)
    assertTrue(memory.confidenceScore >= 0.85f)
  }

  @Test
  fun `nexus engine suite provides research, simulation, and prediction templates`() {
    val templates = defaultNexusEngineTemplates
    assertTrue("Should contain templates for NEXUS engines", templates.isNotEmpty())
    val types = templates.map { it.type }.toSet()
    assertTrue(types.contains(NexusEngineType.RESEARCH))
    assertTrue(types.contains(NexusEngineType.SIMULATION))
    assertTrue(types.contains(NexusEngineType.PREDICTION))
    assertTrue(types.contains(NexusEngineType.AGENT_MESH))
  }
}
