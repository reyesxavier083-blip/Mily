package com.example.data.ai
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
class MilyBackendSettingsTest {
 @Test fun acceptsHttpsAndAddsSlash() {
  assertEquals("https://api.example.com/", MilyBackendSettings.normalizeBaseUrl("https://api.example.com"))
 }
 @Test fun rejectsHttpAndUnsafeUrls() {
  listOf("http://api.example.com","not-a-url","https://user:pass@api.example.com","https://api.example.com/?token=x","https://api.example.com/#x")
   .forEach { assertNull(MilyBackendSettings.normalizeBaseUrl(it)) }
 }
}
