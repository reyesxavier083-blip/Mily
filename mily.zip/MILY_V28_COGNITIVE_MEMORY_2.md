# Mily V28 — Memoria Cognitiva 2.0

## Objetivo
Convertir la memoria cognitiva de Mily en una capa de aprendizaje explícito y controlado, evitando duplicados y evitando inferir información sensible.

## Cambios
- Upsert semántico por `subject + predicate`.
- Actualización de confianza y `updatedAt` cuando un recuerdo existente se confirma.
- Extracción heurística de afirmaciones explícitas de baja sensibilidad: gustos, preferencias y nombre preferido.
- No se extraen contraseñas, tokens, API keys, datos bancarios, domicilio, dirección ni teléfono.
- El aprendizaje ocurre después de una respuesta GPT, sin bloquear la conversación.
- Se conserva el fallback de memoria de V27.

## Flujo
`mensaje del usuario → recuperación cognitiva → GPT → respuesta → extracción explícita → upsert semántico + episodio`

## Nota de compilación
Esta etapa modifica código fuente y documentación. Debe validarse con el Gradle/Android SDK del entorno de desarrollo antes de declarar un APK compilado.
