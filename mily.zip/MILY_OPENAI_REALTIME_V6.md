# Mily OpenAI Realtime V6 — Historial de voz persistente

## Cambios
- Los finales de transcripción de entrada (`conversation.item.input_audio_transcription.completed`) se guardan como mensajes `user`.
- Los finales de transcripción de salida (`response.output_audio_transcript.done` / `response.output_text.done`) se guardan como mensajes `model`.
- Se añadió deduplicación de los últimos mensajes para evitar guardar dos veces el mismo texto cuando llegan eventos equivalentes.
- Se conserva el historial Room existente; no se cambió el esquema de la base de datos.
- La sesión Live habilita `gpt-live-transcribe` para transcripción de entrada y español como idioma esperado.
- Los eventos delta siguen alimentando la vista de transcripción, pero no se persisten hasta recibir el evento final.

## Validación
- El proyecto contiene el wrapper de Gradle en la estructura exportada de la versión anterior, pero este paquete no incluye el ejecutable `gradlew`; por ello no fue posible ejecutar `compileDebugKotlin` en este entorno.
- Se revisaron los cambios de Kotlin y no se modificó el esquema Room.

## Referencias técnicas
La documentación actual de OpenAI describe los eventos `conversation.item.input_audio_transcription.delta` y `conversation.item.input_audio_transcription.completed` para transcripción de entrada, y `response.output_audio_transcript.delta/done` para las transcripciones de salida en conversaciones de voz. También indica que GPT-Live es el flujo recomendado para nuevas aplicaciones conversacionales de voz.
