# Mily V25 — Consolidación completa V1–V24

## Objetivo
Cerrar la cadena de evolución V1–V24 en una base única y preparada para continuar el desarrollo sin perder las funciones acumuladas.

## Correcciones de consolidación
- Identidad de proyecto corregida de NEXUS a Mily en metadata y nombre visible de la app.
- `versionCode` Android actualizado a 25 y `versionName` a 1.25.0.
- Se conserva Room como memoria local y el backend como capa de coordinación.
- Se conserva File Search/Vector Store.
- Se conserva Tool Gateway con allowlist.
- Se conserva GPT-Live/WebRTC.
- Se añade soporte de Conversations API para nuevas sesiones.
- Responses puede asociarse a `conversationId` o `sessionId`.
- Se añade configuración opcional de Prompt mediante `MILY_PROMPT_ID`.
- Se añade Web Search opcional mediante `enableWebSearch`.
- Se añade Moderation opcional por solicitud; las solicitudes marcadas se bloquean antes de Responses.
- Se mantiene la clave de OpenAI exclusivamente en backend.

## Ruta de arquitectura
Android → Backend Mily → Responses / Conversations / File Search / Web Search / GPT-Live

## Migración OpenAI
La documentación oficial actual indica que Assistants API fue retirada el 26 de agosto de 2026 y que las nuevas integraciones deben usar Responses API; la arquitectura equivalente usa Prompts, Conversations y Responses. La consolidación V25 sigue esa dirección.

## Variables de entorno
```text
OPENAI_API_KEY=...
MILY_DEFAULT_MODEL=gpt-6-astra
MILY_REALTIME_MODEL=gpt-live-1
MILY_PROMPT_ID=pmpt_...
MILY_VECTOR_STORE_ID=vs_...
MILY_PORT=8080
```

## Validación
- Validar sintaxis JavaScript con `node --check`.
- Ejecutar `./verify-mily.sh` en un entorno con Java, Android SDK y acceso a dependencias.
- No declarar APK compilado hasta ejecutar realmente `assembleDebug`.
