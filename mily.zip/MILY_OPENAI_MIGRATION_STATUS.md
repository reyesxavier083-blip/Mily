# Mily — estado de migración OpenAI

## V17
Migración consolidada V8–V17 implementada en el árbol actual.

- Responses API + File Search
- GPT-Live WebRTC bridge
- memoria local + memoria de coordinación backend
- Tool Gateway con allowlist
- Context Engine
- orquestación de rutas
- permisos Android
- conocimiento/Vector Stores
- modelo de backend por defecto: gpt-6-astra
- modelo de voz: gpt-live-1

Gemini permanece como compatibilidad para sesiones/código legado; no es la ruta preferida de nuevas sesiones.
