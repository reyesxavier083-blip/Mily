# Mily V7 — Memoria inteligente + File Search

V7 conecta la memoria local persistente de Room con el backend de OpenAI y deja preparado File Search en Responses API.

## Memoria
- `MemoryDao.getActiveMemoriesForPrompt()` aporta memoria activa local.
- `SemanticMemoryDao.getActiveFactsForInjection()` aporta hechos semánticos.
- Se envían al backend como contexto de apoyo, separados de las instrucciones del sistema.
- Se limitan a 30 elementos para controlar contexto y coste.

## File Search
El backend usa el tool hospedado `file_search` de Responses API cuando existe `MILY_VECTOR_STORE_ID`.

Variables:
- `MILY_VECTOR_STORE_ID`: ID del vector store de Mily.
- `MILY_MAX_FILE_SEARCH_RESULTS` no es necesaria; el cliente puede pedir un máximo por solicitud y el backend lo limita a 20.

Si no hay vector store configurado, la app sigue funcionando con memoria Room y Responses API normal.

## Seguridad
La API key y el vector store ID permanecen en el backend. El APK no contiene la clave de OpenAI.

## Nota
File Search requiere que previamente exista un vector store con archivos procesados. V7 integra el consumo del tool; la carga/gestión de archivos puede añadirse como etapa posterior.
