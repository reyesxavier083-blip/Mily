# Mily — GPT-Live V5

V5 conecta la capa WebRTC nativa con el ciclo de eventos de GPT-Live y la UI de Mily.

## Cambios

- Espera a que termine la recolección ICE antes de enviar el SDP.
- Usa `POST /v1/mily/live/sessions` con `session` + `transport` en JSON, siguiendo el flujo oficial de Live WebRTC.
- El cliente mantiene la clave de OpenAI fuera del APK.
- Eventos `session.started`, `session.closed`, VAD y transcripción se exponen a la interfaz.
- La UI muestra el estado de GPT-Live y el último fragmento de transcripción recibido.
- Al desconectar se envía `session.close` cuando el canal está abierto.
- El backend admite opcionalmente `MILY_SAFETY_IDENTIFIER` para el encabezado `OpenAI-Safety-Identifier`.

## Fuente técnica

La implementación sigue el flujo documentado de OpenAI: crear PeerConnection, añadir micrófono, crear `oai-events`, generar SDP, esperar ICE, crear la sesión Live en servidor y aplicar `transport.sdp` como respuesta remota.
