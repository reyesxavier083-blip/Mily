import React, { useState } from 'react';
import {
  Layers,
  ChevronRight,
  ChevronDown,
  Cpu,
  Layout,
  Wrench,
  Sliders,
  CheckCircle2,
  Sparkles,
  Info,
  ExternalLink,
} from 'lucide-react';
import { MODULAR_SYSTEM_BRANCHES } from '../data/modularSystemData';

interface ModularTreeViewerProps {
  onModuleAction?: (moduleName: string) => void;
}

export const ModularTreeViewer: React.FC<ModularTreeViewerProps> = ({ onModuleAction }) => {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    CORE: true,
    UI: true,
    TOOLS: true,
    SETTINGS: false,
  });

  const [selectedModule, setSelectedModule] = useState<{
    name: string;
    category: string;
    description: string;
    status: string;
    version?: string;
  } | null>(null);

  const toggleCategory = (cat: string) => {
    setExpandedCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'CORE':
        return Cpu;
      case 'UI':
        return Layout;
      case 'TOOLS':
        return Wrench;
      case 'SETTINGS':
        return Sliders;
      default:
        return Layers;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'CORE':
        return 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10';
      case 'UI':
        return 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10';
      case 'TOOLS':
        return 'text-amber-400 border-amber-500/30 bg-amber-500/10';
      case 'SETTINGS':
        return 'text-purple-400 border-purple-500/30 bg-purple-500/10';
      default:
        return 'text-slate-400 border-slate-700 bg-slate-800';
    }
  };

  return (
    <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-800/90 rounded-2xl p-5 shadow-2xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 gap-2">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Arquitectura Modular de MILY
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                16 Submódulos Vivos
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Estructura jerárquica de subsistemas CORE, UI, TOOLS y SETTINGS
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() =>
              setExpandedCategories({ CORE: true, UI: true, TOOLS: true, SETTINGS: true })
            }
            type="button"
            className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
          >
            Expandir todo
          </button>
          <button
            onClick={() =>
              setExpandedCategories({ CORE: false, UI: false, TOOLS: false, SETTINGS: false })
            }
            type="button"
            className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
          >
            Colapsar
          </button>
        </div>
      </div>

      {/* Interactive Tree View */}
      <div className="space-y-3 font-mono text-xs">
        {/* Root Node: MILY */}
        <div className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-950/80 border border-slate-800/90 text-slate-200">
          <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="font-bold text-sm tracking-wider text-cyan-300">MILY</span>
          <span className="text-[10px] text-slate-500 uppercase tracking-widest ml-2">
            [Intelligent Modular Ecosystem v18 / v25]
          </span>
        </div>

        {/* Branches */}
        <div className="pl-3 sm:pl-5 space-y-3 border-l-2 border-slate-800 ml-3">
          {MODULAR_SYSTEM_BRANCHES.map((branch) => {
            const CatIcon = getCategoryIcon(branch.category);
            const colorClass = getCategoryColor(branch.category);
            const isExpanded = !!expandedCategories[branch.category];

            return (
              <div key={branch.category} className="space-y-2">
                {/* Branch Header */}
                <button
                  onClick={() => toggleCategory(branch.category)}
                  type="button"
                  className="w-full flex items-center justify-between p-2 rounded-xl bg-slate-950/50 hover:bg-slate-800/60 border border-slate-800/80 transition-colors text-left group cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    {isExpanded ? (
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    )}
                    <div className={`p-1.5 rounded-lg border ${colorClass}`}>
                      <CatIcon className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <span className="font-bold text-white">{branch.category}</span>
                      <span className="text-[11px] text-slate-400 font-sans ml-2 hidden sm:inline">
                        — {branch.description}
                      </span>
                    </div>
                  </div>

                  <span className="text-[10px] text-slate-500">
                    {branch.modules.length} módulos
                  </span>
                </button>

                {/* Submodules */}
                {isExpanded && (
                  <div className="pl-6 space-y-1.5 border-l border-dashed border-slate-800 ml-4">
                    {branch.modules.map((mod, modIdx) => (
                      <div
                        key={`${branch.category}-${mod.name}-${modIdx}`}
                        onClick={() =>
                          setSelectedModule({
                            ...mod,
                            category: branch.category,
                          })
                        }
                        className="p-2 rounded-xl bg-slate-950/40 hover:bg-slate-850/80 border border-slate-800/60 flex items-center justify-between gap-2 transition-all cursor-pointer group/mod"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />
                          <span className="font-semibold text-slate-200 group-hover/mod:text-cyan-300 transition-colors truncate">
                            {mod.name}
                          </span>
                          <span className="text-[10px] text-slate-500 font-sans truncate hidden md:inline">
                            {mod.description}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {mod.version && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                              {mod.version}
                            </span>
                          )}
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase font-bold">
                            {mod.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Module Detail Modal / Drawer */}
      {selectedModule && (
        <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                {selectedModule.category} / {selectedModule.name}
              </span>
              <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Operativo
              </span>
            </div>
            <p className="text-xs text-slate-300 font-sans">{selectedModule.description}</p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onModuleAction && (
              <button
                onClick={() => {
                  onModuleAction(selectedModule.name);
                  setSelectedModule(null);
                }}
                type="button"
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Ejecutar en Mily
              </button>
            )}
            <button
              onClick={() => setSelectedModule(null)}
              type="button"
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
