import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  MessageSquare,
  Briefcase,
  Folder,
  Wrench,
  Zap,
  Activity,
  Settings,
  Sparkles,
  ArrowRight,
  Play,
  CheckCircle2,
  Clock,
  ExternalLink,
  Plus,
  RefreshCw,
  Search,
  Sliders,
  Filter,
  FileCode,
  FileText,
  Database,
  X,
} from 'lucide-react';
import {
  ProjectItem,
  AutomationItem,
  FileRecord,
  Persona,
  ChatMessage,
  SystemStatus,
} from '../types/mily';

interface ModularDashboardProps {
  activePersona: Persona;
  projects: ProjectItem[];
  automations: AutomationItem[];
  files: FileRecord[];
  systemStatus: SystemStatus | null;
  lastMessage?: ChatMessage;
  onOpenChat: () => void;
  onOpenVoice: () => void;
  onOpenTools: (tab?: string) => void;
  onOpenMemory: () => void;
  onOpenSettings: () => void;
  onRunAutomation: (id: string) => void;
  onToggleAutomation: (id: string) => void;
  onCreateProject: () => void;
  onSelectPrompt: (prompt: string) => void;
}

export const ModularDashboard: React.FC<ModularDashboardProps> = ({
  activePersona,
  projects,
  automations,
  files,
  systemStatus,
  lastMessage,
  onOpenChat,
  onOpenVoice,
  onOpenTools,
  onOpenMemory,
  onOpenSettings,
  onRunAutomation,
  onToggleAutomation,
  onCreateProject,
  onSelectPrompt,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'dev' | 'tools' | 'system'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [previewFile, setPreviewFile] = useState<FileRecord | null>(null);

  const filteredProjects = projects.filter(
    (p) =>
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const filteredFiles = files.filter(
    (f) =>
      f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.path.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-full space-y-6">
      {/* Category Pills & Quick Filter Bar */}
      <motion.div
        layout
        className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-3 rounded-2xl shadow-xl"
      >
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <span className="text-xs font-mono text-slate-400 mr-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            VISTAS:
          </span>
          {[
            { id: 'all', label: 'Todos los Paneles' },
            { id: 'dev', label: 'Proyectos & Código' },
            { id: 'tools', label: 'Herramientas & Auto' },
            { id: 'system', label: 'Sistema & Memoria' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              type="button"
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer whitespace-nowrap relative ${
                selectedCategory === cat.id
                  ? 'text-cyan-300 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              {selectedCategory === cat.id && (
                <motion.div
                  layoutId="activeCategoryPill"
                  className="absolute inset-0 bg-cyan-500/20 border border-cyan-500/40 rounded-xl shadow-[0_0_10px_rgba(34,211,238,0.2)]"
                  transition={{ type: 'spring', damping: 25, stiffness: 350 }}
                />
              )}
              <span className="relative z-10">{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Search input for files & projects */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar proyectos o archivos..."
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-950/80 border border-slate-800 rounded-xl text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50"
          />
        </div>
      </motion.div>

      {/* Grid of Modular Cards with Layout Animations */}
      <motion.div
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5"
      >
        <AnimatePresence>
          {/* CARD 1: ASISTENTE & CHAT EN VIVO */}
          {(selectedCategory === 'all' || selectedCategory === 'system') && (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="relative bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 hover:border-cyan-500/40 rounded-3xl p-5 shadow-xl transition-colors duration-300 flex flex-col justify-between group overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />

              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 group-hover:scale-110 transition-transform">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                        Asistente Mily
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
                      </h3>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Modo: {activePersona.name}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={onOpenChat}
                    type="button"
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
                    title="Abrir chat completo"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Last interaction snippet */}
                <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 text-xs text-slate-300 mb-3 leading-relaxed">
                  <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Última Interacción</span>
                    <span className="text-slate-500">{lastMessage ? lastMessage.timestamp : 'Reciente'}</span>
                  </div>
                  <p className="line-clamp-3 italic text-slate-300">
                    {lastMessage
                      ? lastMessage.content.slice(0, 140) + '...'
                      : activePersona.greeting}
                  </p>
                </div>

                {/* Starter prompt chips */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                    Sugerencias rápidas:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {activePersona.suggestedPrompts.slice(0, 2).map((prompt, idx) => (
                      <button
                        key={idx}
                        onClick={() => onSelectPrompt(prompt)}
                        type="button"
                        className="px-2.5 py-1 rounded-lg text-[11px] bg-slate-800/80 hover:bg-cyan-500/10 hover:text-cyan-300 text-slate-300 border border-slate-800 hover:border-cyan-500/30 transition-all text-left truncate max-w-full cursor-pointer"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <button
                  onClick={onOpenVoice}
                  type="button"
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition-all cursor-pointer hover:shadow-[0_0_12px_rgba(52,211,153,0.25)]"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Hablar por Voz</span>
                </button>
                <button
                  onClick={onOpenChat}
                  type="button"
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition-all cursor-pointer shadow-md shadow-cyan-600/30 hover:scale-102"
                >
                  <span>Ver Chat</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          )}

          {/* CARD 2: PROYECTOS & WORKSPACE */}
          {(selectedCategory === 'all' || selectedCategory === 'dev') && (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="relative bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 hover:border-indigo-500/40 rounded-3xl p-5 shadow-xl transition-colors duration-300 flex flex-col justify-between group overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 group-hover:scale-110 transition-transform">
                      <Briefcase className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Proyectos Mily</h3>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {projects.length} workspaces sincronizados
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={onCreateProject}
                    type="button"
                    className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20 text-xs font-medium border border-indigo-500/30 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Nuevo</span>
                  </button>
                </div>

                {/* Projects list */}
                <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                  {filteredProjects.map((p, pIdx) => (
                    <div
                      key={`proj-${p.id}-${pIdx}`}
                      className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-indigo-500/30 transition-all group/item"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-semibold text-slate-200 group-hover/item:text-indigo-300 transition-colors truncate">
                          {p.title}
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                          {p.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mb-2">
                        {p.description}
                      </p>
                      {/* Animated Progress bar */}
                      <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden flex items-center border border-slate-800">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${p.progress}%` }}
                          transition={{ duration: 1, ease: 'easeOut' }}
                          className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full"
                        />
                      </div>
                      <div className="flex justify-between items-center mt-1 text-[10px] font-mono text-slate-500">
                        <span>Progreso: {p.progress}%</span>
                        <span>{p.lastUpdated}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span className="font-mono text-[11px] text-indigo-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Room DB Sincronizado
                </span>
                <button
                  onClick={() => onSelectPrompt('Analiza el estado del proyecto Mily Android v25 y resume sus tareas')}
                  type="button"
                  className="text-indigo-400 hover:text-indigo-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Auditar</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}

          {/* CARD 3: ARCHIVOS & VECTOR STORE (MÓDULOS FLOTANTES CON EXPANSIÓN CONTINUA) */}
          {(selectedCategory === 'all' || selectedCategory === 'dev') && (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="relative bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 hover:border-blue-500/40 rounded-3xl p-5 shadow-xl transition-colors duration-300 flex flex-col justify-between group overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 group-hover:scale-110 transition-transform">
                      <Folder className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Archivos & Vector Store</h3>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Base de conocimiento RAG
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-300 border border-blue-500/20">
                    File Search
                  </span>
                </div>

                {/* File records as interactive floating modules */}
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {filteredFiles.map((f, fIdx) => (
                    <motion.div
                      layoutId={`file-card-${f.id}`}
                      key={`file-${f.id}-${fIdx}`}
                      onClick={() => setPreviewFile(f)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="p-2.5 rounded-2xl bg-slate-950/80 hover:bg-slate-850/90 border border-slate-800/90 hover:border-blue-500/40 flex items-center justify-between cursor-pointer transition-colors shadow-sm"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {f.type === 'code' ? (
                          <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                        ) : (
                          <FileText className="w-4 h-4 text-blue-400 shrink-0" />
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-mono text-slate-200 truncate">{f.name}</p>
                          <p className="text-[10px] font-mono text-slate-500 truncate">{f.path}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0 ml-2">
                        {f.vectorIndexed && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-[0_0_6px_rgba(52,211,153,0.3)]">
                            RAG
                          </span>
                        )}
                        <span className="text-[10px] font-mono text-slate-400">{f.size}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 font-mono">
                  {files.filter((f) => f.vectorIndexed).length} archivos vectorizados
                </span>
                <button
                  onClick={() => onSelectPrompt('Revisa los archivos del proyecto y dame un mapa de arquitectura')}
                  type="button"
                  className="text-blue-400 hover:text-blue-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Explorar</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}

          {/* CARD 4: HERRAMIENTAS & TOOL GATEWAY */}
          {(selectedCategory === 'all' || selectedCategory === 'tools') && (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="relative bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 hover:border-amber-500/40 rounded-3xl p-5 shadow-xl transition-colors duration-300 flex flex-col justify-between group overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 group-hover:scale-110 transition-transform">
                      <Wrench className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Tool Gateway</h3>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Ejecución autorizada
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => onOpenTools()}
                    type="button"
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Abrir caja de herramientas completa"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Quick Tool launchers */}
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'calc', name: 'Calculadora Científica', tab: 'calculator', desc: 'Fórmulas y desglose' },
                    { id: 'ast', name: 'Refactorizador AST', tab: 'code', desc: 'Análisis estático' },
                    { id: 'api', name: 'Simulador Responses', tab: 'apiPrompts', desc: 'gpt-6 & gemini' },
                    { id: 'diag', name: 'Telemetría del Núcleo', tab: 'diagnostics', desc: 'Latencia y motores' },
                  ].map((tool) => (
                    <motion.button
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      key={tool.id}
                      onClick={() => onOpenTools(tool.tab)}
                      type="button"
                      className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-amber-500/40 text-left transition-all group/item cursor-pointer"
                    >
                      <div className="text-xs font-semibold text-slate-200 group-hover/item:text-amber-300 transition-colors">
                        {tool.name}
                      </div>
                      <div className="text-[10px] text-slate-500">{tool.desc}</div>
                    </motion.button>
                  ))}
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Allowlist Activa
                </span>
                <button
                  onClick={() => onOpenTools('apiPrompts')}
                  type="button"
                  className="text-amber-400 hover:text-amber-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Probar API</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}

          {/* CARD 5: AUTOMATIZACIONES */}
          {(selectedCategory === 'all' || selectedCategory === 'tools') && (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="relative bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 hover:border-teal-500/40 rounded-3xl p-5 shadow-xl transition-colors duration-300 flex flex-col justify-between group overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400 group-hover:scale-110 transition-transform">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Automatizaciones</h3>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {automations.filter((a) => a.active).length} triggers en ejecución
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/20">
                    Pipelines
                  </span>
                </div>

                {/* Automations list */}
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {automations.map((auto, aIdx) => (
                    <div
                      key={`auto-${auto.id}-${aIdx}`}
                      className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 flex items-center justify-between gap-2"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-semibold text-slate-200 truncate flex items-center gap-1.5">
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              auto.active ? 'bg-teal-400 shadow-[0_0_8px_#2dd4bf]' : 'bg-slate-600'
                            }`}
                          />
                          {auto.name}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">{auto.trigger}</div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <motion.button
                          whileHover={{ scale: 1.15 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => onRunAutomation(auto.id)}
                          type="button"
                          className="p-1.5 rounded-xl bg-slate-800 hover:bg-teal-500/20 text-slate-300 hover:text-teal-300 transition-colors cursor-pointer"
                          title="Ejecutar constelación de proceso"
                        >
                          <Play className="w-3 h-3 fill-current" />
                        </motion.button>
                        <button
                          onClick={() => onToggleAutomation(auto.id)}
                          type="button"
                          className={`w-7 h-4 rounded-full transition-colors relative cursor-pointer ${
                            auto.active ? 'bg-teal-600' : 'bg-slate-800'
                          }`}
                        >
                          <div
                            className={`w-3 h-3 rounded-full bg-white transition-transform absolute top-0.5 ${
                              auto.active ? 'translate-x-3.5' : 'translate-x-0.5'
                            }`}
                          />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <span className="font-mono text-[11px]">Sincronización autónoma: ON</span>
                <button
                  onClick={() => onRunAutomation('auto-1')}
                  type="button"
                  className="text-teal-400 hover:text-teal-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Disparar proceso</span>
                  <RefreshCw className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}

          {/* CARD 6: SISTEMA & TELEMETRÍA */}
          {(selectedCategory === 'all' || selectedCategory === 'system') && (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="relative bg-slate-900/70 backdrop-blur-xl border border-slate-800/80 hover:border-purple-500/40 rounded-3xl p-5 shadow-xl transition-colors duration-300 flex flex-col justify-between group overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 group-hover:scale-110 transition-transform">
                      <Activity className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Sistema & Núcleo Mily</h3>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Kernel {systemStatus?.version || '18.4.2 / v25'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={onOpenMemory}
                    type="button"
                    className="px-2.5 py-1 rounded-xl bg-purple-500/10 text-purple-300 hover:bg-purple-500/20 text-xs font-mono border border-purple-500/30 transition-colors cursor-pointer"
                  >
                    Memoria Hub
                  </button>
                </div>

                {/* System vitals with animated pulse */}
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Motor Cognitivo</div>
                    <div className="text-xs font-bold font-mono text-purple-300 mt-0.5 truncate">
                      {systemStatus?.model || 'gemini-3.8-flash'}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Latencia Estimada</div>
                    <div className="text-xs font-bold font-mono text-emerald-400 mt-0.5">
                      ~140 ms
                    </div>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Estado General</div>
                    <div className="text-xs font-bold font-mono text-emerald-400 mt-0.5 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      ONLINE
                    </div>
                  </div>
                  <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
                    <div className="text-[10px] font-mono text-slate-500 uppercase">Tiempo Activo</div>
                    <div className="text-xs font-bold font-mono text-slate-200 mt-0.5">
                      {Math.floor((systemStatus?.uptime || 120) / 60)}m {(Math.floor(systemStatus?.uptime || 120) % 60)}s
                    </div>
                  </div>
                </div>

                {/* Subsystems badges */}
                <div className="flex flex-wrap gap-1">
                  {['Nexus: OK', 'Semántica: Activa', 'Episódica: OK', 'Voz: Lista'].map((sub, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-800/80 text-slate-300 border border-slate-700/60"
                    >
                      {sub}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-[11px] font-mono text-slate-400">
                  Auditoría de subsistemas
                </span>
                <button
                  onClick={onOpenSettings}
                  type="button"
                  className="text-purple-400 hover:text-purple-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Ajustes</span>
                  <Settings className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* CONTINUOUS FILE EXPANSION MODAL (archivo → expansión → información → acciones) */}
      <AnimatePresence>
        {previewFile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl"
          >
            <motion.div
              layoutId={`file-card-${previewFile.id}`}
              initial={{ scale: 0.85, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.85, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/50 rounded-3xl p-6 shadow-2xl shadow-cyan-950/60 space-y-4 overflow-hidden"
            >
              {/* Scanline beam traversing */}
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-[shimmer_2s_infinite]" />

              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5 font-mono text-sm text-cyan-300 font-bold">
                  <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30">
                    <Folder className="w-4 h-4 text-cyan-400" />
                  </div>
                  <span>{previewFile.name}</span>
                </div>
                <button
                  onClick={() => setPreviewFile(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* File details */}
              <div className="space-y-2.5 text-xs font-mono text-slate-300 bg-slate-950/80 p-4 rounded-2xl border border-slate-800/80">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Ruta de acceso:</span>
                  <span className="text-slate-300 truncate max-w-xs">{previewFile.path}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Tamaño del archivo:</span>
                  <span className="text-cyan-300 font-bold">{previewFile.size}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-500">Vector Store RAG:</span>
                  <span
                    className={
                      previewFile.vectorIndexed
                        ? 'text-emerald-400 font-bold flex items-center gap-1'
                        : 'text-slate-500'
                    }
                  >
                    {previewFile.vectorIndexed && <CheckCircle2 className="w-3.5 h-3.5" />}
                    {previewFile.vectorIndexed ? 'INDEXADO Y LISTO' : 'NO VECTORIZADO'}
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Última modificación:</span>
                  <span>{previewFile.lastModified}</span>
                </div>
              </div>

              {/* Actions with continuous transition */}
              <div className="pt-2 flex flex-col sm:flex-row justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPreviewFile(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cerrar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSelectPrompt(`Mily, realiza un análisis técnico detallado del archivo ${previewFile.name} y resume su lógica.`);
                    setPreviewFile(null);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-semibold text-xs transition-all cursor-pointer shadow-lg shadow-cyan-600/30 hover:scale-102 flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Analizar archivo con Mily</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
