import React from 'react';
import { Sparkles, Code, Lightbulb, Compass } from 'lucide-react';

interface QuickPromptChipsProps {
  prompts: string[];
  onSelectPrompt: (prompt: string) => void;
}

export const QuickPromptChips: React.FC<QuickPromptChipsProps> = ({
  prompts,
  onSelectPrompt,
}) => {
  if (!prompts || prompts.length === 0) return null;

  return (
    <div className="flex items-center gap-2 overflow-x-auto py-2 px-1 scrollbar-none">
      <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium whitespace-nowrap pr-1 select-none">
        <Sparkles className="w-3.5 h-3.5 text-emerald-400/80" />
        <span>Sugerencias:</span>
      </div>
      {prompts.map((prompt, index) => (
        <button
          key={index}
          onClick={() => onSelectPrompt(prompt)}
          type="button"
          className="px-3 py-1.5 rounded-full text-xs text-slate-300 bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/40 hover:text-emerald-300 transition-all whitespace-nowrap cursor-pointer shrink-0 shadow-sm"
        >
          {prompt}
        </button>
      ))}
    </div>
  );
};
