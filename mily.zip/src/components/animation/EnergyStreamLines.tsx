import React from 'react';
import { motion } from 'motion/react';

interface EnergyStreamLinesProps {
  intensity: 'cinematic' | 'balanced' | 'performance';
}

export const EnergyStreamLines: React.FC<EnergyStreamLinesProps> = ({ intensity }) => {
  if (intensity === 'performance') return null;

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
      {/* Top horizontal beam */}
      <motion.div
        animate={{ x: ['-100%', '200%'] }}
        transition={{ repeat: Infinity, duration: 6, ease: 'linear' }}
        className="absolute top-0 left-0 w-48 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#22d3ee] opacity-70"
      />

      {/* Center cyber grid lines (subtle) */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:32px_32px] opacity-15" />

      {/* Vertical beam right */}
      {intensity === 'cinematic' && (
        <motion.div
          animate={{ y: ['-100%', '200%'] }}
          transition={{ repeat: Infinity, duration: 8, ease: 'linear', delay: 2 }}
          className="absolute top-0 right-1/4 w-[1px] h-64 bg-gradient-to-b from-transparent via-emerald-400 to-transparent shadow-[0_0_10px_#34d399] opacity-40"
        />
      )}
    </div>
  );
};
