import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, CheckCircle2, Zap, Cpu, Brain, Wrench, X } from 'lucide-react';
import { ProcessConstellationState } from '../../types/mily';

interface ProcessConstellationModalProps {
  state: ProcessConstellationState;
  onClose: () => void;
}

export const ProcessConstellationModal: React.FC<ProcessConstellationModalProps> = ({
  state,
  onClose,
}) => {
  const [displayedPercent, setDisplayedPercent] = useState(state.percentage);

  // Smooth number interpolation
  useEffect(() => {
    const timer = setInterval(() => {
      setDisplayedPercent((prev) => {
        if (prev < state.percentage) {
          return Math.min(state.percentage, prev + 1);
        }
        return state.percentage;
      });
    }, 20);
    return () => clearInterval(timer);
  }, [state.percentage]);

  if (!state.isOpen) return null;

  const isCompleted = state.percentage >= 100;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl select-none">
        <motion.div
          initial={{ opacity: 0, scale: 0.85, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: 20 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-lg bg-slate-950/90 border border-cyan-500/40 rounded-3xl p-6 md:p-8 shadow-2xl shadow-cyan-950/50 flex flex-col items-center text-center overflow-hidden"
        >
          {/* Cybernetic glowing corner markers */}
          <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-cyan-400 rounded-tl pointer-events-none" />
          <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-cyan-400 rounded-tr pointer-events-none" />
          <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-cyan-400 rounded-bl pointer-events-none" />
          <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-cyan-400 rounded-br pointer-events-none" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="space-y-1 mb-6">
            <span className="text-[11px] font-mono tracking-widest text-cyan-400 uppercase font-bold flex items-center justify-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              EJECUCIÓN DE PROCESO EN TIEMPO REAL
            </span>
            <h2 className="text-lg md:text-xl font-bold text-white font-mono">
              {state.processName}
            </h2>
          </div>

          {/* CONSTELLATION GRAPH DIAGRAM */}
          <div className="relative w-72 h-64 md:w-80 md:h-72 my-2 flex items-center justify-center">
            {/* SVG Connecting Energy Lines */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none"
              viewBox="0 0 320 288"
            >
              <defs>
                <linearGradient id="lineGlow" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.8" />
                  <stop offset="50%" stopColor="#34d399" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#818cf8" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Core (160, 40) to Memory (60, 140) */}
              <line
                x1="160"
                y1="45"
                x2="60"
                y2="140"
                stroke="url(#lineGlow)"
                strokeWidth={state.percentage > 15 ? '2.5' : '1'}
                strokeDasharray={state.percentage > 15 ? '4 2' : 'none'}
                className={state.percentage > 15 ? 'animate-[dash_1s_linear_infinite]' : 'opacity-40'}
              />

              {/* Core (160, 40) to AI Router (160, 140) */}
              <line
                x1="160"
                y1="45"
                x2="160"
                y2="140"
                stroke="url(#lineGlow)"
                strokeWidth={state.percentage > 35 ? '2.5' : '1'}
                strokeDasharray={state.percentage > 35 ? '4 2' : 'none'}
                className={state.percentage > 35 ? 'animate-[dash_1s_linear_infinite]' : 'opacity-40'}
              />

              {/* Core (160, 40) to Tool Gateway (260, 140) */}
              <line
                x1="160"
                y1="45"
                x2="260"
                y2="140"
                stroke="url(#lineGlow)"
                strokeWidth={state.percentage > 55 ? '2.5' : '1'}
                strokeDasharray={state.percentage > 55 ? '4 2' : 'none'}
                className={state.percentage > 55 ? 'animate-[dash_1s_linear_infinite]' : 'opacity-40'}
              />

              {/* Memory (60, 140) to Process (160, 240) */}
              <line
                x1="60"
                y1="140"
                x2="160"
                y2="240"
                stroke="url(#lineGlow)"
                strokeWidth={state.percentage > 65 ? '2.5' : '1'}
                strokeDasharray={state.percentage > 65 ? '4 2' : 'none'}
                className={state.percentage > 65 ? 'animate-[dash_1s_linear_infinite]' : 'opacity-40'}
              />

              {/* AI Router (160, 140) to Process (160, 240) */}
              <line
                x1="160"
                y1="140"
                x2="160"
                y2="240"
                stroke="url(#lineGlow)"
                strokeWidth={state.percentage > 75 ? '2.5' : '1'}
                strokeDasharray={state.percentage > 75 ? '4 2' : 'none'}
                className={state.percentage > 75 ? 'animate-[dash_1s_linear_infinite]' : 'opacity-40'}
              />

              {/* Tool Gateway (260, 140) to Process (160, 240) */}
              <line
                x1="260"
                y1="140"
                x2="160"
                y2="240"
                stroke="url(#lineGlow)"
                strokeWidth={state.percentage > 85 ? '2.5' : '1'}
                strokeDasharray={state.percentage > 85 ? '4 2' : 'none'}
                className={state.percentage > 85 ? 'animate-[dash_1s_linear_infinite]' : 'opacity-40'}
              />
            </svg>

            {/* NODE 1: TOP - MILY CORE */}
            <motion.div
              animate={{
                scale: [1, 1.08, 1],
                boxShadow: [
                  '0 0 10px rgba(34, 211, 238, 0.4)',
                  '0 0 25px rgba(34, 211, 238, 0.8)',
                  '0 0 10px rgba(34, 211, 238, 0.4)',
                ],
              }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute top-2 left-1/2 -translate-x-1/2 w-14 h-14 rounded-full bg-gradient-to-tr from-cyan-600 via-teal-500 to-emerald-400 p-[2px] z-10 flex items-center justify-center cursor-default"
            >
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center">
                <Sparkles className="w-4 h-4 text-cyan-300" />
                <span className="text-[7px] font-mono tracking-widest text-cyan-400 font-bold uppercase">
                  CORE
                </span>
              </div>
            </motion.div>

            {/* NODE 2: LEFT - MEMORY */}
            <div
              className={`absolute top-28 left-4 w-12 h-12 rounded-full p-[2px] transition-all duration-500 z-10 ${
                state.percentage >= 25
                  ? 'bg-gradient-to-tr from-emerald-500 to-cyan-400 shadow-lg shadow-emerald-500/30 scale-105'
                  : 'bg-slate-800 opacity-50'
              }`}
            >
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center">
                <Brain className={`w-3.5 h-3.5 ${state.percentage >= 25 ? 'text-emerald-400' : 'text-slate-500'}`} />
                <span className="text-[6.5px] font-mono tracking-tighter text-slate-400 uppercase">
                  MEMORY
                </span>
              </div>
            </div>

            {/* NODE 3: CENTER - NEURAL */}
            <div
              className={`absolute top-28 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full p-[2px] transition-all duration-500 z-10 ${
                state.percentage >= 50
                  ? 'bg-gradient-to-tr from-purple-500 to-indigo-400 shadow-lg shadow-purple-500/30 scale-105'
                  : 'bg-slate-800 opacity-50'
              }`}
            >
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center">
                <Cpu className={`w-3.5 h-3.5 ${state.percentage >= 50 ? 'text-purple-400' : 'text-slate-500'}`} />
                <span className="text-[6.5px] font-mono tracking-tighter text-slate-400 uppercase">
                  NEURAL
                </span>
              </div>
            </div>

            {/* NODE 4: RIGHT - TOOLS */}
            <div
              className={`absolute top-28 right-4 w-12 h-12 rounded-full p-[2px] transition-all duration-500 z-10 ${
                state.percentage >= 70
                  ? 'bg-gradient-to-tr from-amber-500 to-yellow-400 shadow-lg shadow-amber-500/30 scale-105'
                  : 'bg-slate-800 opacity-50'
              }`}
            >
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center">
                <Wrench className={`w-3.5 h-3.5 ${state.percentage >= 70 ? 'text-amber-400' : 'text-slate-500'}`} />
                <span className="text-[6.5px] font-mono tracking-tighter text-slate-400 uppercase">
                  TOOLS
                </span>
              </div>
            </div>

            {/* NODE 5: BOTTOM - TARGET PROCESS */}
            <div
              className={`absolute bottom-2 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full p-[2px] transition-all duration-500 z-10 ${
                isCompleted
                  ? 'bg-gradient-to-tr from-emerald-400 to-cyan-400 shadow-xl shadow-emerald-500/50 scale-110'
                  : 'bg-gradient-to-tr from-cyan-600 to-blue-500'
              }`}
            >
              <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center">
                {isCompleted ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 animate-bounce" />
                ) : (
                  <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
                )}
                <span className="text-[8px] font-mono font-bold text-white uppercase mt-0.5">
                  PROCESS
                </span>
              </div>
            </div>
          </div>

          {/* Real-time Percentage Indicator */}
          <div className="mt-4 space-y-2 w-full max-w-xs">
            <div className="flex items-center justify-between font-mono text-xs">
              <span className="text-slate-400">Progreso del Flujo:</span>
              <span className="text-lg font-black text-cyan-300 font-mono">
                {displayedPercent}%
              </span>
            </div>

            {/* Futuristic Progress Bar */}
            <div className="w-full h-2 rounded-full bg-slate-900 border border-slate-800 overflow-hidden relative">
              <motion.div
                className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 rounded-full"
                style={{ width: `${displayedPercent}%` }}
                transition={{ ease: 'linear' }}
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-[shimmer_1.5s_infinite]" />
            </div>

            <p className="text-xs font-mono text-slate-400 pt-1 italic">
              {state.phase}
            </p>
          </div>

          {/* Action button on complete */}
          {isCompleted && (
            <motion.button
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={onClose}
              type="button"
              className="mt-6 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-mono font-bold text-xs uppercase shadow-lg shadow-emerald-500/30 cursor-pointer transition-all hover:scale-105"
            >
              Completado · Continuar
            </motion.button>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
