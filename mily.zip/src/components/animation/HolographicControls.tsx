import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Gauge, Zap } from 'lucide-react';
import { AnimationIntensity } from '../../types/mily';

// 1. HOLOGRAPHIC TOGGLE SWITCH
interface HolographicToggleProps {
  checked: boolean;
  onChange: (val: boolean) => void;
  label?: string;
  sublabel?: string;
}

export const HolographicToggle: React.FC<HolographicToggleProps> = ({
  checked,
  onChange,
  label,
  sublabel,
}) => {
  return (
    <div
      onClick={() => onChange(!checked)}
      className="flex items-center justify-between p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-cyan-500/40 transition-all cursor-pointer group select-none"
    >
      <div>
        {label && (
          <div className="text-xs font-semibold text-slate-200 group-hover:text-white transition-colors">
            {label}
          </div>
        )}
        {sublabel && <div className="text-[11px] text-slate-400">{sublabel}</div>}
      </div>

      <div
        className={`w-13 h-7 rounded-full p-1 transition-all duration-300 relative border ${
          checked
            ? 'bg-gradient-to-r from-emerald-600 to-teal-500 border-emerald-400/50 shadow-[0_0_15px_rgba(52,211,153,0.35)]'
            : 'bg-slate-900 border-slate-700/60'
        }`}
      >
        <motion.div
          animate={{ x: checked ? 24 : 0 }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
          className={`w-5 h-5 rounded-full flex items-center justify-center ${
            checked
              ? 'bg-white shadow-[0_0_10px_#ffffff]'
              : 'bg-slate-400 group-hover:bg-slate-300'
          }`}
        >
          {checked && <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />}
        </motion.div>
      </div>
    </div>
  );
};

// 2. HOLOGRAPHIC CIRCULAR GAUGE / DIAL
interface HolographicDialProps {
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  label: string;
  onChange: (val: number) => void;
}

export const HolographicDial: React.FC<HolographicDialProps> = ({
  value,
  min,
  max,
  step,
  unit = 'x',
  label,
  onChange,
}) => {
  const percent = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
  const strokeDash = 226; // 2 * PI * r (r=36)
  const strokeOffset = strokeDash - (strokeDash * percent) / 100;

  return (
    <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-cyan-500/40 transition-all flex items-center justify-between gap-4">
      <div className="flex-1">
        <span className="text-xs font-semibold text-slate-200 block">{label}</span>
        <span className="text-[10px] text-slate-400 font-mono">
          Rango: {min}{unit} — {max}{unit}
        </span>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="w-full accent-cyan-400 mt-2 cursor-pointer"
        />
      </div>

      {/* Futuristic Circular HUD readout */}
      <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 84 84">
          {/* Background circle track */}
          <circle
            cx="42"
            cy="42"
            r="36"
            className="stroke-slate-800"
            strokeWidth="5"
            fill="transparent"
          />
          {/* Animated active glowing arc */}
          <motion.circle
            cx="42"
            cy="42"
            r="36"
            stroke="url(#dialGlow)"
            strokeWidth="5"
            strokeDasharray={strokeDash}
            animate={{ strokeDashoffset: strokeOffset }}
            transition={{ type: 'spring', damping: 20 }}
            strokeLinecap="round"
            fill="transparent"
          />
          <defs>
            <linearGradient id="dialGlow" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
          </defs>
        </svg>

        <div className="absolute inset-0 flex flex-col items-center justify-center font-mono">
          <span className="text-xs font-bold text-white">
            {value.toFixed(2)}
          </span>
          <span className="text-[8px] text-cyan-400 uppercase">{unit}</span>
        </div>
      </div>
    </div>
  );
};

// 3. HOLOGRAPHIC INTENSITY SEGMENTED SELECTOR
interface IntensitySelectorProps {
  currentIntensity: AnimationIntensity;
  onChange: (val: AnimationIntensity) => void;
}

export const HolographicIntensitySelector: React.FC<IntensitySelectorProps> = ({
  currentIntensity,
  onChange,
}) => {
  const options: { id: AnimationIntensity; label: string; desc: string }[] = [
    {
      id: 'cinematic',
      label: 'Cinemática (Ultra)',
      desc: 'Partículas cuánticas, órbitas 3D y líneas de energía',
    },
    {
      id: 'balanced',
      label: 'Equilibrada',
      desc: 'Animaciones suaves y óptima para cualquier dispositivo',
    },
    {
      id: 'performance',
      label: 'Rendimiento',
      desc: 'Transiciones mínimas y máxima velocidad de render',
    },
  ];

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-cyan-400" />
        <span className="text-xs font-bold text-slate-200">
          Mily Animation Engine · Intensidad Visual
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {options.map((opt) => {
          const isSelected = currentIntensity === opt.id;
          return (
            <button
              key={opt.id}
              onClick={() => onChange(opt.id)}
              type="button"
              className={`relative p-3 rounded-2xl border text-left transition-all cursor-pointer overflow-hidden ${
                isSelected
                  ? 'bg-slate-900 border-cyan-400 text-white shadow-[0_0_15px_rgba(34,211,238,0.2)]'
                  : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              {isSelected && (
                <motion.div
                  layoutId="intensityHighlight"
                  className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 via-teal-500/5 to-transparent pointer-events-none"
                />
              )}
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold font-mono">{opt.label}</span>
                {isSelected && (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" />
                )}
              </div>
              <p className="text-[10px] text-slate-400 line-clamp-2">{opt.desc}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
