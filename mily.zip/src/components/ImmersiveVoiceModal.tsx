import React, { useEffect, useState } from 'react';
import { X, Mic, MicOff, MessageSquare, Volume2, Sparkles, Radio, Activity } from 'lucide-react';
import { OrbState } from './AIVoiceOrb';
import { Persona } from '../types/mily';

interface ImmersiveVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  orbState: OrbState;
  onToggleListen: () => void;
  onStopSpeaking: () => void;
  transcript: string;
  lastAssistantReply: string;
  activePersona: Persona;
  onSelectPrompt?: (prompt: string) => void;
}

export const ImmersiveVoiceModal: React.FC<ImmersiveVoiceModalProps> = ({
  isOpen,
  onClose,
  orbState,
  onToggleListen,
  onStopSpeaking,
  transcript,
  lastAssistantReply,
  activePersona,
  onSelectPrompt,
}) => {
  const [waveAmplitudes, setWaveAmplitudes] = useState<number[]>([15, 25, 40, 65, 80, 50, 30, 20]);

  // Audio wave reactivity simulation
  useEffect(() => {
    if (orbState === 'listening' || orbState === 'speaking') {
      const interval = setInterval(() => {
        setWaveAmplitudes(
          Array.from({ length: 16 }, () => Math.floor(Math.random() * 60) + 15)
        );
      }, 100);
      return () => clearInterval(interval);
    } else {
      setWaveAmplitudes(Array.from({ length: 16 }, () => 10));
    }
  }, [orbState]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-2xl flex flex-col justify-between p-4 sm:p-8 select-none animate-in fade-in overflow-y-auto">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between w-full max-w-2xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm font-bold text-white tracking-widest">
                MILY
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                VOICE CONSOLE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              {activePersona.name} · {activePersona.title}
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          type="button"
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-mono cursor-pointer transition-colors"
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Volver al Dashboard</span>
        </button>
      </div>

      {/* Futuristic Frame Container */}
      <div className="my-auto w-full max-w-lg mx-auto py-6">
        <div className="relative rounded-3xl bg-slate-900/80 border border-slate-800/90 p-6 md:p-8 shadow-2xl shadow-cyan-950/30 flex flex-col items-center text-center space-y-6">
          {/* Subtle cyber corner accents */}
          <div className="absolute top-3 left-3 w-3 h-3 border-t-2 border-l-2 border-cyan-500/50 rounded-tl-sm pointer-events-none" />
          <div className="absolute top-3 right-3 w-3 h-3 border-t-2 border-r-2 border-cyan-500/50 rounded-tr-sm pointer-events-none" />
          <div className="absolute bottom-3 left-3 w-3 h-3 border-b-2 border-l-2 border-cyan-500/50 rounded-bl-sm pointer-events-none" />
          <div className="absolute bottom-3 right-3 w-3 h-3 border-b-2 border-r-2 border-cyan-500/50 rounded-br-sm pointer-events-none" />

          {/* Console Header */}
          <div className="space-y-1">
            <h1 className="text-xl md:text-2xl font-black font-mono tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-teal-200 to-emerald-300">
              MILY
            </h1>
            <div className="flex items-center justify-center gap-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  orbState === 'listening'
                    ? 'bg-emerald-400 shadow-[0_0_10px_#34d399] animate-pulse'
                    : orbState === 'thinking'
                    ? 'bg-purple-400 shadow-[0_0_10px_#c084fc] animate-ping'
                    : orbState === 'speaking'
                    ? 'bg-cyan-400 shadow-[0_0_10px_#22d3ee]'
                    : 'bg-slate-500'
                }`}
              />
              <span className="font-mono text-xs text-slate-300 tracking-wider">
                {orbState === 'listening' && '● Escuchando...'}
                {orbState === 'thinking' && '● Procesando respuesta...'}
                {orbState === 'speaking' && '● Mily respondiendo...'}
                {orbState === 'idle' && '● En espera de voz'}
              </span>
            </div>
          </div>

          {/* Conversational prompt */}
          <div className="py-2">
            <h2 className="text-xl md:text-2xl font-semibold text-slate-100 italic tracking-tight">
              "¿Qué quieres hacer?"
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              Habla con naturalidad para pedir tareas, analizar código o consultar información.
            </p>
          </div>

          {/* Real-time Dynamic Waveform Bars */}
          <div className="w-full flex items-center justify-center gap-1.5 h-16 px-4 py-2 bg-slate-950/70 rounded-2xl border border-slate-800/80">
            {waveAmplitudes.map((amp, idx) => (
              <div
                key={idx}
                className={`w-1.5 rounded-full transition-all duration-100 ${
                  orbState === 'listening'
                    ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                    : orbState === 'speaking'
                    ? 'bg-cyan-400 shadow-[0_0_8px_#22d3ee]'
                    : 'bg-slate-700'
                }`}
                style={{
                  height: `${Math.max(6, amp)}px`,
                }}
              />
            ))}
          </div>

          {/* Large Tactile Microphone Button */}
          <div className="pt-2">
            <button
              onClick={onToggleListen}
              type="button"
              className={`group relative flex items-center justify-center w-24 h-24 rounded-full transition-all duration-300 cursor-pointer shadow-2xl ${
                orbState === 'listening'
                  ? 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/40 scale-105 ring-4 ring-rose-500/30'
                  : 'bg-gradient-to-tr from-cyan-600 to-emerald-500 hover:scale-105 text-white shadow-cyan-500/30'
              }`}
            >
              <div className="flex flex-col items-center">
                {orbState === 'listening' ? (
                  <MicOff className="w-8 h-8 animate-pulse" />
                ) : (
                  <Mic className="w-8 h-8 group-hover:scale-110 transition-transform" />
                )}
                <span className="text-[9px] font-mono tracking-widest mt-1 uppercase font-bold">
                  {orbState === 'listening' ? 'DETENER' : 'MICRÓFONO'}
                </span>
              </div>
            </button>
          </div>

          {/* Live Transcript / Speech Preview */}
          {transcript && (
            <div className="w-full p-3.5 rounded-2xl bg-slate-950/90 border border-emerald-500/30 text-xs md:text-sm text-slate-200 text-left font-mono">
              <span className="text-[10px] text-emerald-400 uppercase tracking-wider block mb-1">
                TRANSCRIPCIÓN EN VIVO:
              </span>
              "{transcript}"
            </div>
          )}

          {/* Assistant speech playback feedback */}
          {orbState === 'speaking' && lastAssistantReply && (
            <div className="w-full p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 text-xs text-slate-200 text-left flex items-start gap-3">
              <Volume2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-mono text-cyan-400 uppercase block mb-1">
                  MILY HABLANDO:
                </span>
                <p className="line-clamp-3 italic">"{lastAssistantReply}"</p>
              </div>
              <button
                onClick={onStopSpeaking}
                className="text-[10px] font-mono px-2 py-1 rounded bg-slate-800 text-slate-300 hover:text-white shrink-0 cursor-pointer"
              >
                Silenciar
              </button>
            </div>
          )}

          {/* Quick Voice Suggestions */}
          {onSelectPrompt && (
            <div className="w-full pt-2">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block mb-2">
                Prueba diciendo o pulsando:
              </span>
              <div className="flex flex-wrap justify-center gap-1.5">
                {[
                  '¿Cuál es el estado de los proyectos?',
                  'Explícame la arquitectura modular',
                  'Sincroniza la memoria y el sistema',
                ].map((sug, i) => (
                  <button
                    key={i}
                    onClick={() => onSelectPrompt(sug)}
                    type="button"
                    className="px-2.5 py-1 rounded-lg text-[11px] bg-slate-950/80 hover:bg-cyan-500/10 hover:text-cyan-300 text-slate-400 border border-slate-800 hover:border-cyan-500/30 transition-all cursor-pointer truncate max-w-full"
                  >
                    "{sug}"
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom hint */}
      <div className="text-center text-[11px] font-mono text-slate-500">
        Reconocimiento en tiempo real vía Web Speech API + Gemini TTS fallback
      </div>
    </div>
  );
};
