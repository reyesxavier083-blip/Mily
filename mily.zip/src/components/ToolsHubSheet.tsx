import React, { useState, useEffect } from 'react';
import {
  Wrench,
  Calculator,
  Code2,
  ListTodo,
  FileText,
  Activity,
  X,
  Play,
  Copy,
  Check,
  RefreshCw,
  Terminal,
  Sparkles,
} from 'lucide-react';

interface ToolsHubSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSendToMily: (prompt: string) => void;
  systemUptime: number;
  memoryCount: number;
  initialTab?: string;
}

export const ToolsHubSheet: React.FC<ToolsHubSheetProps> = ({
  isOpen,
  onClose,
  onSendToMily,
  systemUptime,
  memoryCount,
  initialTab,
}) => {
  const [activeTool, setActiveTool] = useState<
    'calculator' | 'codeAudit' | 'planner' | 'summarizer' | 'apiPrompts' | 'diagnostics'
  >((initialTab as any) || 'apiPrompts');

  useEffect(() => {
    if (initialTab) {
      if (initialTab === 'code') {
        setActiveTool('codeAudit');
      } else {
        setActiveTool(initialTab as any);
      }
    }
  }, [initialTab]);

  // Calculator State
  const [calcInput, setCalcInput] = useState('25 * 4 + Math.sqrt(144) - (15 / 3)');
  const [calcResult, setCalcResult] = useState<string | null>(null);

  // Code Audit State
  const [codeSnippet, setCodeSnippet] = useState(
    `function fetchUserData(userId) {\n  var data = db.query("SELECT * FROM users WHERE id = " + userId);\n  return data;\n}`
  );

  // Planner State
  const [planGoal, setPlanGoal] = useState('Lanzar una aplicación web SaaS con autenticación y pagos');

  // Summarizer State
  const [textToSummarize, setTextToSummarize] = useState(
    'La inteligencia artificial generativa ha transformado la arquitectura del software moderno, pasando de modelos monolíticos a agentes colaborativos con memorias episódicas y semánticas. La velocidad de inferencia y la multimodalidad en tiempo real permiten ahora experiencias conversacionales orgánicas sin latencia perceptible.'
  );

  // API Prompt State
  const [apiModel, setApiModel] = useState('gpt-6-astra');
  const [apiDeveloperRole, setApiDeveloperRole] = useState(
    'You are a helpful support assistant. Be concise, accurate, and friendly.'
  );
  const [apiUserInput, setApiUserInput] = useState(
    'Customer name: Acme. Issue: billing question. Write a response to the customer.'
  );

  // Copy helper
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCalculate = () => {
    try {
      // Safe sanitized math evaluation using Math.* context
      const sanitized = calcInput.replace(/[^0-9+\-*/().,% Math.sqrtMath.powMath.sinMath.cosMath.tanMath.PIMath.E]/g, '');
      const fn = new Function(`with (Math) { return (${sanitized}); }`);
      const res = fn();
      setCalcResult(String(res));
    } catch (err: any) {
      setCalcResult(`Error de sintaxis: ${err.message}`);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Caja de Herramientas de Mily
              </h2>
              <p className="text-xs text-slate-400">
                Módulos de cálculo, auditoría de código, planificación y diagnóstico
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tool Navigation Tabs */}
        <div className="px-5 py-2.5 bg-slate-950/70 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTool('calculator')}
            type="button"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTool === 'calculator'
                ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Calculadora Matemática</span>
          </button>

          <button
            onClick={() => setActiveTool('codeAudit')}
            type="button"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTool === 'codeAudit'
                ? 'bg-slate-800 text-cyan-400 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Auditor de Código</span>
          </button>

          <button
            onClick={() => setActiveTool('planner')}
            type="button"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTool === 'planner'
                ? 'bg-slate-800 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ListTodo className="w-3.5 h-3.5" />
            <span>Planificador de Metas</span>
          </button>

          <button
            onClick={() => setActiveTool('summarizer')}
            type="button"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTool === 'summarizer'
                ? 'bg-slate-800 text-purple-400 border border-purple-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Extractor & Resumen</span>
          </button>

          <button
            onClick={() => setActiveTool('apiPrompts')}
            type="button"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTool === 'apiPrompts'
                ? 'bg-slate-800 text-cyan-400 border border-cyan-500/30 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Simulador API & Prompts</span>
          </button>

          <button
            onClick={() => setActiveTool('diagnostics')}
            type="button"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
              activeTool === 'diagnostics'
                ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Diagnóstico Mily</span>
          </button>
        </div>

        {/* Tool Content Area */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* CALCULATOR */}
          {activeTool === 'calculator' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-emerald-400" />
                  Calculadora Matemática Rápida
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Evalúa expresiones numéricas, funciones trigonométricas y fórmulas algebraicas.
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300">Expresión matemática</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={calcInput}
                    onChange={(e) => setCalcInput(e.target.value)}
                    className="flex-1 px-3.5 py-2 text-sm bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-emerald-500"
                    placeholder="ej: 12 * 8 + sqrt(144)"
                  />
                  <button
                    onClick={handleCalculate}
                    type="button"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Calcular
                  </button>
                </div>
              </div>

              {calcResult !== null && (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <span className="text-xs text-slate-500 font-medium">Resultado:</span>
                  <div className="text-xl font-mono font-bold text-emerald-400 break-all">
                    {calcResult}
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => {
                    onSendToMily(`Mily, por favor ayúdame a resolver y explicar el procedimiento detallado para este cálculo matemático: ${calcInput}`);
                    onClose();
                  }}
                  type="button"
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 cursor-pointer"
                >
                  Pedir a Mily que explique el procedimiento paso a paso &rarr;
                </button>
              </div>
            </div>
          )}

          {/* CODE AUDIT */}
          {activeTool === 'codeAudit' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-cyan-400" />
                  Auditoría de Código y Refactorización
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Pega un fragmento de código para que Mily audite seguridad, rendimiento y legibilidad.
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300">Código fuente a auditar</label>
                <textarea
                  value={codeSnippet}
                  onChange={(e) => setCodeSnippet(e.target.value)}
                  rows={6}
                  className="w-full p-3 text-xs md:text-sm bg-slate-950 border border-slate-700 rounded-xl text-emerald-300 font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => {
                    onSendToMily(`Mily, actúa como auditora de software senior. Audita este código, detecta vulnerabilidades, cuellos de botella y genera una versión refactorizada, tipada y optimizada con comentarios:\n\`\`\`\n${codeSnippet}\n\`\`\``);
                    onClose();
                  }}
                  type="button"
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Auditar con Mily
                </button>
              </div>
            </div>
          )}

          {/* PLANNER */}
          {activeTool === 'planner' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ListTodo className="w-4 h-4 text-amber-400" />
                  Planificador Estratégico de Proyectos
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Convierte cualquier visión o meta en un plan de acción estructurado con hitos y métricas.
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300">¿Cuál es tu objetivo?</label>
                <textarea
                  value={planGoal}
                  onChange={(e) => setPlanGoal(e.target.value)}
                  rows={3}
                  className="w-full p-3 text-xs md:text-sm bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-500"
                  placeholder="Describe la meta..."
                />
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => {
                    onSendToMily(`Mily, por favor diseña un plan de acción exhaustivo y priorizado de 5 fases para alcanzar esta meta: "${planGoal}". Incluye entregables clave, métricas de éxito (KPIs) y riesgos a prevenir.`);
                    onClose();
                  }}
                  type="button"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Generar Plan con Mily
                </button>
              </div>
            </div>
          )}

          {/* SUMMARIZER */}
          {activeTool === 'summarizer' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-400" />
                  Resumidor & Extractor Conceptual
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Extrae conclusiones, ideas clave y puntos de acción a partir de textos largos.
                </p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-300">Texto o artículo</label>
                <textarea
                  value={textToSummarize}
                  onChange={(e) => setTextToSummarize(e.target.value)}
                  rows={5}
                  className="w-full p-3 text-xs md:text-sm bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex justify-end">
                <button
                  onClick={() => {
                    onSendToMily(`Mily, realiza un resumen ejecutivo de alto nivel del siguiente texto. Extrae: 1) Los 3 puntos esenciales, 2) Consecuencias prácticas, 3) Una tabla resumen o lista concisa:\n\n"${textToSummarize}"`);
                    onClose();
                  }}
                  type="button"
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Sintetizar con Mily
                </button>
              </div>
            </div>
          )}

          {/* API PROMPTS & CODE SIMULATOR */}
          {activeTool === 'apiPrompts' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-cyan-400" />
                  Simulador de APIs: OpenAI Responses & Gemini
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Diseña, prueba e inspecciona llamadas a modelos de razonamiento (Responses API con <code>gpt-6-astra</code> o Gemini).
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Modelo</label>
                  <select
                    value={apiModel}
                    onChange={(e) => setApiModel(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                  >
                    <option value="gpt-6-astra">gpt-6-astra (OpenAI Responses API)</option>
                    <option value="gemini-3.8-flash">gemini-3.8-flash (Google GenAI)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-medium text-slate-300">Rol de Sistema / Developer</label>
                  <input
                    type="text"
                    value={apiDeveloperRole}
                    onChange={(e) => setApiDeveloperRole(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-slate-200 focus:outline-none focus:border-cyan-500"
                    placeholder="Instrucciones al modelo..."
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-300">Input del Usuario</label>
                <textarea
                  value={apiUserInput}
                  onChange={(e) => setApiUserInput(e.target.value)}
                  rows={2}
                  className="w-full p-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Code representation snippet */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>Código de llamada generado (SDK moderno):</span>
                  <button
                    onClick={() =>
                      handleCopy(`import OpenAI from "openai";\nconst client = new OpenAI();\n\nconst response = await client.responses.create({\n  model: "${apiModel}",\n  instructions: "${apiDeveloperRole}",\n  input: "${apiUserInput}",\n});\n\nconsole.log(response.output_text);`)
                    }
                    type="button"
                    className="flex items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copiar código</span>
                  </button>
                </div>
                <pre className="text-xs font-mono text-emerald-300 overflow-x-auto p-2 bg-slate-900/60 rounded-lg">
{`import OpenAI from "openai";
const client = new OpenAI();

const response = await client.responses.create({
  model: "${apiModel}",
  instructions: "${apiDeveloperRole}",
  input: "${apiUserInput}",
});

console.log(response.output_text);`}
                </pre>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  onClick={() => {
                    onSendToMily(`Mily, ejecuta y simula la respuesta exacta que generaría este código de la API de OpenAI Responses:\n\nInstrucciones: "${apiDeveloperRole}"\nInput: "${apiUserInput}"\n\nGenera la respuesta al cliente Acme tal como lo haría el modelo, y luego explica brevemente las mejores prácticas de formato en Responses API.`);
                    onClose();
                  }}
                  type="button"
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Simular respuesta con Mily
                </button>
              </div>
            </div>
          )}

          {/* DIAGNOSTICS */}
          {activeTool === 'diagnostics' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  Telemetría y Estado de Mily v18
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Diagnóstico en tiempo real de los subsistemas y memoria cognitiva
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-500">Motor de Razonamiento Principal</span>
                  <div className="text-sm font-semibold text-emerald-400">Gemini 3.8 Flash</div>
                  <p className="text-[11px] text-slate-400">Optimizado para inferencia en tiempo real y streaming</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-500">Unidades de Memoria Activa</span>
                  <div className="text-sm font-semibold text-cyan-400">{memoryCount} hechos indexados</div>
                  <p className="text-[11px] text-slate-400">Memoria episódica y semántica inyectadas en contexto</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-500">Tiempo de Actividad (Uptime)</span>
                  <div className="text-sm font-semibold text-purple-400">
                    {Math.floor(systemUptime / 60)}m {Math.floor(systemUptime % 60)}s
                  </div>
                  <p className="text-[11px] text-slate-400">Servidor Node Express + Vite en ejecución continua</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-xs text-slate-500">Voz y Audio en Vivo</span>
                  <div className="text-sm font-semibold text-amber-400">Web Speech API + Gemini TTS</div>
                  <p className="text-[11px] text-slate-400">Reconocimiento bidireccional y síntesis interactiva</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors text-xs font-semibold cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
