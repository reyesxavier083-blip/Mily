import React, { useState } from 'react';
import { X, Sparkles, AlertCircle, Check } from 'lucide-react';

interface CorrectionFeedbackDialogProps {
  isOpen: boolean;
  onClose: () => void;
  targetMessageContent?: string;
  onSaveCorrection: (correction: string) => void;
}

export const CorrectionFeedbackDialog: React.FC<CorrectionFeedbackDialogProps> = ({
  isOpen,
  onClose,
  targetMessageContent,
  onSaveCorrection,
}) => {
  const [correctionText, setCorrectionText] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!correctionText.trim()) return;
    onSaveCorrection(correctionText.trim());
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setCorrectionText('');
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Enseñar o Corregir a Mily
              </h2>
              <p className="text-xs text-slate-400">
                Mily almacenará esta corrección en su memoria semántica permanente
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {targetMessageContent && (
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
              <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px]">
                Referencia al mensaje:
              </span>
              <p className="line-clamp-2 italic text-slate-300">
                "{targetMessageContent}"
              </p>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <span>¿Qué debe recordar o hacer diferente Mily?</span>
            </label>
            <textarea
              value={correctionText}
              onChange={(e) => setCorrectionText(e.target.value)}
              placeholder="Ejemplo: 'Prefiero que siempre uses español formal', o 'Mi framework principal es React con Tailwind'..."
              rows={4}
              className="w-full p-3 text-xs md:text-sm bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              autoFocus
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!correctionText.trim() || submitted}
              className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              {submitted ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>¡Memoria actualizada!</span>
                </>
              ) : (
                <span>Guardar corrección</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
