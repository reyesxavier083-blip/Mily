import React, { useEffect, useState } from 'react';
import { Volume2, X, Play, Sliders, Check, Sparkles } from 'lucide-react';
import { VoiceSettings, AnimationIntensity } from '../types/mily';
import {
  HolographicToggle,
  HolographicDial,
  HolographicIntensitySelector,
} from './animation/HolographicControls';

interface VoiceSettingsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VoiceSettings;
  onUpdateSettings: (newSettings: Partial<VoiceSettings>) => void;
  onTestVoice: (sampleText: string) => void;
}

export const VoiceSettingsSheet: React.FC<VoiceSettingsSheetProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onTestVoice,
}) => {
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const updateVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setAvailableVoices(voices);
      };
      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  if (!isOpen) return null;

  // Deduplicate voices by voiceURI or name + lang
  const uniqueVoices = availableVoices.filter(
    (voice, index, self) =>
      index ===
      self.findIndex(
        (v) =>
          (v.voiceURI && voice.voiceURI && v.voiceURI === voice.voiceURI) ||
          (v.name === voice.name && v.lang === voice.lang)
      )
  );

  // Filter Spanish voices first
  const spanishVoices = uniqueVoices.filter(
    (v) => v.lang.startsWith('es') || v.name.toLowerCase().includes('spanish')
  );
  const otherVoices = uniqueVoices.filter(
    (v) => !v.lang.startsWith('es') && !v.name.toLowerCase().includes('spanish')
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-in fade-in select-none">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header with holographic accent */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 relative">
          <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Ajustes de Sistema y Voz
              </h2>
              <p className="text-xs text-slate-400">
                Personaliza la experiencia visual y los parámetros de habla
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
          {/* 1. MILY ANIMATION ENGINE INTENSITY */}
          <HolographicIntensitySelector
            currentIntensity={settings.animationIntensity || 'cinematic'}
            onChange={(val) => onUpdateSettings({ animationIntensity: val })}
          />

          {/* 2. HOLOGRAPHIC TOGGLE AUTO-SPEAK */}
          <HolographicToggle
            checked={settings.autoSpeak}
            onChange={(checked) => onUpdateSettings({ autoSpeak: checked })}
            label="Lectura automática de respuestas (Auto-Speak)"
            sublabel="Mily sintetizará su respuesta con voz fluida al completar cada mensaje"
          />

          {/* 3. VOICE SELECTOR */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 block">
              Voz de síntesis del sistema
            </label>
            <select
              value={settings.voiceURI}
              onChange={(e) => onUpdateSettings({ voiceURI: e.target.value })}
              className="w-full px-3 py-2.5 text-xs bg-slate-950 border border-slate-800 rounded-2xl text-slate-200 focus:outline-none focus:border-cyan-500/50"
            >
              <option value="">Voz predeterminada del sistema</option>
              {spanishVoices.length > 0 && (
                <optgroup label="Voces en Español">
                  {spanishVoices.map((v, idx) => (
                    <option key={`es-${v.voiceURI || v.name}-${idx}`} value={v.voiceURI || v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </optgroup>
              )}
              {otherVoices.length > 0 && (
                <optgroup label="Otras Voces">
                  {otherVoices.slice(0, 30).map((v, idx) => (
                    <option key={`other-${v.voiceURI || v.name}-${idx}`} value={v.voiceURI || v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </optgroup>
              )}
            </select>
          </div>

          {/* 4. HOLOGRAPHIC CIRCULAR DIALS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <HolographicDial
              value={settings.rate}
              min={0.7}
              max={1.5}
              step={0.05}
              unit="x"
              label="Velocidad (Rate)"
              onChange={(rate) => onUpdateSettings({ rate })}
            />

            <HolographicDial
              value={settings.pitch}
              min={0.8}
              max={1.3}
              step={0.05}
              unit="x"
              label="Tono de Voz (Pitch)"
              onChange={(pitch) => onUpdateSettings({ pitch })}
            />
          </div>

          {/* Test Voice Button */}
          <div className="flex justify-between items-center pt-2 border-t border-slate-800/80">
            <button
              onClick={() =>
                onTestVoice('Hola, soy Mily. Tu sistema operativo de inteligencia artificial está listo para operar.')
              }
              type="button"
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Probar voz de muestra
            </button>

            <button
              onClick={onClose}
              type="button"
              className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white rounded-xl text-xs font-bold font-mono transition-all cursor-pointer shadow-lg shadow-emerald-500/20"
            >
              Guardar configuración
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
