import React, { useState } from 'react';
import {
  Brain,
  Search,
  Plus,
  Trash2,
  Calendar,
  Tag,
  Check,
  X,
  Sparkles,
} from 'lucide-react';
import { MemoryItem, MemoryType } from '../types/mily';

interface MemoryHubSheetProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
  onAddMemory: (type: MemoryType, content: string, category: string) => void;
  onDeleteMemory: (id: string) => void;
}

export const MemoryHubSheet: React.FC<MemoryHubSheetProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
  onDeleteMemory,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | MemoryType>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newType, setNewType] = useState<MemoryType>('semantic');
  const [newCategory, setNewCategory] = useState('Personal');

  if (!isOpen) return null;

  const filteredMemories = memories.filter((m) => {
    const matchesTab = activeTab === 'all' || m.type === activeTab;
    const matchesSearch =
      m.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    onAddMemory(newType, newContent.trim(), newCategory.trim() || 'General');
    setNewContent('');
    setIsAdding(false);
  };

  const typeLabels: Record<MemoryType, { label: string; color: string }> = {
    semantic: { label: 'Semántica', color: 'text-cyan-400 bg-cyan-950/40 border-cyan-500/30' },
    episodic: { label: 'Episódica', color: 'text-purple-400 bg-purple-950/40 border-purple-500/30' },
    preference: { label: 'Preferencia', color: 'text-emerald-400 bg-emerald-950/40 border-emerald-500/30' },
    goal: { label: 'Meta', color: 'text-amber-400 bg-amber-950/40 border-amber-500/30' },
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Centro de Memoria Cognitiva
                <span className="text-xs font-normal text-emerald-400 font-mono">
                  v18.4
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Información y hechos que Mily recuerda para personalizar tus respuestas
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Bar & Stats */}
        <div className="px-5 py-3 bg-slate-950/60 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">
              {memories.length} recuerdos registrados en Mily
            </span>
          </div>
          <button
            onClick={() => setIsAdding(!isAdding)}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-sm shadow-emerald-900/50"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{isAdding ? 'Cancelar' : 'Agregar recuerdo'}</span>
          </button>
        </div>

        {/* Add Memory Form */}
        {isAdding && (
          <form
            onSubmit={handleCreate}
            className="p-4 bg-slate-950 border-b border-slate-800 space-y-3 animate-in slide-in-from-top-2"
          >
            <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Enseñar un nuevo dato o preferencia a Mily</span>
            </div>
            <textarea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder="Ejemplo: 'Me gusta programar en TypeScript y prefiero explicaciones directas con ejemplos prácticos'..."
              rows={2}
              className="w-full px-3 py-2 text-xs md:text-sm bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              autoFocus
            />
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={newType}
                onChange={(e) => setNewType(e.target.value as MemoryType)}
                className="px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-slate-200 focus:outline-none"
              >
                <option value="semantic">Semántica (Dato/Hecho)</option>
                <option value="preference">Preferencia de usuario</option>
                <option value="episodic">Episódica (Evento/Hito)</option>
                <option value="goal">Meta o Proyecto</option>
              </select>
              <input
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Categoría (ej: Trabajo, Gustos)"
                className="px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-slate-200 focus:outline-none"
              />
              <button
                type="submit"
                className="ml-auto px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors cursor-pointer"
              >
                Guardar en memoria
              </button>
            </div>
          </form>
        )}

        {/* Filter & Search Bar */}
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Segmented Filter Control */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 w-full sm:w-auto overflow-x-auto">
            {(['all', 'semantic', 'preference', 'goal', 'episodic'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                type="button"
                className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors capitalize whitespace-nowrap cursor-pointer ${
                  activeTab === tab
                    ? 'bg-slate-800 text-emerald-400 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab === 'all' ? 'Todos' : typeLabels[tab]?.label || tab}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-60">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar recuerdos..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-slate-700"
            />
          </div>
        </div>

        {/* Memories List */}
        <div className="p-4 overflow-y-auto space-y-2.5 flex-1 min-h-[220px]">
          {filteredMemories.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
              <Brain className="w-8 h-8 opacity-30 text-emerald-400" />
              <span>No se encontraron recuerdos con estos filtros.</span>
              <span className="text-[11px] text-slate-600">
                A medida que converses con Mily, ella aprenderá y guardará datos sobre ti de forma autónoma.
              </span>
            </div>
          ) : (
            filteredMemories.map((mem, memIdx) => {
              const meta = typeLabels[mem.type] || {
                label: mem.type,
                color: 'text-slate-400 bg-slate-800 border-slate-700',
              };

              return (
                <div
                  key={`mem-${mem.id}-${memIdx}`}
                  className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition-all flex items-start justify-between gap-3 group"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase tracking-wider ${meta.color}`}
                      >
                        {meta.label}
                      </span>
                      <span className="text-xs text-slate-500 flex items-center gap-1">
                        <Tag className="w-3 h-3 text-slate-600" />
                        {mem.category}
                      </span>
                      <span className="text-xs text-slate-500 flex items-center gap-1 ml-auto sm:ml-0">
                        <Calendar className="w-3 h-3 text-slate-600" />
                        {mem.timestamp}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-normal">
                      {mem.content}
                    </p>
                  </div>
                  <button
                    onClick={() => onDeleteMemory(mem.id)}
                    title="Eliminar este recuerdo de Mily"
                    className="p-1.5 text-slate-500 hover:text-rose-400 opacity-60 group-hover:opacity-100 transition-opacity rounded hover:bg-slate-800 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>El motor de memoria se inyecta dinámicamente en el contexto de Mily.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors font-medium cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
