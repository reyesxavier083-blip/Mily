import React, { useEffect, useState } from 'react';
import { Mic, MicOff, Volume2, Sparkles, Loader2, Square } from 'lucide-react';

export type OrbState = 'idle' | 'listening' | 'thinking' | 'speaking';

interface AIVoiceOrbProps {
  state: OrbState;
  onToggleListen: () => void;
  onStopSpeaking?: () => void;
  size?: 'sm' | 'md' | 'lg';
  showControls?: boolean;
}

export const AIVoiceOrb: React.FC<AIVoiceOrbProps> = ({
  state,
  onToggleListen,
  onStopSpeaking,
  size = 'md',
  showControls = true,
}) => {
  const [waveAmplitudes, setWaveAmplitudes] = useState<number[]>([
    25, 45, 70, 40, 20, 60, 30,
  ]);

  // Dynamic visualizer frequencies
  useEffect(() => {
    if (state === 'listening' || state === 'speaking') {
      const interval = setInterval(() => {
        setWaveAmplitudes(
          Array.from({ length: 7 }, () => Math.floor(Math.random() * 75) + 20)
        );
      }, 100);
      return () => clearInterval(interval);
    } else {
      setWaveAmplitudes([15, 25, 30, 25, 20, 25, 15]);
    }
  }, [state]);

  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-36 h-36',
    lg: 'w-52 h-52',
  };

  const ringSizes = {
    sm: 'w-32 h-32',
    md: 'w-48 h-48',
    lg: 'w-64 h-64',
  };

  return (
    <div className="flex flex-col items-center justify-center select-none relative">
      {/* Outer ambient glow & ripple rings */}
      <div className="relative flex items-center justify-center">
        {/* Pulsing Ripple 1 */}
        <div
          className={`absolute rounded-full transition-all duration-700 pointer-events-none ${
            ringSizes[size]
          } ${
            state === 'listening'
              ? 'scale-110 opacity-40 bg-emerald-500/20 blur-xl animate-ping'
              : state === 'speaking'
              ? 'scale-105 opacity-30 bg-cyan-500/20 blur-xl animate-pulse'
              : state === 'thinking'
              ? 'scale-100 opacity-25 bg-purple-500/20 blur-xl'
              : 'scale-90 opacity-15 bg-emerald-500/10 blur-lg'
          }`}
        />

        {/* Outer Orbit / Thinking Ring */}
        {state === 'thinking' && (
          <div
            className={`absolute rounded-full border border-dashed border-emerald-400/50 animate-spin ${ringSizes[size]}`}
            style={{ animationDuration: '6s' }}
          />
        )}

        {/* Central Organic Orb Button */}
        <button
          onClick={state === 'speaking' && onStopSpeaking ? onStopSpeaking : onToggleListen}
          type="button"
          aria-label={
            state === 'listening'
              ? 'Detener escucha'
              : state === 'speaking'
              ? 'Silenciar respuesta'
              : 'Iniciar conversación por voz con Mily'
          }
          className={`relative rounded-full cursor-pointer flex items-center justify-center transition-all duration-500 shadow-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 ${
            sizeClasses[size]
          } ${
            state === 'listening'
              ? 'bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-400 shadow-emerald-500/40 scale-105 ring-4 ring-emerald-500/30'
              : state === 'speaking'
              ? 'bg-gradient-to-tr from-cyan-600 via-blue-500 to-emerald-400 shadow-cyan-500/40 scale-102 ring-4 ring-cyan-500/30'
              : state === 'thinking'
              ? 'bg-gradient-to-tr from-purple-700 via-indigo-600 to-emerald-500 shadow-purple-500/30 animate-pulse'
              : 'bg-gradient-to-tr from-slate-900 via-emerald-950/60 to-slate-800 border border-emerald-500/30 shadow-emerald-900/30 hover:border-emerald-400/60 hover:scale-105'
          }`}
        >
          {/* Inner glass refraction layer */}
          <div className="absolute inset-1 rounded-full bg-radial from-white/20 via-transparent to-black/40 pointer-events-none" />

          {/* Core Icon Display */}
          <div className="relative z-10 flex flex-col items-center justify-center text-white">
            {state === 'listening' ? (
              <Mic className="w-8 h-8 md:w-10 md:h-10 text-white animate-pulse" />
            ) : state === 'speaking' ? (
              <Volume2 className="w-8 h-8 md:w-10 md:h-10 text-white animate-bounce" />
            ) : state === 'thinking' ? (
              <Loader2 className="w-8 h-8 md:w-10 md:h-10 text-emerald-200 animate-spin" />
            ) : (
              <Sparkles className="w-7 h-7 md:w-9 md:h-9 text-emerald-400 group-hover:text-emerald-300 transition-colors" />
            )}
          </div>
        </button>
      </div>

      {/* Dynamic Voice Equalizer Waveform */}
      {(state === 'listening' || state === 'speaking') && (
        <div className="flex items-center gap-1 mt-4 h-6 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-800">
          {waveAmplitudes.map((amp, idx) => (
            <div
              key={idx}
              className={`w-1 rounded-full transition-all duration-100 ${
                state === 'listening'
                  ? 'bg-emerald-400'
                  : 'bg-cyan-400'
              }`}
              style={{ height: `${amp}%` }}
            />
          ))}
        </div>
      )}

      {/* Status Label & Controls */}
      {showControls && (
        <div className="mt-3 flex items-center gap-2">
          <span
            className={`text-xs font-medium tracking-wide transition-colors ${
              state === 'listening'
                ? 'text-emerald-400 font-semibold'
                : state === 'speaking'
                ? 'text-cyan-400'
                : state === 'thinking'
                ? 'text-purple-300'
                : 'text-slate-400'
            }`}
          >
            {state === 'listening' && 'Mily está escuchando...'}
            {state === 'speaking' && 'Mily está hablando...'}
            {state === 'thinking' && 'Mily está procesando...'}
            {state === 'idle' && 'Pulsa para hablar con Mily'}
          </span>

          {state === 'speaking' && onStopSpeaking && (
            <button
              onClick={onStopSpeaking}
              title="Detener voz"
              className="p-1 text-slate-400 hover:text-rose-400 transition-colors rounded hover:bg-slate-800"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
