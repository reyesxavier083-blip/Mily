import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Mic, Cpu, Zap, CheckCircle2, Radio, Activity } from 'lucide-react';
import { MilyCoreState, AnimationIntensity } from '../types/mily';

interface MilyCoreNucleusProps {
  state: MilyCoreState;
  isSpeaking: boolean;
  onActivateVoice: () => void;
  subtext?: string;
  intensity?: AnimationIntensity;
}

export const MilyCoreNucleus: React.FC<MilyCoreNucleusProps> = ({
  state,
  isSpeaking,
  onActivateVoice,
  subtext = 'MILY CORE INTELLIGENCE',
  intensity = 'cinematic',
}) => {
  const [pulse, setPulse] = useState(0);

  // Audio simulation pulse for visual reactivity
  useEffect(() => {
    const interval = setInterval(() => {
      setPulse(Math.floor(Math.random() * 40) + 60);
    }, 120);
    return () => clearInterval(interval);
  }, []);

  // Visual parameters based on MILY state
  const stateConfig = {
    idle: {
      label: 'En espera',
      badgeColor: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
      dotColor: 'bg-cyan-400 shadow-[0_0_12px_#22d3ee]',
      glowColor: 'from-cyan-500/25 via-blue-600/15 to-transparent',
      ringColor: 'border-cyan-400/40',
      coreColor: 'from-cyan-400 via-blue-500 to-indigo-600',
      icon: Radio,
    },
    listening: {
      label: 'Escuchando...',
      badgeColor: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 animate-pulse',
      dotColor: 'bg-emerald-400 shadow-[0_0_16px_#34d399]',
      glowColor: 'from-emerald-500/35 via-teal-600/20 to-transparent',
      ringColor: 'border-emerald-400/60',
      coreColor: 'from-emerald-400 via-teal-500 to-cyan-500',
      icon: Mic,
    },
    processing: {
      label: 'Procesando...',
      badgeColor: 'bg-purple-500/20 border-purple-500/40 text-purple-300',
      dotColor: 'bg-purple-400 shadow-[0_0_16px_#c084fc]',
      glowColor: 'from-purple-500/35 via-indigo-600/20 to-transparent',
      ringColor: 'border-purple-400/60',
      coreColor: 'from-purple-400 via-indigo-500 to-pink-500',
      icon: Cpu,
    },
    executing: {
      label: 'Ejecutando...',
      badgeColor: 'bg-amber-500/20 border-amber-500/40 text-amber-300',
      dotColor: 'bg-amber-400 shadow-[0_0_16px_#fbbf24]',
      glowColor: 'from-amber-500/35 via-orange-600/20 to-transparent',
      ringColor: 'border-amber-400/60',
      coreColor: 'from-amber-400 via-orange-500 to-yellow-400',
      icon: Zap,
    },
    completed: {
      label: 'Completado',
      badgeColor: 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300',
      dotColor: 'bg-emerald-400 shadow-[0_0_12px_#34d399]',
      glowColor: 'from-emerald-500/25 via-cyan-500/15 to-transparent',
      ringColor: 'border-emerald-400/50',
      coreColor: 'from-emerald-300 via-teal-400 to-cyan-400',
      icon: CheckCircle2,
    },
  }[state];

  const CurrentIcon = stateConfig.icon;
  const isVoiceActive = state === 'listening' || isSpeaking;

  // Orbiting telemetry data badges
  const telemetryChips = [
    { label: 'CPU 14%', angle: 0 },
    { label: 'LAT 12ms', angle: 72 },
    { label: 'RAG VEC-STORE', angle: 144 },
    { label: 'NEURAL 99.8%', angle: 216 },
    { label: 'ROOM DB OK', angle: 288 },
  ];

  return (
    <div className="relative flex flex-col items-center justify-center py-6 select-none">
      {/* Outer ambient glow */}
      <div
        className={`absolute -inset-12 bg-radial ${stateConfig.glowColor} rounded-full blur-3xl opacity-70 pointer-events-none transition-all duration-700`}
      />

      {/* Central Interactive Orb with Concentric Orbits */}
      <div className="relative flex items-center justify-center w-64 h-64 md:w-72 md:h-72">
        {/* Gimbal Orbit Ring 1 (Dotted external ring) */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 28, ease: 'linear' }}
          className={`absolute inset-0 rounded-full border border-dashed ${stateConfig.ringColor} opacity-50 pointer-events-none`}
        />

        {/* Gimbal Orbit Ring 2 (Tilted axis ring) */}
        {intensity !== 'performance' && (
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ repeat: Infinity, duration: 16, ease: 'linear' }}
            className={`absolute inset-4 rounded-full border-t-2 border-b-2 border-l-0 border-r-0 ${stateConfig.ringColor} opacity-75 pointer-events-none`}
          />
        )}

        {/* Gimbal Orbit Ring 3 (Middle pulsing aura) */}
        <motion.div
          animate={{
            scale: isVoiceActive ? [1, 1.08, 1] : [1, 1.03, 1],
            opacity: [0.4, 0.7, 0.4],
          }}
          transition={{ repeat: Infinity, duration: isVoiceActive ? 0.8 : 3, ease: 'easeInOut' }}
          className={`absolute inset-8 rounded-full border ${stateConfig.ringColor} pointer-events-none`}
        />

        {/* Orbiting Telemetry Chips (Floating around the nucleus) */}
        {intensity === 'cinematic' && (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 32, ease: 'linear' }}
            className="absolute inset-0 pointer-events-none"
          >
            {telemetryChips.map((chip, idx) => {
              const rad = (chip.angle * Math.PI) / 180;
              const radius = 120; // distance from center
              const x = Math.cos(rad) * radius;
              const y = Math.sin(rad) * radius;

              return (
                <div
                  key={idx}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                  style={{
                    transform: `translate(${x}px, ${y}px)`,
                  }}
                >
                  <motion.span
                    animate={{ rotate: -360 }}
                    transition={{ repeat: Infinity, duration: 32, ease: 'linear' }}
                    className="inline-block px-1.5 py-0.5 rounded-md text-[8.5px] font-mono tracking-tighter bg-slate-950/90 text-cyan-300 border border-cyan-500/30 shadow-[0_0_8px_rgba(34,211,238,0.25)] whitespace-nowrap"
                  >
                    {chip.label}
                  </motion.span>
                </div>
              );
            })}
          </motion.div>
        )}

        {/* Real-time Audio Wave Indicator when Voice is active */}
        {isVoiceActive && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            <div className="flex items-center gap-1">
              {[0.4, 0.9, 0.6, 1.3, 0.8, 1.2, 0.5, 0.8, 1.1, 0.6].map((mult, idx) => (
                <motion.div
                  key={idx}
                  animate={{
                    height: [6, Math.max(8, pulse * mult * 0.5), 6],
                  }}
                  transition={{ duration: 0.15, repeat: Infinity }}
                  className="w-1 bg-emerald-300 rounded-full shadow-[0_0_8px_#34d399]"
                />
              ))}
            </div>
          </div>
        )}

        {/* Interactive Center Nucleus */}
        <motion.button
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.94 }}
          onClick={onActivateVoice}
          type="button"
          aria-label="Interactuar con el núcleo de Mily"
          className="group relative z-20 w-28 h-28 md:w-32 md:h-32 rounded-full cursor-pointer focus:outline-none"
        >
          {/* Animated Core Gradient Ring */}
          <div
            className={`w-full h-full rounded-full bg-gradient-to-tr ${stateConfig.coreColor} shadow-xl shadow-cyan-500/30 p-[2.5px] transition-all duration-500 ${
              state === 'processing' ? 'animate-[spin_4s_linear_infinite]' : ''
            }`}
          >
            <div className="w-full h-full rounded-full bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden backdrop-blur-md">
              {/* Internal holographic refraction shimmer */}
              <div className="absolute inset-0 bg-gradient-to-tr from-white/15 via-transparent to-transparent opacity-50 group-hover:opacity-100 transition-opacity" />

              <CurrentIcon
                className={`w-8 h-8 md:w-9 md:h-9 transition-all duration-300 ${
                  state === 'listening'
                    ? 'text-emerald-300 scale-110'
                    : state === 'processing'
                    ? 'text-purple-300 animate-pulse'
                    : state === 'executing'
                    ? 'text-amber-300 scale-105'
                    : 'text-cyan-300 group-hover:text-white'
                }`}
              />

              <span className="text-[10px] font-mono tracking-widest text-slate-300 uppercase mt-1 font-bold">
                MILY
              </span>
            </div>
          </div>

          {/* Micro satellite node orbiting */}
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee] pointer-events-none" />
        </motion.button>
      </div>

      {/* Real-time State & Status Badge */}
      <div className="mt-2 flex flex-col items-center gap-1.5 z-20">
        <motion.div
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ repeat: Infinity, duration: 2.5 }}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono border backdrop-blur-md ${stateConfig.badgeColor} transition-all duration-300 shadow-sm`}
        >
          <span className={`w-2.5 h-2.5 rounded-full ${stateConfig.dotColor}`} />
          <span className="font-bold tracking-wide">{stateConfig.label}</span>
          {state === 'processing' && (
            <Activity className="w-3.5 h-3.5 animate-spin text-purple-400" />
          )}
        </motion.div>

        <p className="text-[11px] font-mono text-slate-400/90 tracking-wider uppercase">
          {subtext}
        </p>
      </div>
    </div>
  );
};
