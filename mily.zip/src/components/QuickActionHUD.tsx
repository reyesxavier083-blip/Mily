import React, { useState } from 'react';
import {
  Plus,
  Play,
  Mic,
  Folder,
  Settings,
  X,
  Sparkles,
  Zap,
  Terminal,
} from 'lucide-react';

interface QuickActionHUDProps {
  onOpenVoice: () => void;
  onOpenFiles: () => void;
  onOpenSystem: () => void;
  onQuickCreate: () => void;
  onQuickExecute: () => void;
}

export const QuickActionHUD: React.FC<QuickActionHUDProps> = ({
  onOpenVoice,
  onOpenFiles,
  onOpenSystem,
  onQuickCreate,
  onQuickExecute,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const actions = [
    {
      id: 'create',
      label: 'Crear',
      icon: Plus,
      color: 'text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 border-cyan-500/30',
      action: () => {
        setIsOpen(false);
        onQuickCreate();
      },
      desc: 'Nuevo proyecto / prompt / memoria',
    },
    {
      id: 'execute',
      label: 'Ejecutar',
      icon: Play,
      color: 'text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border-amber-500/30',
      action: () => {
        setIsOpen(false);
        onQuickExecute();
      },
      desc: 'Disparar automatizaciones / tests',
    },
    {
      id: 'voice',
      label: 'Voz',
      icon: Mic,
      color: 'text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 border-emerald-500/30',
      action: () => {
        setIsOpen(false);
        onOpenVoice();
      },
      desc: 'Hablar directamente con Mily',
    },
    {
      id: 'files',
      label: 'Archivos',
      icon: Folder,
      color: 'text-blue-400 bg-blue-500/10 hover:bg-blue-500/20 border-blue-500/30',
      action: () => {
        setIsOpen(false);
        onOpenFiles();
      },
      desc: 'Explorador y Vector Store',
    },
    {
      id: 'system',
      label: 'Sistema',
      icon: Settings,
      color: 'text-purple-400 bg-purple-500/10 hover:bg-purple-500/20 border-purple-500/30',
      action: () => {
        setIsOpen(false);
        onOpenSystem();
      },
      desc: 'Telemetría y arquitectura modular',
    },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Expanded Quick Action Menu */}
      {isOpen && (
        <div className="mb-3 w-64 md:w-72 bg-slate-900/95 backdrop-blur-2xl border border-slate-700/80 rounded-2xl p-2.5 shadow-2xl shadow-black/80 animate-in fade-in slide-in-from-bottom-5">
          <div className="px-3 py-2 border-b border-slate-800/80 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-white tracking-wider uppercase">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              Acciones Rápidas
            </div>
            <span className="text-[10px] font-mono text-slate-500">MILY HUD</span>
          </div>

          <div className="py-1.5 space-y-1">
            {actions.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={item.action}
                  type="button"
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-left hover:bg-slate-800/80 transition-all group cursor-pointer"
                >
                  <div
                    className={`p-2 rounded-lg border transition-all ${item.color} group-hover:scale-105`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-slate-200 group-hover:text-white flex items-center justify-between">
                      <span>{item.label}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 truncate">{item.desc}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        type="button"
        aria-label="Abrir centro de acciones rápidas"
        className={`relative flex items-center gap-2.5 px-4 py-3 rounded-full font-mono text-xs font-semibold shadow-xl shadow-cyan-500/10 border transition-all duration-300 cursor-pointer ${
          isOpen
            ? 'bg-slate-800 text-white border-slate-600 scale-95'
            : 'bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 text-white border-cyan-400/40 hover:shadow-cyan-500/30 hover:scale-105'
        }`}
      >
        {isOpen ? (
          <>
            <X className="w-4 h-4 text-slate-300" />
            <span>Cerrar HUD</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span className="hidden sm:inline">ACCIONES RÁPIDAS</span>
            <span className="sm:hidden">HUD</span>
          </>
        )}

        {/* Ambient ping indicator */}
        {!isOpen && (
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500" />
          </span>
        )}
      </button>
    </div>
  );
};
