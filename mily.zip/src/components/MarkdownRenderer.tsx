import React, { useState } from 'react';
import { Check, Copy, Terminal } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  // Split content by code blocks: ```lang ... ```
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-3 text-slate-200 text-sm md:text-base leading-relaxed break-words font-normal">
      {parts.map((part, index) => {
        if (part.startsWith('```') && part.endsWith('```')) {
          const lines = part.slice(3, -3).trim().split('\n');
          const firstLine = lines[0].trim();
          const hasLanguage = /^[a-zA-Z0-9_-]+$/.test(firstLine);
          const language = hasLanguage ? firstLine : 'plaintext';
          const code = hasLanguage ? lines.slice(1).join('\n') : lines.join('\n');

          return <CodeBlock key={index} code={code} language={language} />;
        }

        return <TextSection key={index} text={part} />;
      })}
    </div>
  );
};

const CodeBlock: React.FC<{ code: string; language: string }> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-slate-800 bg-slate-950/90 shadow-lg">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900/90 border-b border-slate-800/80 text-xs">
        <div className="flex items-center gap-2 text-slate-400 font-mono">
          <Terminal className="w-3.5 h-3.5 text-emerald-400" />
          <span className="uppercase font-semibold tracking-wider text-[11px] text-emerald-400/90">
            {language}
          </span>
        </div>
        <button
          onClick={handleCopy}
          type="button"
          className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer text-xs"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400 font-medium">Copiado</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copiar</span>
            </>
          )}
        </button>
      </div>
      <div className="p-4 overflow-x-auto text-xs md:text-sm font-mono leading-relaxed text-emerald-100/90 bg-slate-950/60 selection:bg-emerald-500/30">
        <pre>{code}</pre>
      </div>
    </div>
  );
};

const TextSection: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');

  return (
    <>
      {lines.map((line, idx) => {
        const trimmed = line.trim();

        if (!trimmed) {
          return <div key={idx} className="h-2" />;
        }

        // Headers
        if (trimmed.startsWith('### ')) {
          return (
            <h4 key={idx} className="text-base md:text-lg font-semibold text-emerald-300 pt-2 pb-1">
              {formatInline(trimmed.replace(/^###\s+/, ''))}
            </h4>
          );
        }
        if (trimmed.startsWith('## ')) {
          return (
            <h3 key={idx} className="text-lg md:text-xl font-bold text-slate-100 pt-3 pb-1 border-b border-slate-800/60">
              {formatInline(trimmed.replace(/^##\s+/, ''))}
            </h3>
          );
        }
        if (trimmed.startsWith('# ')) {
          return (
            <h2 key={idx} className="text-xl md:text-2xl font-extrabold text-white pt-3 pb-1.5 border-b border-slate-800">
              {formatInline(trimmed.replace(/^#\s+/, ''))}
            </h2>
          );
        }

        // Blockquotes
        if (trimmed.startsWith('> ')) {
          return (
            <blockquote
              key={idx}
              className="pl-3.5 my-1.5 border-l-2 border-emerald-500/70 text-slate-300 italic bg-emerald-950/10 py-1 rounded-r"
            >
              {formatInline(trimmed.replace(/^>\s+/, ''))}
            </blockquote>
          );
        }

        // Bullet lists
        if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
          return (
            <div key={idx} className="flex items-start gap-2.5 my-1 pl-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2 shrink-0" />
              <div className="flex-1 text-slate-200">
                {formatInline(trimmed.replace(/^[-*]\s+/, ''))}
              </div>
            </div>
          );
        }

        // Numbered lists
        const numMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
        if (numMatch) {
          return (
            <div key={idx} className="flex items-start gap-2.5 my-1 pl-1">
              <span className="text-xs font-mono font-bold text-emerald-400 mt-0.5 shrink-0 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-500/30">
                {numMatch[1]}
              </span>
              <div className="flex-1 text-slate-200">
                {formatInline(numMatch[2])}
              </div>
            </div>
          );
        }

        // Default Paragraph
        return (
          <p key={idx} className="text-slate-200 leading-relaxed my-1">
            {formatInline(line)}
          </p>
        );
      })}
    </>
  );
};

// Formats inline bold, italics, and inline code with guaranteed unique keys
function formatInline(str: string): React.ReactNode {
  if (!str.includes('`') && !str.includes('*')) {
    return str;
  }

  const tokens: React.ReactNode[] = [];
  const codeParts = str.split(/(`[^`]+`)/g);
  let keyCounter = 0;

  for (const cPart of codeParts) {
    if (cPart.startsWith('`') && cPart.endsWith('`') && cPart.length > 2) {
      tokens.push(
        <code
          key={`code-${keyCounter++}`}
          className="px-1.5 py-0.5 mx-0.5 rounded bg-slate-800 text-emerald-300 font-mono text-xs border border-slate-700/60"
        >
          {cPart.slice(1, -1)}
        </code>
      );
      continue;
    }

    const boldParts = cPart.split(/(\*\*[^*]+\*\*)/g);
    for (const bPart of boldParts) {
      if (bPart.startsWith('**') && bPart.endsWith('**') && bPart.length > 4) {
        tokens.push(
          <strong key={`bold-${keyCounter++}`} className="font-semibold text-white">
            {bPart.slice(2, -2)}
          </strong>
        );
        continue;
      }

      const italicParts = bPart.split(/(\*[^*]+\*)/g);
      for (const itPart of italicParts) {
        if (itPart.startsWith('*') && itPart.endsWith('*') && itPart.length > 2) {
          tokens.push(
            <em key={`italic-${keyCounter++}`} className="italic text-slate-200">
              {itPart.slice(1, -1)}
            </em>
          );
        } else if (itPart) {
          tokens.push(itPart);
        }
      }
    }
  }

  return tokens;
}
