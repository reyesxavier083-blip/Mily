import React from 'react';
import {
  X,
  Sparkles,
  Code,
  Feather,
  TrendingUp,
  Atom,
  Check,
} from 'lucide-react';
import { Persona } from '../types/mily';
import { PERSONAS } from '../data/personas';

interface PersonaSelectorDialogProps {
  isOpen: boolean;
  onClose: () => void;
  activePersonaId: string;
  onSelectPersona: (persona: Persona) => void;
}

const iconMap: Record<string, React.ReactNode> = {
  Sparkles: <Sparkles className="w-5 h-5 text-emerald-400" />,
  Code: <Code className="w-5 h-5 text-cyan-400" />,
  Feather: <Feather className="w-5 h-5 text-purple-400" />,
  TrendingUp: <TrendingUp className="w-5 h-5 text-amber-400" />,
  Atom: <Atom className="w-5 h-5 text-blue-400" />,
};

export const PersonaSelectorDialog: React.FC<PersonaSelectorDialogProps> = ({
  isOpen,
  onClose,
  activePersonaId,
  onSelectPersona,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              Modos Cognitivos de Mily
            </h2>
            <p className="text-xs text-slate-400">
              Selecciona la especialización y tono que Mily adoptará en sus respuestas
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Personas Cards */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-3 flex-1">
          {PERSONAS.map((p) => {
            const isSelected = p.id === activePersonaId;

            return (
              <button
                key={p.id}
                onClick={() => {
                  onSelectPersona(p);
                  onClose();
                }}
                type="button"
                className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-4 ${
                  isSelected
                    ? 'bg-slate-800/90 border-emerald-500 shadow-md shadow-emerald-950/40 ring-1 ring-emerald-500/50'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                }`}
              >
                <div
                  className={`p-3 rounded-xl border ${
                    isSelected
                      ? 'bg-emerald-500/10 border-emerald-500/30'
                      : 'bg-slate-900 border-slate-800'
                  }`}
                >
                  {iconMap[p.iconName] || <Sparkles className="w-5 h-5 text-emerald-400" />}
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-100 text-sm md:text-base flex items-center gap-2">
                      {p.name}
                      <span className="text-xs font-normal text-slate-400 hidden sm:inline">
                        — {p.title}
                      </span>
                    </span>
                    {isSelected && (
                      <span className="flex items-center gap-1 text-xs text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                        <Check className="w-3.5 h-3.5" />
                        Activa
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed font-normal">
                    {p.description}
                  </p>
                  <p className="text-[11px] text-slate-400 italic pt-1">
                    "{p.tagline}"
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors text-xs font-semibold cursor-pointer"
          >
            Aceptar
          </button>
        </div>
      </div>
    </div>
  );
};
