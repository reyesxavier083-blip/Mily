import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Sparkles,
  Mic,
  MicOff,
  Send,
  Volume2,
  Brain,
  Wrench,
  Settings,
  Trash2,
  Copy,
  Check,
  RotateCcw,
  Square,
  ChevronDown,
  Activity,
  Edit3,
  Layers,
  LayoutDashboard,
  MessageSquare,
  Briefcase,
  Folder,
  Plus,
  X,
  Play,
  Zap,
} from 'lucide-react';
import {
  ChatMessage,
  MemoryItem,
  MemoryType,
  Persona,
  VoiceSettings,
  SystemStatus,
  ProjectItem,
  AutomationItem,
  FileRecord,
  MilyCoreState,
  ProcessConstellationState,
} from './types/mily';
import { PERSONAS } from './data/personas';
import {
  INITIAL_PROJECTS,
  INITIAL_AUTOMATIONS,
  INITIAL_FILES,
} from './data/modularSystemData';
import { AIVoiceOrb, OrbState } from './components/AIVoiceOrb';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { PersonaSelectorDialog } from './components/PersonaSelectorDialog';
import { MemoryHubSheet } from './components/MemoryHubSheet';
import { ToolsHubSheet } from './components/ToolsHubSheet';
import { VoiceSettingsSheet } from './components/VoiceSettingsSheet';
import { CorrectionFeedbackDialog } from './components/CorrectionFeedbackDialog';
import { QuickPromptChips } from './components/QuickPromptChips';
import { ImmersiveVoiceModal } from './components/ImmersiveVoiceModal';
import { MilyCoreNucleus } from './components/MilyCoreNucleus';
import { ModularDashboard } from './components/ModularDashboard';
import { ModularTreeViewer } from './components/ModularTreeViewer';
import { QuickActionHUD } from './components/QuickActionHUD';
import { MilyParticleCanvas } from './components/animation/MilyParticleCanvas';
import { ProcessConstellationModal } from './components/animation/ProcessConstellationModal';
import { EnergyStreamLines } from './components/animation/EnergyStreamLines';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';

const INITIAL_MEMORIES: MemoryItem[] = [
  {
    id: 'mem-1',
    type: 'preference',
    content: 'Prefiere respuestas articuladas en español, estructuradas con Markdown y código documentado.',
    timestamp: 'Hoy',
    category: 'Estilo',
  },
  {
    id: 'mem-2',
    type: 'goal',
    content: 'Explorando las capacidades de Mily y su Interfaz Modular Inteligente con núcleo dinámico.',
    timestamp: 'Hoy',
    category: 'Proyectos',
  },
  {
    id: 'mem-3',
    type: 'semantic',
    content: 'Usuario enfocado en ingeniería, productividad, creación y control modular del sistema.',
    timestamp: 'Hoy',
    category: 'Perfil',
  },
];

export default function App() {
  // Navigation / View Mode: 'dashboard' | 'chat' | 'modular'
  const [viewMode, setViewMode] = useState<'dashboard' | 'chat' | 'modular'>('dashboard');

  // Active Persona State
  const [activePersona, setActivePersona] = useState<Persona>(PERSONAS[0]);
  const [isPersonaModalOpen, setIsPersonaModalOpen] = useState(false);

  // Projects, Automations, Files State
  const [projects, setProjects] = useState<ProjectItem[]>(() => {
    const saved = localStorage.getItem('mily_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [automations, setAutomations] = useState<AutomationItem[]>(() => {
    const saved = localStorage.getItem('mily_automations');
    return saved ? JSON.parse(saved) : INITIAL_AUTOMATIONS;
  });

  const [files, setFiles] = useState<FileRecord[]>(INITIAL_FILES);

  // System Status State
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);

  // Core execution state for Nucleus
  const [manualCoreState, setManualCoreState] = useState<MilyCoreState | null>(null);

  // New Project Modal State
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [newProjectTitle, setNewProjectTitle] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectCategory, setNewProjectCategory] = useState<'Android' | 'Backend' | 'IA' | 'Web'>('Web');

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Messages State
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('mily_messages');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return [
      {
        id: 'welcome-msg',
        role: 'assistant',
        content: PERSONAS[0].greeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        personaId: PERSONAS[0].id,
      },
    ];
  });

  // Memory Hub State
  const [memories, setMemories] = useState<MemoryItem[]>(() => {
    const saved = localStorage.getItem('mily_memories');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return INITIAL_MEMORIES;
  });
  const [isMemoryHubOpen, setIsMemoryHubOpen] = useState(false);

  // Tools Hub State
  const [isToolsHubOpen, setIsToolsHubOpen] = useState(false);
  const [activeToolsTab, setActiveToolsTab] = useState<string | undefined>(undefined);

  // Voice Settings State
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>(() => {
    const saved = localStorage.getItem('mily_voice_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return {
      enabled: true,
      autoSpeak: false,
      voiceURI: '',
      rate: 1.05,
      pitch: 1.0,
      useGeminiTTS: false,
    };
  });
  const [isVoiceSettingsOpen, setIsVoiceSettingsOpen] = useState(false);

  // Immersive Voice Mode State
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);

  // Correction Feedback State
  const [feedbackDialogData, setFeedbackDialogData] = useState<{
    isOpen: boolean;
    targetMessage?: ChatMessage;
  }>({ isOpen: false });

  // Input State
  const [inputText, setInputText] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [systemUptime, setSystemUptime] = useState(120);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Speech Synthesis Hook
  const { isSpeaking, speak, stopSpeaking } = useSpeechSynthesis(voiceSettings);

  // Speech Recognition Hook
  const handleFinalVoiceResult = useCallback((text: string) => {
    if (text.trim()) {
      handleSendMessage(text.trim());
    }
  }, []);

  const { isListening, transcript, startListening, stopListening } =
    useSpeechRecognition(handleFinalVoiceResult);

  // Trigger quick toast
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Determine computed Mily Core state:
  const computedCoreState: MilyCoreState = manualCoreState
    ? manualCoreState
    : isListening
    ? 'listening'
    : isStreaming
    ? 'processing'
    : isSpeaking
    ? 'executing'
    : 'idle';

  // OrbState for voice modal
  const orbState: OrbState = isListening
    ? 'listening'
    : isStreaming
    ? 'thinking'
    : isSpeaking
    ? 'speaking'
    : 'idle';

  // Fetch system status on load
  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/status');
        if (res.ok) {
          const data = await res.json();
          setSystemStatus(data);
          if (data.uptime) setSystemUptime(data.uptime);
        }
      } catch (e) {
        console.warn('Status fetch error', e);
      }
    };
    fetchStatus();
    const interval = setInterval(fetchStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  // Sync projects and automations to localStorage
  useEffect(() => {
    localStorage.setItem('mily_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('mily_automations', JSON.stringify(automations));
  }, [automations]);

  useEffect(() => {
    localStorage.setItem('mily_messages', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('mily_memories', JSON.stringify(memories));
  }, [memories]);

  useEffect(() => {
    localStorage.setItem('mily_voice_settings', JSON.stringify(voiceSettings));
  }, [voiceSettings]);

  // Memory Handlers
  const handleAddMemory = (type: MemoryType, content: string, category: string) => {
    const newMem: MemoryItem = {
      id: `mem-${Date.now()}`,
      type,
      content,
      timestamp: 'Ahora',
      category,
    };
    setMemories((prev) => [newMem, ...prev]);
  };

  const handleDeleteMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  // Toggle Voice Listening
  const handleToggleVoice = () => {
    if (isListening) {
      stopListening();
    } else {
      if (isSpeaking) stopSpeaking();
      startListening();
    }
  };

  // Process Constellation State (Execution Nodes Visualization)
  const [processState, setProcessState] = useState<ProcessConstellationState>({
    isOpen: false,
    processName: 'MILY CORE EXECUTION',
    percentage: 0,
    phase: 'Inicializando subrutinas...',
    nodes: [
      { id: 'core', label: 'MILY CORE', active: true, completed: false },
      { id: 'mem', label: 'MEMORY STORE', active: false, completed: false },
      { id: 'ai', label: 'NEURAL ROUTER', active: false, completed: false },
      { id: 'tools', label: 'TOOL GATEWAY', active: false, completed: false },
    ],
  });

  // Launch Process with constellation animation
  const handleLaunchProcess = (processName: string, onDone?: () => void) => {
    setProcessState({
      isOpen: true,
      processName,
      percentage: 12,
      phase: 'Sincronizando con Mily Core...',
      nodes: [
        { id: 'core', label: 'MILY CORE', active: true, completed: false },
        { id: 'mem', label: 'MEMORY STORE', active: false, completed: false },
        { id: 'ai', label: 'NEURAL ROUTER', active: false, completed: false },
        { id: 'tools', label: 'TOOL GATEWAY', active: false, completed: false },
      ],
    });

    setManualCoreState('executing');

    setTimeout(() => {
      setProcessState((prev) => ({
        ...prev,
        percentage: 42,
        phase: 'Indexando contexto y memoria episódica...',
      }));
    }, 450);

    setTimeout(() => {
      setProcessState((prev) => ({
        ...prev,
        percentage: 76,
        phase: 'Validando herramientas y canal neural...',
      }));
    }, 1000);

    setTimeout(() => {
      setProcessState((prev) => ({
        ...prev,
        percentage: 100,
        phase: 'Proceso completado con éxito.',
      }));
      setManualCoreState('completed');
      if (onDone) onDone();

      setTimeout(() => {
        setManualCoreState(null);
      }, 3000);
    }, 1600);
  };

  // Trigger Automation
  const handleRunAutomation = (id: string) => {
    const target = automations.find((a) => a.id === id);
    if (!target) return;

    handleLaunchProcess(`Pipeline: ${target.name}`, () => {
      setAutomations((prev) =>
        prev.map((a) => (a.id === id ? { ...a, lastRun: 'Ahora mismo', status: 'ok' } : a))
      );
      showToast(`Completado: ${target.name}`);
    });
  };

  const handleToggleAutomation = (id: string) => {
    setAutomations((prev) =>
      prev.map((a) => (a.id === id ? { ...a, active: !a.active } : a))
    );
  };

  // Create Project
  const handleSaveNewProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectTitle.trim()) return;

    const newProj: ProjectItem = {
      id: `proj-${Date.now()}`,
      title: newProjectTitle.trim(),
      description: newProjectDesc.trim() || 'Proyecto modular gestionado por MILY.',
      category: newProjectCategory,
      progress: 10,
      status: 'activo',
      tags: [newProjectCategory, 'Mily-Core'],
      lastUpdated: 'Ahora',
    };

    setProjects((prev) => [newProj, ...prev]);
    setIsNewProjectModalOpen(false);
    setNewProjectTitle('');
    setNewProjectDesc('');
    showToast(`Proyecto creado: ${newProj.title}`);
  };

  // Autonomous Memory Extractor
  const checkAutonomousLearning = async (userMsg: string, assistantReply: string) => {
    try {
      const res = await fetch('/api/learn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userMessage: userMsg, assistantReply }),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.facts) && data.facts.length > 0) {
          data.facts.forEach((fact: any) => {
            if (fact.content) {
              handleAddMemory(fact.type || 'semantic', fact.content, 'Aprendizaje');
            }
          });
        }
      }
    } catch {}
  };

  // Send Message function
  const handleSendMessage = async (textToSend?: string) => {
    const messageContent = (textToSend || inputText).trim();
    if (!messageContent || isStreaming) return;

    if (isSpeaking) stopSpeaking();
    if (isListening) stopListening();

    const userMessageId = `user-${Date.now()}`;
    const userTimestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const userMessage: ChatMessage = {
      id: userMessageId,
      role: 'user',
      content: messageContent,
      timestamp: userTimestamp,
    };

    const assistantMessageId = `mily-${Date.now()}`;
    const assistantTimestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const placeholderAssistant: ChatMessage = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: assistantTimestamp,
      personaId: activePersona.id,
      isStreaming: true,
    };

    const updatedMessages = [...messages, userMessage, placeholderAssistant];
    setMessages(updatedMessages);
    setInputText('');
    setIsStreaming(true);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }

    try {
      abortControllerRef.current = new AbortController();

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages.slice(0, -1).map((m) => ({
            role: m.role,
            content: m.content,
          })),
          persona: activePersona.id,
          memories: memories.map((m) => ({ type: m.type, content: m.content })),
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      if (!response.body) {
        throw new Error('No readable stream received');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let fullReply = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.replace(/^data:\s*/, '').trim();
            if (dataStr === '[DONE]') break;

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                fullReply += parsed.text;
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantMessageId
                      ? { ...msg, content: fullReply, isStreaming: true }
                      : msg
                  )
                );
              }
            } catch {
              // Non-JSON SSE string
              if (dataStr) {
                fullReply += dataStr;
                setMessages((prev) =>
                  prev.map((msg) =>
                    msg.id === assistantMessageId
                      ? { ...msg, content: fullReply, isStreaming: true }
                      : msg
                  )
                );
              }
            }
          }
        }
      }

      // Finalize streaming
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMessageId
            ? { ...msg, isStreaming: false, content: fullReply }
            : msg
        )
      );

      // Auto-speak if enabled
      if (voiceSettings.autoSpeak && fullReply) {
        speak(fullReply);
      }

      // Check autonomous learning
      checkAutonomousLearning(messageContent, fullReply);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User stopped generation
      } else {
        console.error('Chat error:', err);
        const errorReply =
          'Lo siento, ocurrió una interrupción en mi conexión con el modelo Gemini 3.8 Flash. Por favor verifica tu conexión o intenta nuevamente.';
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === assistantMessageId
              ? { ...msg, content: errorReply, isStreaming: false }
              : msg
          )
        );
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  };

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  const handleClearHistory = () => {
    if (window.confirm('¿Deseas reiniciar la conversación con Mily?')) {
      stopSpeaking();
      const freshWelcome: ChatMessage = {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        content: activePersona.greeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        personaId: activePersona.id,
      };
      setMessages([freshWelcome]);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setMessages((prev) =>
      prev.map((m) => (m.id === id ? { ...m, copied: true } : m))
    );
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === id ? { ...m, copied: false } : m))
      );
    }, 2000);
  };

  const handleSaveCorrection = (correction: string) => {
    handleAddMemory('preference', correction, 'Corrección de usuario');
    const ackMessage: ChatMessage = {
      id: `ack-${Date.now()}`,
      role: 'assistant',
      content: `He integrado esta corrección en mi memoria semántica permanente: *" ${correction} "*. A partir de ahora tendré esto siempre en cuenta.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      personaId: activePersona.id,
    };
    setMessages((prev) => [...prev, ackMessage]);
  };

  // Find last assistant reply for voice modal
  const lastAssistantReply =
    messages.filter((m) => m.role === 'assistant').slice(-1)[0]?.content || '';

  return (
    <div
      className={`flex flex-col h-screen bg-[#080b11] text-slate-100 overflow-hidden font-sans relative transition-all duration-700 ${
        isSpeaking ? 'ring-1 ring-cyan-500/30 shadow-[inset_0_0_80px_rgba(34,211,238,0.06)]' : ''
      }`}
    >
      {/* Background Interactive Quantum Particle System */}
      <MilyParticleCanvas intensity={voiceSettings.animationIntensity || 'cinematic'} />

      {/* Cybernetic Energy Stream Beams */}
      <EnergyStreamLines intensity={voiceSettings.animationIntensity || 'cinematic'} />

      {/* Background cyber ambient gradients */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* TOP HEADER */}
      <header className="h-16 px-4 md:px-6 bg-slate-900/80 border-b border-slate-800/80 backdrop-blur-xl flex items-center justify-between z-30 shrink-0">
        {/* Brand & Persona Switcher */}
        <div className="flex items-center gap-3">
          {/* Mily Mini Glow Avatar */}
          <div className="relative flex items-center justify-center">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-cyan-500 via-teal-500 to-emerald-400 p-[1.5px] shadow-sm shadow-cyan-500/30">
              <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-cyan-400" />
              </div>
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-950 animate-pulse" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-sm md:text-base text-white tracking-tight flex items-center gap-1.5">
                MILY
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  MODULAR INTERFACE
                </span>
              </h1>
            </div>
            <p className="text-[11px] text-slate-400 font-mono hidden sm:block">
              Núcleo Central · Gemini 3.8 Flash & GPT-6
            </p>
          </div>
        </div>

        {/* View Mode Navigation Switcher */}
        <div className="flex items-center bg-slate-950/80 border border-slate-800 p-1 rounded-xl">
          <button
            onClick={() => setViewMode('dashboard')}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              viewMode === 'dashboard'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Centro de Control</span>
            <span className="sm:hidden">Control</span>
          </button>

          <button
            onClick={() => setViewMode('chat')}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              viewMode === 'chat'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Asistente & Chat</span>
            <span className="sm:hidden">Chat</span>
          </button>

          <button
            onClick={() => setViewMode('modular')}
            type="button"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              viewMode === 'modular'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Arquitectura</span>
            <span className="sm:hidden">Módulos</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Persona selector button */}
          <button
            onClick={() => setIsPersonaModalOpen(true)}
            type="button"
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-300 cursor-pointer transition-colors"
          >
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <span>{activePersona.name}</span>
            <ChevronDown className="w-3 h-3 text-slate-500" />
          </button>

          {/* Voice Mode */}
          <button
            onClick={() => setIsVoiceModalOpen(true)}
            type="button"
            className="p-2 md:px-3 md:py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Abrir consola de voz inmersiva"
          >
            <Mic className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Modo Voz</span>
          </button>

          {/* Memory Hub */}
          <button
            onClick={() => setIsMemoryHubOpen(true)}
            type="button"
            className="p-2 md:px-3 md:py-1.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Memoria cognitiva de Mily"
          >
            <Brain className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Memoria</span>
          </button>

          {/* Tools Hub */}
          <button
            onClick={() => {
              setActiveToolsTab(undefined);
              setIsToolsHubOpen(true);
            }}
            type="button"
            className="p-2 md:px-3 md:py-1.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Tool Gateway"
          >
            <Wrench className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Tools</span>
          </button>

          {/* Voice Settings */}
          <button
            onClick={() => setIsVoiceSettingsOpen(true)}
            type="button"
            className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Ajustes de voz y audio"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="absolute top-20 right-6 z-50 px-4 py-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 text-xs font-mono shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* MAIN VIEW CONTENT CONTAINER */}
      <main className="flex-1 overflow-y-auto relative p-4 md:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        {/* VIEW 1: CENTRO DE CONTROL (MODULAR DASHBOARD + NÚCLEO CENTRAL) */}
        {viewMode === 'dashboard' && (
          <div className="space-y-8 animate-in fade-in">
            {/* Núcleo Central Dinámico */}
            <div className="flex flex-col items-center justify-center pt-2 pb-4 text-center">
              <MilyCoreNucleus
                state={computedCoreState}
                isSpeaking={isSpeaking}
                onActivateVoice={() => setIsVoiceModalOpen(true)}
                subtext={`MILY INTELLIGENT MODULAR INTERFACE // ${activePersona.name}`}
                intensity={voiceSettings.animationIntensity || 'cinematic'}
              />

              <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight mt-1">
                ¿En qué trabajamos?
              </h2>
              <p className="text-xs md:text-sm text-slate-400 max-w-md mx-auto mt-1">
                Controla proyectos, memoria, herramientas y automatizaciones desde tu centro de mando modular.
              </p>

              {/* Center Quick Action Buttons (matching concept mockup) */}
              <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                <button
                  onClick={() => setIsNewProjectModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 text-xs font-mono text-indigo-300 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm hover:scale-105"
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>PROYECTOS</span>
                </button>

                <button
                  onClick={() => {
                    handleSendMessage('Enumera los archivos de código clave y el esquema de conocimiento de Mily');
                    setViewMode('chat');
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 text-xs font-mono text-blue-300 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm hover:scale-105"
                >
                  <Folder className="w-3.5 h-3.5" />
                  <span>ARCHIVOS</span>
                </button>

                <button
                  onClick={() => {
                    setActiveToolsTab(undefined);
                    setIsToolsHubOpen(true);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 text-xs font-mono text-amber-300 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm hover:scale-105"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>TOOLS</span>
                </button>

                <button
                  onClick={() => setIsVoiceModalOpen(true)}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-mono text-xs font-bold transition-all hover:scale-105 flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-600/25"
                >
                  <Mic className="w-4 h-4" />
                  <span>HABLAR CON MILY</span>
                </button>
              </div>
            </div>

            {/* Modular Dashboard Cards Grid */}
            <ModularDashboard
              activePersona={activePersona}
              projects={projects}
              automations={automations}
              files={files}
              systemStatus={systemStatus}
              lastMessage={messages.slice(-1)[0]}
              onOpenChat={() => setViewMode('chat')}
              onOpenVoice={() => setIsVoiceModalOpen(true)}
              onOpenTools={(tab) => {
                setActiveToolsTab(tab);
                setIsToolsHubOpen(true);
              }}
              onOpenMemory={() => setIsMemoryHubOpen(true)}
              onOpenSettings={() => setIsVoiceSettingsOpen(true)}
              onRunAutomation={handleRunAutomation}
              onToggleAutomation={handleToggleAutomation}
              onCreateProject={() => setIsNewProjectModalOpen(true)}
              onSelectPrompt={(p) => {
                handleSendMessage(p);
                setViewMode('chat');
              }}
            />
          </div>
        )}

        {/* VIEW 2: ASISTENTE & CHAT EN VIVO */}
        {viewMode === 'chat' && (
          <div className="flex flex-col h-full max-w-4xl mx-auto space-y-4 animate-in fade-in">
            {/* Chat header bar */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-cyan-400">
                  DIÁLOGO CON MILY:
                </span>
                <span className="text-xs text-slate-300 font-semibold">{activePersona.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleClearHistory}
                  type="button"
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono text-slate-400 hover:text-rose-400 hover:bg-slate-900 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Limpiar</span>
                </button>
                <button
                  onClick={() => setIsPersonaModalOpen(true)}
                  type="button"
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-mono bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
                >
                  <span>Cambiar Modo</span>
                </button>
              </div>
            </div>

            {/* Message Stream */}
            <div className="flex-1 space-y-4 overflow-y-auto pr-1">
              {messages.map((message, messageIndex) => {
                const isUser = message.role === 'user';
                return (
                  <div
                    key={`${message.id || 'msg'}-${messageIndex}`}
                    className={`flex gap-3 md:gap-4 ${
                      isUser ? 'justify-end' : 'justify-start'
                    } animate-in fade-in`}
                  >
                    {!isUser && (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-emerald-400 p-[1.5px] shrink-0 mt-0.5 shadow-sm">
                        <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center">
                          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                        </div>
                      </div>
                    )}

                    <div
                      className={`max-w-[85%] md:max-w-[78%] rounded-2xl p-4 shadow-md ${
                        isUser
                          ? 'bg-gradient-to-r from-cyan-900/60 to-blue-900/60 border border-cyan-500/30 text-white rounded-tr-sm'
                          : 'bg-slate-900/80 border border-slate-800/80 text-slate-200 rounded-tl-sm'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-1.5 gap-4">
                        <span>{isUser ? 'Tú' : 'Mily'}</span>
                        <span>{message.timestamp}</span>
                      </div>

                      {/* Content */}
                      <div className="text-sm leading-relaxed">
                        {isUser ? (
                          <p className="whitespace-pre-wrap font-sans">{message.content}</p>
                        ) : (
                          <MarkdownRenderer content={message.content} />
                        )}
                      </div>

                      {/* Action buttons on assistant message */}
                      {!isUser && (
                        <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-800/70 text-xs text-slate-400 font-mono">
                          <button
                            onClick={() => handleCopyMessage(message.id, message.content)}
                            type="button"
                            className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                          >
                            {message.copied ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                            <span>{message.copied ? 'Copiado' : 'Copiar'}</span>
                          </button>

                          <button
                            onClick={() => speak(message.content)}
                            type="button"
                            className="flex items-center gap-1 hover:text-emerald-400 transition-colors cursor-pointer ml-2"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Escuchar</span>
                          </button>

                          <button
                            onClick={() =>
                              setFeedbackDialogData({ isOpen: true, targetMessage: message })
                            }
                            type="button"
                            className="flex items-center gap-1 hover:text-cyan-400 transition-colors cursor-pointer ml-auto"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Enseñar a Mily</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Prompt Chips */}
            <QuickPromptChips
              prompts={activePersona.suggestedPrompts}
              onSelectPrompt={handleSendMessage}
            />

            {/* Input Bar */}
            <div className="pt-2">
              <div className="relative rounded-2xl bg-slate-900/90 border border-slate-800 focus-within:border-cyan-500/60 p-2 shadow-2xl transition-all">
                <textarea
                  ref={textareaRef}
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  rows={2}
                  placeholder="Escribe una instrucción, pregunta o tarea para Mily..."
                  className="w-full bg-transparent text-sm text-slate-100 placeholder:text-slate-500 px-3 py-1 focus:outline-none resize-none font-sans"
                />

                <div className="flex items-center justify-between pt-2 px-2 border-t border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleToggleVoice}
                      type="button"
                      className={`p-2 rounded-xl transition-all cursor-pointer ${
                        isListening
                          ? 'bg-rose-500 text-white animate-pulse'
                          : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
                      }`}
                      title="Hablar por micrófono"
                    >
                      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </button>
                    {isListening && (
                      <span className="text-xs font-mono text-rose-400 animate-pulse">
                        Escuchando...
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {isStreaming ? (
                      <button
                        onClick={handleStopStreaming}
                        type="button"
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer shadow-md"
                      >
                        <Square className="w-3.5 h-3.5 fill-current" />
                        <span>Detener</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleSendMessage()}
                        disabled={!inputText.trim()}
                        type="button"
                        className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white text-xs font-semibold cursor-pointer transition-all shadow-md shadow-cyan-600/30"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Enviar</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 3: ARQUITECTURA MODULAR */}
        {viewMode === 'modular' && (
          <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in">
            <ModularTreeViewer
              onModuleAction={(modName) => {
                showToast(`Módulo seleccionado: ${modName}`);
                handleSendMessage(`Explica el rol y las directrices operacionales del módulo "${modName}" en la arquitectura de MILY.`);
                setViewMode('chat');
              }}
            />
          </div>
        )}
      </main>

      {/* QUICK ACTION FLOATING HUD MATRIX */}
      <QuickActionHUD
        onOpenVoice={() => setIsVoiceModalOpen(true)}
        onOpenFiles={() => {
          handleSendMessage('Haz un inventario y resumen de los archivos clave del repositorio de Mily');
          setViewMode('chat');
        }}
        onOpenSystem={() => {
          setActiveToolsTab('diagnostics');
          setIsToolsHubOpen(true);
        }}
        onQuickCreate={() => setIsNewProjectModalOpen(true)}
        onQuickExecute={() => handleLaunchProcess('Auditoría General & Optimización Neural')}
      />

      {/* NEW PROJECT MODAL */}
      {isNewProjectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-cyan-400" />
                Nuevo Proyecto en MILY
              </h3>
              <button
                onClick={() => setIsNewProjectModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveNewProject} className="space-y-4">
              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">
                  Nombre del Proyecto:
                </label>
                <input
                  type="text"
                  required
                  value={newProjectTitle}
                  onChange={(e) => setNewProjectTitle(e.target.value)}
                  placeholder="ej. Mily Autonomous Pipeline"
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">Categoría:</label>
                <select
                  value={newProjectCategory}
                  onChange={(e) => setNewProjectCategory(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="Web">Web (Modular Interface)</option>
                  <option value="Android">Android (Kotlin / Room)</option>
                  <option value="Backend">Backend (Responses API / Node)</option>
                  <option value="IA">IA (Cognitive Models / RAG)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">
                  Descripción o Alcance:
                </label>
                <textarea
                  rows={3}
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  placeholder="Objetivo principal, tecnologías y requerimientos..."
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewProjectModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold cursor-pointer shadow-md shadow-cyan-600/30"
                >
                  Crear Proyecto
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* IMMERSIVE VOICE CONSOLE MODAL */}
      <ImmersiveVoiceModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        orbState={orbState}
        onToggleListen={handleToggleVoice}
        onStopSpeaking={stopSpeaking}
        transcript={transcript}
        lastAssistantReply={lastAssistantReply}
        activePersona={activePersona}
        onSelectPrompt={(p) => {
          setIsVoiceModalOpen(false);
          handleSendMessage(p);
          setViewMode('chat');
        }}
      />

      {/* PERSONA SELECTOR DIALOG */}
      <PersonaSelectorDialog
        isOpen={isPersonaModalOpen}
        onClose={() => setIsPersonaModalOpen(false)}
        activePersonaId={activePersona.id}
        onSelectPersona={(persona) => {
          setActivePersona(persona);
          setIsPersonaModalOpen(false);
          showToast(`Modo cambiado a: ${persona.name}`);
        }}
      />

      {/* MEMORY HUB SHEET */}
      <MemoryHubSheet
        isOpen={isMemoryHubOpen}
        onClose={() => setIsMemoryHubOpen(false)}
        memories={memories}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
      />

      {/* TOOLS HUB SHEET */}
      <ToolsHubSheet
        isOpen={isToolsHubOpen}
        onClose={() => setIsToolsHubOpen(false)}
        onSendToMily={(prompt) => {
          setIsToolsHubOpen(false);
          handleSendMessage(prompt);
          setViewMode('chat');
        }}
        systemUptime={systemUptime}
        memoryCount={memories.length}
        initialTab={activeToolsTab}
      />

      {/* VOICE SETTINGS SHEET */}
      <VoiceSettingsSheet
        isOpen={isVoiceSettingsOpen}
        onClose={() => setIsVoiceSettingsOpen(false)}
        settings={voiceSettings}
        onUpdateSettings={(newSettings) =>
          setVoiceSettings((prev) => ({ ...prev, ...newSettings }))
        }
        onTestVoice={(sampleText) => speak(sampleText)}
      />

      {/* CORRECTION / TEACH MILY DIALOG */}
      <CorrectionFeedbackDialog
        isOpen={feedbackDialogData.isOpen}
        onClose={() => setFeedbackDialogData({ isOpen: false })}
        targetMessageContent={feedbackDialogData.targetMessage?.content}
        onSaveCorrection={handleSaveCorrection}
      />

      {/* PROCESS CONSTELLATION EXECUTION MODAL */}
      <ProcessConstellationModal
        state={processState}
        onClose={() => setProcessState((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}
