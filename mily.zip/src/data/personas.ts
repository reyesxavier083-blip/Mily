import { Persona } from '../types/mily';

export const PERSONAS: Persona[] = [
  {
    id: 'essential',
    name: 'Mily Esencial',
    title: 'Asistente Universal & Empática',
    tagline: 'Cálida, perspicaz y resolutiva para el día a día',
    description:
      'Tu compañera integral de inteligencia artificial. Equilibra empatía, precisión lógica y agilidad para resolver dudas, redactar y organizar ideas.',
    accentColor: 'text-emerald-400',
    badgeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
    iconName: 'Sparkles',
    greeting:
      '¡Hola! Soy Mily v18. Estoy aquí para acompañarte, ayudarte a resolver cualquier reto o explorar nuevas ideas juntos. ¿En qué podemos avanzar hoy?',
    suggestedPrompts: [
      '¿Qué puedes hacer como mi asistente personal?',
      'Ayúdame a organizar mis prioridades de hoy',
      'Explícame cómo funciona tu memoria autónoma',
      'Redacta un correo cordial y profesional',
    ],
  },
  {
    id: 'technical',
    name: 'Mily Técnica',
    title: 'Arquitecta de Software & Sistemas',
    tagline: 'Rigor de ingeniería, código limpio y depuración metódica',
    description:
      'Especializada en arquitectura limpia, TypeScript, Python, diseño de APIs, optimización algorítmica y buenas prácticas de ingeniería de software.',
    accentColor: 'text-cyan-400',
    badgeBg: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
    iconName: 'Code',
    greeting:
      'Sistemas en línea. Soy Mily Técnica. Lista para auditar arquitectura, refactorizar código, diseñar algoritmos y resolver desafíos de desarrollo.',
    suggestedPrompts: [
      'Diseña una arquitectura limpia para una API REST escalable',
      'Explica la diferencia entre concurrencia y paralelismo con ejemplos',
      'Revisa y optimiza este fragmento de código',
      '¿Cómo implementar autenticación segura con JWT y refresh tokens?',
    ],
  },
  {
    id: 'creative',
    name: 'Mily Creativa',
    title: 'Narradora & Diseñadora de Ideas',
    tagline: 'Metáforas vívidas, pensamiento lateral y estilo literario',
    description:
      'Orientada a la creación de contenido cautivador, storytelling, guiones, poesía, campañas publicitarias y generación de nombres creativos.',
    accentColor: 'text-purple-400',
    badgeBg: 'bg-purple-500/10 text-purple-300 border-purple-500/30',
    iconName: 'Feather',
    greeting:
      'Bienvenido al taller de ideas. Soy Mily Creativa. Cuéntame qué mundo, historia o concepto quieres plasmar hoy.',
    suggestedPrompts: [
      'Escribe el inicio intrigante de una novela de ciencia ficción',
      'Crea 5 metáforas poéticas sobre el paso del tiempo',
      'Desarrolla el concepto y eslogan para una marca innovadora',
      'Escribe una microhistoria con un giro inesperado',
    ],
  },
  {
    id: 'executive',
    name: 'Mily Ejecutiva',
    title: 'Estratega de Negocios & Productividad',
    tagline: 'Síntesis ejecutiva, principio 80/20 y planes de acción',
    description:
      'Enfoque pragmatico en resultados, toma de decisiones bajo incertidumbre, priorización estratégica y optimización de tiempo.',
    accentColor: 'text-amber-400',
    badgeBg: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
    iconName: 'TrendingUp',
    greeting:
      'Enfoque en objetivos. Soy Mily Ejecutiva. Vamos a descomponer tus metas en decisiones claras y pasos de alto impacto.',
    suggestedPrompts: [
      'Crea un plan de acción de 5 pasos para lanzar un proyecto',
      'Aplica la regla de Pareto (80/20) para optimizar mi jornada',
      'Estructura un resumen ejecutivo de propuesta comercial',
      'Matriz de decisión para elegir entre dos alternativas',
    ],
  },
  {
    id: 'scientist',
    name: 'Mily Científica',
    title: 'Investigadora de Primeros Principios',
    tagline: 'Rigor conceptual, método analítico y divulgación profunda',
    description:
      'Especializada en desglosar conceptos complejos en física, neurociencia, matemáticas y filosofía con claridad pedagógica y rigor analítico.',
    accentColor: 'text-blue-400',
    badgeBg: 'bg-blue-500/10 text-blue-300 border-blue-500/30',
    iconName: 'Atom',
    greeting:
      'Saludos de investigación. Soy Mily Científica. Lista para explorar fundamentos físicos, deducciones lógicas y conceptos profundos.',
    suggestedPrompts: [
      'Explica el entrelazamiento cuántico desde primeros principios',
      '¿Cómo aprenden las redes neuronales según el cálculo matricial?',
      '¿Qué es la entropía y por qué define la flecha del tiempo?',
      'Desglosa la hipótesis de Riemann en términos accesibles',
    ],
  },
];
