export type Role = 'user' | 'assistant' | 'system';

export type MilyCoreState = 'idle' | 'listening' | 'processing' | 'executing' | 'completed';

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  timestamp: string;
  personaId?: string;
  isStreaming?: boolean;
  copied?: boolean;
}

export interface Persona {
  id: string;
  name: string;
  title: string;
  tagline: string;
  description: string;
  accentColor: string;
  badgeBg: string;
  iconName: string;
  greeting: string;
  suggestedPrompts: string[];
}

export type MemoryType = 'semantic' | 'episodic' | 'preference' | 'goal';

export interface MemoryItem {
  id: string;
  type: MemoryType;
  content: string;
  timestamp: string;
  category: string;
}

export type AnimationIntensity = 'cinematic' | 'balanced' | 'performance';

export interface AnimationEngineConfig {
  intensity: AnimationIntensity;
  particlesEnabled: boolean;
  energyStreamsEnabled: boolean;
  holographicShimmer: boolean;
  audioReactivity: boolean;
  microInteractions: boolean;
}

export interface VoiceSettings {
  enabled: boolean;
  autoSpeak: boolean;
  voiceURI: string;
  rate: number;
  pitch: number;
  useGeminiTTS: boolean;
  animationIntensity?: AnimationIntensity;
}

export interface SystemStatus {
  status: string;
  version: string;
  name: string;
  model: string;
  hasApiKey: boolean;
  engines: Record<string, string>;
  uptime: number;
}

export interface ProjectItem {
  id: string;
  title: string;
  description: string;
  category: 'Android' | 'Backend' | 'IA' | 'Web';
  progress: number;
  status: 'en_progreso' | 'activo' | 'completado' | 'pausado';
  tags: string[];
  lastUpdated: string;
}

export interface AutomationItem {
  id: string;
  name: string;
  description: string;
  trigger: string;
  active: boolean;
  lastRun: string;
  status: 'ok' | 'running' | 'idle';
}

export interface FileRecord {
  id: string;
  name: string;
  path: string;
  size: string;
  type: 'code' | 'doc' | 'config' | 'dataset';
  vectorIndexed: boolean;
  lastModified: string;
}

export interface ModularBranch {
  category: 'CORE' | 'UI' | 'TOOLS' | 'SETTINGS';
  description: string;
  modules: {
    name: string;
    description: string;
    status: 'activo' | 'standby' | 'operativo';
    version?: string;
  }[];
}

export interface ProcessNode {
  id: string;
  label: string;
  active: boolean;
  completed: boolean;
  x?: number;
  y?: number;
}

export interface ProcessConstellationState {
  isOpen: boolean;
  processName: string;
  percentage: number;
  phase: string;
  nodes: ProcessNode[];
}
