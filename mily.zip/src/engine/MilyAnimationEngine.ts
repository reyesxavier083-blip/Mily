import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { AnimationIntensity, AnimationEngineConfig, ProcessConstellationState } from '../types/mily';

export interface MilyAnimationEngineContextType {
  config: AnimationEngineConfig;
  updateIntensity: (intensity: AnimationIntensity) => void;
  toggleParticles: () => void;
  toggleEnergyStreams: () => void;
  processState: ProcessConstellationState;
  startProcess: (processName: string, onFinished?: () => void) => void;
  closeProcess: () => void;
  successPulse: boolean;
  errorPulse: boolean;
  triggerSuccess: () => void;
  triggerError: () => void;
  triggerRipple: (e: React.MouseEvent) => void;
  activeRipples: { id: number; x: number; y: number }[];
}

export const DEFAULT_ANIMATION_CONFIG: AnimationEngineConfig = {
  intensity: 'cinematic',
  particlesEnabled: true,
  energyStreamsEnabled: true,
  holographicShimmer: true,
  audioReactivity: true,
  microInteractions: true,
};

export const createInitialProcessState = (): ProcessConstellationState => ({
  isOpen: false,
  processName: 'MILY CORE EXECUTION',
  percentage: 0,
  phase: 'Inicializando subrutinas...',
  nodes: [
    { id: 'core', label: 'MILY CORE', active: true, completed: false },
    { id: 'mem', label: 'MEMORY STORE', active: false, completed: false },
    { id: 'ai', label: 'NEURAL ROUTER', active: false, completed: false },
    { id: 'tools', label: 'TOOL GATEWAY', active: false, completed: false },
  ],
});
