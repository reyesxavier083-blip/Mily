import { useState, useEffect, useCallback, useRef } from 'react';
import { VoiceSettings } from '../types/mily';

export const useSpeechSynthesis = (settings: VoiceSettings) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Stop any ongoing speech
  const stopSpeaking = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsSpeaking(false);
  }, []);

  const speak = useCallback(
    async (text: string) => {
      stopSpeaking();

      // Clean markdown tags, emojis, and code blocks for speech clarity
      const cleanText = text
        .replace(/```[\s\S]*?```/g, 'Bloque de código omitido.')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/[*_#~>]/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .trim();

      if (!cleanText) return;

      // 1. Try Gemini TTS endpoint if enabled
      if (settings.useGeminiTTS) {
        try {
          const res = await fetch('/api/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: cleanText, voice: 'Kore' }),
          });

          if (res.ok) {
            const data = await res.json();
            if (data.audio) {
              const audio = new Audio(`data:audio/wav;base64,${data.audio}`);
              audioRef.current = audio;
              setIsSpeaking(true);
              audio.onended = () => setIsSpeaking(false);
              audio.onerror = () => setIsSpeaking(false);
              await audio.play();
              return;
            }
          }
        } catch (e) {
          console.warn('Gemini TTS failed, falling back to Web Speech API', e);
        }
      }

      // 2. Web Speech Synthesis fallback
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(cleanText);
        utterance.rate = settings.rate;
        utterance.pitch = settings.pitch;

        // Try to match selected voice
        const voices = window.speechSynthesis.getVoices();
        if (settings.voiceURI) {
          const match = voices.find(
            (v) => v.voiceURI === settings.voiceURI || v.name === settings.voiceURI
          );
          if (match) utterance.voice = match;
        } else {
          // Default to first Spanish voice if available
          const esVoice = voices.find((v) => v.lang.startsWith('es'));
          if (esVoice) utterance.voice = esVoice;
        }

        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);

        window.speechSynthesis.speak(utterance);
      }
    },
    [settings, stopSpeaking]
  );

  return {
    isSpeaking,
    speak,
    stopSpeaking,
  };
};
