# Mily — Gradle wrapper

This project now includes `gradlew` and `gradlew.bat`.

The wrapper reads `gradle/wrapper/gradle-wrapper.properties` and bootstraps the pinned Gradle distribution (`9.3.1`) into the user's Gradle cache.

## Android build

Linux/macOS/Termux:

```bash
chmod +x gradlew
./gradlew :app:assembleDebug
```

Windows:

```bat
gradlew.bat :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

The first run requires internet access because the Gradle distribution is downloaded if it is not already cached.
