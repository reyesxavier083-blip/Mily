# Mily V26 — Memoria Cognitiva

V26 agrega una capa de recuperación cognitiva sobre las memorias existentes.

## Qué hace
- Combina memoria estable, episódica y semántica.
- Calcula relevancia por coincidencia de términos, confianza y recencia.
- Registra cuándo un recuerdo vuelve a ser utilizado.
- Genera un bloque compacto `MEMORIA COGNITIVA RELEVANTE` para el contexto.
- El backend añade `POST /v1/mily/memory/recall` para recuperar recuerdos por consulta.

## Límites
La recuperación es determinista y local; no inventa recuerdos ni convierte coincidencias en hechos nuevos.
