# Implementation rules

1. Prefer Responses for new Mily model interactions.
2. Keep Realtime isolated from ordinary Responses transport while sharing session/memory abstractions.
3. Never put an OpenAI API key in the Android APK. Use a controlled backend or short-lived credentials appropriate to the chosen transport.
4. Keep tool permissions explicit and auditable.
5. Keep File Search/vector-store knowledge separate from private local cognitive memory unless the user explicitly enables synchronization.
6. Make model selection configuration-driven.
7. Capture request IDs and structured errors for diagnostics.
8. Add tests before marking each milestone complete.
9. Do not claim an OpenAI capability is implemented until the corresponding adapter and integration test exist.
