# Mily OpenAI coverage matrix

| OpenAI capability | Mily target | Status in V28 base | Planned milestone |
|---|---|---|---|
| Responses API | OpenAiBackendService | partial | V29 |
| Conversations | repository/state | partial | V31 |
| Prompts | orchestration | planned | V41 |
| Streaming | backend/client | partial | V33 |
| Realtime | MilyRealtimeClient | present | V73–V82 |
| File Search | knowledge layer | partial | V63 |
| Vector stores | knowledge layer | partial | V64 |
| Web Search | tool gateway | planned | V68 |
| Code Interpreter | tool gateway | planned | V69 |
| Function calling | Tool Gateway | partial | V51 |
| Tool search | Tool Gateway | planned | V59 |
| Remote MCP | Tool Gateway | planned | V60 |
| Structured outputs | response parser | planned | V91 |
| Image input | multimodal layer | planned | V83 |
| Audio input | realtime/audio | partial | V84 |
| Image generation | media layer | planned | V88 |
| Speech | voice layer | partial | V85 |
| Transcription | voice layer | partial | V86 |
| Translation | voice layer | planned | V87 |
| Moderation | safety layer | planned | V107 |
| Files | knowledge layer | partial | V99 |
| Embeddings | retrieval layer | planned | V103 |
| Background responses | orchestration | planned | V37 |
| Context management | cognitive layer | partial | V36 |
| Evals | QA | planned | V97 |
| Admin/audit | governance | planned | V112 |

Model IDs should remain configuration-driven. Do not hard-code a model merely because it appears in an example in documentation.
