# Mily V18 — Build & QA

V18 convierte la consolidación V17 en un árbol preparado para validación reproducible.

## Incluido

- `gradlew` / `gradlew.bat` para bootstrap de Gradle 9.3.1.
- `verify-mily.sh` para comprobar wrapper, backend, estructura Android y compilar `assembleDebug`.
- Mantiene V17: memoria, File Search, Tool Gateway, GPT-Live, Context Engine, configuración y orquestación.

## Ejecución

```bash
./verify-mily.sh
```

La compilación real requiere Java/Android SDK y acceso de red la primera vez que Gradle descargue dependencias.
