#!/bin/sh
set -eu
ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT_DIR"

echo "[1/4] Gradle wrapper"
test -x ./gradlew || { echo "ERROR: gradlew is missing or not executable"; exit 1; }
./gradlew --version

echo "[2/4] Backend JavaScript syntax"
node --check backend/mily-openai/server.mjs

echo "[3/4] Android project files"
test -f settings.gradle.kts
test -f build.gradle.kts
test -f app/build.gradle.kts
test -f gradle/wrapper/gradle-wrapper.properties

echo "[4/4] Debug APK compile"
./gradlew :app:assembleDebug

echo "Verification complete. APK: app/build/outputs/apk/debug/app-debug.apk"
