# Mily V27 — Cognitive Memory Integration

V27 conecta la capa de Memoria Cognitiva con el flujo real de conversación.

## Cambios
- `ChatRepository` crea `CognitiveMemoryEngine` cuando están disponibles los DAOs de memoria.
- Las solicitudes GPT realizan recuperación cognitiva antes de construir `memoryFacts`.
- Se conserva un fallback a la memoria local/semántica anterior.
- Después de una respuesta GPT se registra un episodio de conversación de forma asíncrona.
- La recuperación actualiza el acceso de memorias estables, semánticas y episódicas.

## Resultado
Mily ya no tiene la memoria cognitiva como módulo aislado: queda conectada al camino principal de conversación GPT.

## Próxima etapa sugerida
V28 — `Cognitive Memory 2.0`: extracción automática de hechos/preferencias desde conversaciones, deduplicación, actualización de recuerdos y controles de privacidad en la interfaz.
